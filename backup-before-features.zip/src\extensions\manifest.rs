use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExtensionType {
    McpServer,
    Skill,
    Rule,
    Hook,
    Tool,
    Subagent,
    Unknown,
}

impl ExtensionType {
    pub fn display_name(&self) -> &'static str {
        match self {
            Self::McpServer => "MCP Server (Tools & Context)",
            Self::Skill => "Skill (Instructions & Scripts)",
            Self::Rule => "Rule / Guidelines (AGENTS.md)",
            Self::Hook => "Lifecycle Hook (Pre/Post step)",
            Self::Tool => "CLI Tool (Repo Map / Context)",
            Self::Subagent => "Subagent Definition",
            Self::Unknown => "Custom AI Repo",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExtensionPermissions {
    pub allow_network: bool,
    pub allow_file_write: bool,
    pub allow_exec_commands: bool,
    pub allow_read_secrets: bool,
}

impl Default for ExtensionPermissions {
    fn default() -> Self {
        Self {
            allow_network: false,
            allow_file_write: false,
            allow_exec_commands: false,
            allow_read_secrets: false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MechExtensionManifest {
    pub name: String,
    pub version: String,
    pub description: String,
    pub extension_type: ExtensionType,
    pub repository: String,
    pub commit_sha: String,
    pub permissions: ExtensionPermissions,
    pub entry_point: Option<String>,
    pub enabled: bool,
}
