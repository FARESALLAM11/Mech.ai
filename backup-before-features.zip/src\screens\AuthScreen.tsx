import React, { useState } from 'react';
import { Github, Globe2, LockKeyhole, ShieldCheck, ExternalLink } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';
import mechMark from '../mech-mark.svg';

const oauthSetup = [
  { name: 'Google', url: 'https://console.cloud.google.com/auth/clients', icon: <Globe2 size={18} /> },
  { name: 'GitHub', url: 'https://github.com/settings/developers', icon: <Github size={18} /> },
  { name: 'Microsoft / Outlook', url: 'https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade', icon: <span style={{ fontSize: 18, fontWeight: 700, color: '#2563eb' }}>▦</span> },
];

export const AuthScreen: React.FC<{ onContinueLocally?: () => void }> = ({ onContinueLocally }) => {
  const { language } = useTaskStore();
  const isAr = language === 'ar';
  const [mode, setMode] = useState<'login' | 'signup'>('signup');

  return <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 18, background: 'var(--bg-primary)' }}>
    <section style={{ width: '100%', maxWidth: 480, background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 18, padding: '32px clamp(20px, 5vw, 40px)', boxShadow: '0 12px 40px rgba(25,45,75,.07)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}><img src={mechMark} alt="Mech" width={48} height={48} /><div style={{ color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 6, fontSize: 12 }}><LockKeyhole size={14} />{isAr ? 'دخول آمن' : 'Secure access'}</div></div>
      <h1 style={{ fontSize: 25, marginBottom: 7 }}>{isAr ? (mode === 'signup' ? 'أنشئ حساب Mech' : 'مرحباً بعودتك') : (mode === 'signup' ? 'Create your Mech account' : 'Welcome back')}</h1>
      <p style={{ color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.6 }}>{isAr ? 'سجّل باستخدام حساب Google أو GitHub أو Microsoft (Outlook).' : 'Sign in securely with Google, GitHub, or Microsoft (Outlook).'}</p>

      <div style={{ display: 'grid', gap: 10, marginTop: 24 }}>
        {oauthSetup.map(provider => <button key={provider.name} type="button" disabled title={isAr ? 'يجب إعداد OAuth أولاً' : 'OAuth setup required'} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, width: '100%', padding: '12px 14px', borderRadius: 10, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', opacity: .72, cursor: 'not-allowed' }}><span style={{ display: 'flex', alignItems: 'center', gap: 11 }}>{provider.icon}<strong>{isAr ? `المتابعة باستخدام ${provider.name}` : `Continue with ${provider.name}`}</strong></span><span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{isAr ? 'غير مُعدّ' : 'Not configured'}</span></button>)}
      </div>

      <div style={{ marginTop: 18, padding: 14, borderRadius: 10, background: 'var(--color-warning-light)', color: 'var(--color-warning)', fontSize: 12.5, lineHeight: 1.65 }}><strong>{isAr ? 'إعداد OAuth مطلوب' : 'OAuth setup required'}</strong><p style={{ marginTop: 4 }}>{isAr ? 'يجب تسجيل Mech كتطبيق OAuth لدى كل مزود وإضافة Client ID وRedirect URI قبل تفعيل تسجيل الدخول. لم نفعّل أزراراً وهمية ولن نخزن كلمات مرور الحسابات الخارجية.' : 'Register Mech as an OAuth app with each provider and configure its Client ID and redirect URI before enabling sign-in. These buttons are intentionally inactive until then; Mech will not collect your provider passwords.'}</p></div>

      <div style={{ display: 'grid', gap: 8, marginTop: 15 }}>{oauthSetup.map(provider => <a key={provider.name} href={provider.url} target="_blank" rel="noreferrer" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--color-primary)', textDecoration: 'none', fontSize: 12.5 }}>{isAr ? `إعداد تطبيق ${provider.name}` : `Set up ${provider.name} OAuth app`}<ExternalLink size={13} /></a>)}</div>

      <div style={{ marginTop: 22, borderTop: '1px solid var(--border-color)', paddingTop: 18, textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)' }}><span>{isAr ? (mode === 'signup' ? 'لديك حساب بالفعل؟' : 'مستخدم جديد؟') : (mode === 'signup' ? 'Already have an account?' : 'New to Mech?')}</span> <button onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')} style={{ color: 'var(--color-primary)', fontWeight: 700 }}>{isAr ? (mode === 'signup' ? 'تسجيل الدخول' : 'إنشاء حساب') : (mode === 'signup' ? 'Sign in' : 'Create account')}</button></div>
      {onContinueLocally && <button type="button" onClick={onContinueLocally} style={{ display: 'block', width: '100%', marginTop: 20, padding: 12, borderRadius: 10, border: '1px solid var(--border-color)', background: 'transparent', color: 'var(--text-primary)', cursor: 'pointer', fontWeight: 600 }}>{isAr ? 'المتابعة محلياً بدون تسجيل الدخول' : 'Continue locally without signing in'}</button>}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 18, fontSize: 11, color: 'var(--text-secondary)' }}><ShieldCheck size={14} />{isAr ? 'يمكنك استخدام Mech محلياً. يتطلب تفعيل الدخول إعداد تطبيق OAuth أولاً.' : 'You can use Mech locally. Provider sign-in needs OAuth app setup first.'}</div>
    </section>
  </div>;
};
