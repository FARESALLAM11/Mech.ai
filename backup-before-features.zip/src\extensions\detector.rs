use std::path::Path;
use crate::extensions::manifest::{ExtensionPermissions, ExtensionType, MechExtensionManifest};

pub struct ExtensionDetector;

impl ExtensionDetector {
    /// Inspect repository folder structure and infer extension type and manifest
    pub fn inspect_repo_directory(repo_dir: &Path, repo_url: &str, commit_sha: &str) -> MechExtensionManifest {
        // 1. Check for official `mech-extension.json`
        let official_manifest_path = repo_dir.join("mech-extension.json");
        if official_manifest_path.exists() {
            if let Ok(content) = std::fs::read_to_string(&official_manifest_path) {
                if let Ok(parsed) = serde_json::from_str::<MechExtensionManifest>(&content) {
                    return parsed;
                }
            }
        }

        // 2. Detect `SKILL.md` -> Skill
        if repo_dir.join("SKILL.md").exists() || repo_dir.join("skill.md").exists() {
            return MechExtensionManifest {
                name: repo_dir.file_name().unwrap_or_default().to_string_lossy().to_string(),
                version: "1.0.0".into(),
                description: "Skill instructions and automation scripts".into(),
                extension_type: ExtensionType::Skill,
                repository: repo_url.to_string(),
                commit_sha: commit_sha.to_string(),
                permissions: ExtensionPermissions {
                    allow_network: false,
                    allow_file_write: false,
                    allow_exec_commands: true,
                    allow_read_secrets: false,
                },
                entry_point: Some("SKILL.md".into()),
                enabled: true,
            };
        }

        // 3. Detect MCP Server (mcp.json or server.py/index.ts)
        if repo_dir.join("mcp.json").exists() || repo_dir.join("server.py").exists() {
            return MechExtensionManifest {
                name: repo_dir.file_name().unwrap_or_default().to_string_lossy().to_string(),
                version: "1.0.0".into(),
                description: "Model Context Protocol (MCP) tool server".into(),
                extension_type: ExtensionType::McpServer,
                repository: repo_url.to_string(),
                commit_sha: commit_sha.to_string(),
                permissions: ExtensionPermissions {
                    allow_network: true,
                    allow_file_write: false,
                    allow_exec_commands: true,
                    allow_read_secrets: false,
                },
                entry_point: Some("mcp.json".into()),
                enabled: true,
            };
        }

        // 4. Detect AGENTS.md or rules -> Rule
        if repo_dir.join("AGENTS.md").exists() || repo_dir.join("rules.md").exists() {
            return MechExtensionManifest {
                name: repo_dir.file_name().unwrap_or_default().to_string_lossy().to_string(),
                version: "1.0.0".into(),
                description: "Agent guidance and coding style rules".into(),
                extension_type: ExtensionType::Rule,
                repository: repo_url.to_string(),
                commit_sha: commit_sha.to_string(),
                permissions: ExtensionPermissions::default(),
                entry_point: Some("AGENTS.md".into()),
                enabled: true,
            };
        }

        // Default fallback
        MechExtensionManifest {
            name: repo_dir.file_name().unwrap_or_default().to_string_lossy().to_string(),
            version: "0.1.0".into(),
            description: "Custom AI Repository Extension".into(),
            extension_type: ExtensionType::Unknown,
            repository: repo_url.to_string(),
            commit_sha: commit_sha.to_string(),
            permissions: ExtensionPermissions::default(),
            entry_point: None,
            enabled: true,
        }
    }
}
