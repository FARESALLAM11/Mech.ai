use std::path::Path;
use crate::sandbox::WindowsJobObjectSandbox;

pub struct HookRunner;

impl HookRunner {
    /// Execute pre-step hook (e.g. workspace verification or git check)
    pub fn run_pre_step_hook(worktree_dir: &Path, hook_cmd: &str) -> anyhow::Result<(bool, String)> {
        WindowsJobObjectSandbox::execute_sandboxed(worktree_dir, hook_cmd, false)
    }

    /// Execute post-step hook (e.g. code formatter, linter, or security scan)
    pub fn run_post_step_hook(worktree_dir: &Path, hook_cmd: &str) -> anyhow::Result<(bool, String)> {
        WindowsJobObjectSandbox::execute_sandboxed(worktree_dir, hook_cmd, false)
    }
}
