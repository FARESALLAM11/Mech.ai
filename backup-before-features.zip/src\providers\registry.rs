use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, StreamChunk};
use std::collections::HashMap;
use std::sync::Arc;
use std::sync::RwLock;
use tokio::sync::mpsc;

pub struct ProviderRegistry {
    providers: RwLock<HashMap<String, Arc<dyn ProviderAdapter>>>,
    fallback_chain: RwLock<Vec<String>>,
}

impl ProviderRegistry {
    pub fn new() -> Self {
        Self {
            providers: RwLock::new(HashMap::new()),
            fallback_chain: RwLock::new(Vec::new()),
        }
    }

    pub fn register(&self, provider: Arc<dyn ProviderAdapter>) {
        let id = provider.id().to_string();
        self.providers
            .write()
            .unwrap_or_else(|e| e.into_inner())
            .insert(id.clone(), provider);
        let mut chain = self
            .fallback_chain
            .write()
            .unwrap_or_else(|e| e.into_inner());
        if !chain.contains(&id) {
            chain.push(id);
        }
    }

    pub fn unregister(&self, id: &str) {
        self.providers
            .write()
            .unwrap_or_else(|e| e.into_inner())
            .remove(id);
        self.fallback_chain
            .write()
            .unwrap_or_else(|e| e.into_inner())
            .retain(|provider_id| provider_id != id);
    }

    pub fn set_fallback_chain(&self, chain: Vec<String>) {
        *self
            .fallback_chain
            .write()
            .unwrap_or_else(|e| e.into_inner()) = chain;
    }

    pub fn has_provider(&self, id: &str) -> bool {
        self.providers
            .read()
            .unwrap_or_else(|e| e.into_inner())
            .contains_key(id)
    }

    pub fn get(&self, id: &str) -> Option<Arc<dyn ProviderAdapter>> {
        self.providers
            .read()
            .unwrap_or_else(|e| e.into_inner())
            .get(id)
            .cloned()
    }

    /// List all models across all registered providers
    pub async fn list_all_models(&self) -> Vec<ModelInfo> {
        let mut all = Vec::new();
        let providers: Vec<_> = self
            .providers
            .read()
            .unwrap_or_else(|e| e.into_inner())
            .values()
            .cloned()
            .collect();
        for provider in providers {
            if let Ok(models) = provider.list_models().await {
                all.extend(models);
            }
        }
        all
    }

    /// Execute chat stream with automatic fallback chain if primary fails
    pub async fn execute_with_fallback(
        &self,
        preferred_provider_id: &str,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<String> {
        let mut candidates = vec![preferred_provider_id.to_string()];
        let fallback_chain = self
            .fallback_chain
            .read()
            .unwrap_or_else(|e| e.into_inner())
            .clone();
        for f in &fallback_chain {
            if f != preferred_provider_id && !candidates.contains(f) {
                candidates.push(f.clone());
            }
        }

        let mut last_error = None;

        for provider_id in candidates {
            if let Some(provider) = self.get(&provider_id) {
                // Inform UI of provider being contacted
                let _ = sender
                    .send(StreamChunk {
                        delta: format!("\n[Mech Provider: {}]\n", provider.name()),
                        is_done: false,
                        prompt_tokens: None,
                        completion_tokens: None,
                        cost_usd: None,
                    })
                    .await;

                match provider.chat_stream(model, messages, sender.clone()).await {
                    Ok(()) => return Ok(provider_id),
                    Err(e) => {
                        let _ = sender
                            .send(StreamChunk {
                                delta: format!(
                                    "\n[Provider {} failed: {}. Switching to next fallback...]\n",
                                    provider_id, e
                                ),
                                is_done: false,
                                prompt_tokens: None,
                                completion_tokens: None,
                                cost_usd: None,
                            })
                            .await;
                        last_error = Some(e);
                    }
                }
            }
        }

        anyhow::bail!(
            "All providers in fallback chain failed. Last error: {:?}",
            last_error
        );
    }
}
