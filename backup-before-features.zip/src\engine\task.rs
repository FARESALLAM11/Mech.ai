use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum TaskStatus {
    Planned,
    Running,
    Testing,
    Reviewing,
    Done,
    Failed,
    Paused,
}

impl TaskStatus {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Planned => "planned",
            Self::Running => "running",
            Self::Testing => "testing",
            Self::Reviewing => "reviewing",
            Self::Done => "done",
            Self::Failed => "failed",
            Self::Paused => "paused",
        }
    }

    /// Check if state transition is valid
    pub fn can_transition_to(&self, next: TaskStatus) -> bool {
        match (self, next) {
            (Self::Planned, TaskStatus::Running) => true,
            (Self::Running, TaskStatus::Testing) => true,
            (Self::Running, TaskStatus::Failed) => true,
            (Self::Running, TaskStatus::Paused) => true,
            (Self::Testing, TaskStatus::Reviewing) => true,
            (Self::Testing, TaskStatus::Running) => true, // Retry loop
            (Self::Testing, TaskStatus::Failed) => true,
            (Self::Reviewing, TaskStatus::Done) => true,
            (Self::Reviewing, TaskStatus::Failed) => true,
            (Self::Paused, TaskStatus::Running) => true, // Resume
            _ => false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskStepEvent {
    pub task_id: String,
    pub step_index: i32,
    pub status: TaskStatus,
    pub description: String,
    pub diff_preview: Option<String>,
    pub cost_usd: f64,
    pub duration_ms: u64,
}
