import React from 'react';
import { AlertTriangle, ShieldCheck, XCircle, CheckCircle, Terminal } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

export interface PendingApproval {
  id: string;
  command: string;
  actionType: string;
  explanation: string;
}

interface ApprovalModalProps {
  request: PendingApproval | null;
  onDecide: (approved: boolean, remember: boolean) => void;
}

export const ApprovalModal: React.FC<ApprovalModalProps> = ({ request, onDecide }) => {
  const { language } = useTaskStore();
  const isAr = language === 'ar';

  if (!request) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.6)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 5000,
      padding: '20px',
    }}>
      <div style={{
        background: 'var(--bg-primary)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        maxWidth: '540px',
        width: '100%',
        padding: '24px',
        boxShadow: '0 20px 50px rgba(0,0,0,0.25)',
        display: 'flex',
        flexDirection: 'column',
        gap: '20px',
      }}>
        {/* Warning Badge & Title */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            padding: '10px',
            borderRadius: 'var(--radius-md)',
            background: 'var(--color-warning-light)',
            color: 'var(--color-warning)',
          }}>
            <AlertTriangle size={24} />
          </div>
          <div>
            <h3 style={{ fontSize: '17px', fontWeight: 700 }}>
              {isAr ? 'موافقة مطلوبة لتنفيذ أمر حساس' : 'Human Approval Required'}
            </h3>
            <span style={{ fontSize: '12.5px', color: 'var(--text-secondary)' }}>
              {isAr ? 'حماية بيئة المطور والصلاحيات' : 'Sandbox Security & Permissions Guard'}
            </span>
          </div>
        </div>

        {/* Explanation */}
        <p style={{ fontSize: '13.5px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
          {request.explanation || (isAr
            ? 'يحاول الوكيل تنفيذ أمر حساس أو خارج قائمة السماح الخاصة بالمشروع. هل تسمح بتنفيذه؟'
            : 'The agent is attempting to run a sensitive or unlisted command. Do you authorize execution?')}
        </p>

        {/* Command Box */}
        <div style={{
          background: '#1E1E1E',
          color: '#E0E0E0',
          borderRadius: 'var(--radius-md)',
          padding: '12px 14px',
          fontFamily: 'var(--font-mono)',
          fontSize: '13px',
          direction: 'ltr',
          textAlign: 'left',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          overflowX: 'auto',
        }}>
          <Terminal size={16} color="#4EC9B0" />
          <span>{request.command}</span>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', flexWrap: 'wrap' }}>
          <button
            onClick={() => onDecide(false, false)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '9px 16px',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-color)',
              background: '#fff',
              color: 'var(--color-error)',
              fontSize: '13px',
              fontWeight: 600,
            }}
          >
            <XCircle size={15} />
            <span>{isAr ? 'رفض وحظر الأمر' : 'Deny Command'}</span>
          </button>

          <button
            onClick={() => onDecide(true, false)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '9px 16px',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-color)',
              background: 'var(--bg-secondary)',
              color: 'var(--text-primary)',
              fontSize: '13px',
              fontWeight: 600,
            }}
          >
            <CheckCircle size={15} />
            <span>{isAr ? 'موافقة لمرة واحدة' : 'Approve Once'}</span>
          </button>

          <button
            onClick={() => onDecide(true, true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '9px 18px',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-primary)',
              color: '#fff',
              fontSize: '13px',
              fontWeight: 600,
            }}
          >
            <ShieldCheck size={15} />
            <span>{isAr ? 'موافقة وإضافة للقائمة المسموحة' : 'Approve & Allow Always'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
