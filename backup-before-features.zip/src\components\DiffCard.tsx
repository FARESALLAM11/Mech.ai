import React, { useState } from 'react';
import { Check, CheckCircle2, ChevronDown, ChevronUp, FileCode, FileDiff, LoaderCircle } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';
import { parseDiff } from '../lib/diff';
import { acceptTaskChanges } from '../lib/runtime';

interface DiffCardProps {
  diff: string;
  projectPath: string;
  taskId: string | null;
  conversationId: string;
  turnId: string;
  applied?: boolean;
  full?: boolean;
}

export const DiffCard: React.FC<DiffCardProps> = ({
  diff,
  projectPath,
  taskId,
  conversationId,
  turnId,
  applied = false,
  full = false,
}) => {
  const { language, setCurrentScreen, markApplied, t } = useTaskStore();
  const strings = t();
  const isAr = language === 'ar';
  const [expanded, setExpanded] = useState(true);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const { lines, files, additions, deletions } = parseDiff(diff);
  const simulated = !taskId || taskId.startsWith('preview-');
  const fileLabel = `${files.length || 1} ${files.length === 1 ? (isAr ? 'ملف' : 'file') : strings.chat.files}`;

  const apply = async () => {
    if (!taskId || busy || simulated) return;
    setBusy(true);
    setError(null);
    try {
      const count = await acceptTaskChanges(projectPath, taskId);
      markApplied(conversationId, turnId);
      setMessage(
        isAr ? `تم تطبيق ${count} ملف بعد موافقتك.` : `Applied ${count} file(s) after your approval.`,
      );
    } catch (applyError) {
      setError(applyError instanceof Error ? applyError.message : String(applyError));
    } finally {
      setBusy(false);
      setConfirming(false);
    }
  };

  return (
    <section className={`diff-card${full ? ' is-full' : ''}`} aria-label={strings.chat.changes}>
      <header className="diff-head">
        <FileDiff size={15} color="var(--text-secondary)" />
        <strong>{strings.chat.changes}</strong>
        <span className="diff-files">{fileLabel}</span>
        <span className="diff-add">+{additions}</span>
        <span className="diff-del">−{deletions}</span>
        <button
          type="button"
          className="icon-btn"
          onClick={() => setExpanded(value => !value)}
          aria-expanded={expanded}
          aria-label={isAr ? (expanded ? 'طي التغييرات' : 'عرض التغييرات') : expanded ? 'Collapse changes' : 'Show changes'}
        >
          {expanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
        </button>
      </header>

      {files.length > 0 && (
        <div className="diff-files-row">
          {files.slice(0, 6).map(file => (
            <span className="file-chip" key={file}>
              <FileCode size={11} />
              {file}
            </span>
          ))}
          {files.length > 6 && <span className="file-chip">+{files.length - 6}</span>}
        </div>
      )}

      {expanded && (
        <pre className="diff-body">
          {lines.map((line, index) => (
            <span key={index} className={`diff-line is-${line.type}`}>
              {line.text || ' '}
            </span>
          ))}
        </pre>
      )}

      {(error || message) && (
        <div
          role={error ? 'alert' : 'status'}
          className="inline-error"
          style={error ? { border: 0, borderRadius: 0 } : {
            border: 0,
            borderRadius: 0,
            background: 'var(--color-success-light)',
            color: 'var(--color-success)',
          }}
        >
          {error ?? message}
        </div>
      )}

      {confirming && (
        <div className="confirm" role="alertdialog" aria-label={strings.chat.accept}>
          <span>{strings.chat.applyQuestion.replace('{n}', String(files.length || 1))}</span>
          <div className="confirm-actions">
            <button type="button" className="btn" onClick={() => setConfirming(false)}>
              {strings.chat.cancel}
            </button>
            <button type="button" className="btn btn-success" onClick={() => void apply()}>
              {busy ? <LoaderCircle size={14} className="spin" /> : <Check size={14} />}
              {strings.chat.accept}
            </button>
          </div>
        </div>
      )}

      {!applied && !confirming && (
        <footer className="diff-foot">
          <span className="diff-note">
            {simulated
              ? isAr
                ? 'تشغيل محاكى — لن تُكتب أي ملفات.'
                : 'Simulated run — nothing is written to disk.'
              : strings.chat.privacyHint}
          </span>
          <button
            type="button"
            className="btn btn-quiet"
            onClick={() => setCurrentScreen('diff')}
          >
            {strings.chat.review}
          </button>
          <button
            type="button"
            className="btn btn-success"
            disabled={simulated}
            title={simulated ? (isAr ? 'غير متاح في وضع المعاينة' : 'Not available in preview mode') : undefined}
            onClick={() => setConfirming(true)}
          >
            <Check size={14} />
            {strings.chat.accept}
          </button>
        </footer>
      )}

      {applied && (
        <footer className="diff-foot">
          <span className="applied-note">
            <CheckCircle2 size={14} />
            {strings.chat.applied}
          </span>
        </footer>
      )}
    </section>
  );
};
