import React, { useState } from 'react';
import { BookOpenText, Bug, FlaskConical, Wand2 } from 'lucide-react';
import mechMark from '../mech-mark.svg';
import { ChatThread } from '../components/ChatThread';
import { Composer } from '../components/Composer';
import { useTaskStore, isRunActive } from '../store/taskStore';
import { isDesktop, startTask } from '../lib/runtime';
import { runPreviewTask } from '../lib/preview';

export const HomeScreen: React.FC = () => {
  const {
    conversations,
    activeConversationId,
    taskPrompt,
    setTaskPrompt,
    projectPath,
    selectedModel,
    budgetLimit,
    appendUserTurn,
    beginAssistantTurn,
    setTaskId,
    setConversationDiff,
    failActiveTurn,
    t,
  } = useTaskStore();

  const strings = t();
  const [error, setError] = useState<string | null>(null);
  const [focusToken, setFocusToken] = useState(0);

  const conversation = conversations.find(item => item.id === activeConversationId);
  const turns = conversation?.turns ?? [];
  const hasTurns = turns.length > 0;
  const busy = isRunActive(conversation?.status);

  const suggest = (prompt: string) => {
    setTaskPrompt(prompt);
    setFocusToken(token => token + 1);
  };

  const handleSubmit = () => {
    const prompt = taskPrompt.trim();
    if (!prompt || busy) return;

    if (!isDesktop()) {
      setError(null);
      appendUserTurn(prompt);
      setTaskPrompt('');
      beginAssistantTurn();
      void runPreviewTask(useTaskStore.getState().activeConversationId);
      return;
    }

    if (!projectPath.trim()) {
      setError(strings.chat.chooseProject);
      return;
    }

    const [preferredProvider, ...rest] = selectedModel.split('::');
    const model = rest.join('::');
    if (!preferredProvider || !model) {
      setError(strings.chat.addProvider);
      return;
    }

    setError(null);
    appendUserTurn(prompt);
    setTaskPrompt('');
    beginAssistantTurn();
    const runId = useTaskStore.getState().activeConversationId;

    void (async () => {
      try {
        const result = await startTask({
          projectPath,
          prompt,
          preferredProvider,
          model,
          budgetLimit,
        });
        setTaskId(result.task_id, runId);
        if (result.diff?.trim()) setConversationDiff(result.diff, runId);
      } catch (startError) {
        failActiveTurn(
          startError instanceof Error ? startError.message : String(startError),
          runId,
        );
      }
    })();
  };

  const suggestions = [
    { icon: <Bug size={16} />, ...strings.chat.suggestions.bug, prompt: strings.chat.prompts.bug },
    { icon: <Wand2 size={16} />, ...strings.chat.suggestions.feature, prompt: strings.chat.prompts.feature },
    { icon: <FlaskConical size={16} />, ...strings.chat.suggestions.tests, prompt: strings.chat.prompts.tests },
    { icon: <BookOpenText size={16} />, ...strings.chat.suggestions.explain, prompt: strings.chat.prompts.explain },
  ];

  if (!hasTurns) {
    return (
      <div className="chat-page">
        <div className="chat-empty">
          <div className="chat-empty-inner">
            <header className="hero">
              <div className="hero-mark">
                <img src={mechMark} alt="" width={30} height={30} />
              </div>
              <h1>{strings.chat.heroTitle}</h1>
              <p>{strings.chat.heroSubtitle}</p>
            </header>

            <div className="suggestions">
              {suggestions.map(suggestion => (
                <button
                  type="button"
                  key={suggestion.title}
                  className="suggestion"
                  onClick={() => suggest(suggestion.prompt)}
                >
                  {suggestion.icon}
                  <span className="suggestion-copy">
                    <strong>{suggestion.title}</strong>
                    <span>{suggestion.text}</span>
                  </span>
                </button>
              ))}
            </div>

            <div className="composer-inline">
              {error && (
                <div className="inline-error" role="alert" style={{ marginBottom: 10 }}>
                  {error}
                </div>
              )}
              <Composer onSubmit={handleSubmit} busy={busy} focusToken={focusToken} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="chat-page">
      <ChatThread conversation={conversation!} busy={busy} />
      <div className="composer-dock">
        {error && (
          <div
            className="inline-error"
            role="alert"
            style={{ maxWidth: 780, margin: '0 auto 8px' }}
          >
            {error}
          </div>
        )}
        <Composer onSubmit={handleSubmit} busy={busy} focusToken={focusToken} />
      </div>
    </div>
  );
};

export default HomeScreen;
