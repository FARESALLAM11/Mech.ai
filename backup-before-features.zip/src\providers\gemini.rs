use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};
use async_trait::async_trait;
use futures_util::StreamExt;
use serde_json::json;
use tokio::sync::mpsc;

pub struct GeminiProvider {
    pub api_key: String,
    pub base_url: String,
}

impl GeminiProvider {
    pub fn new(api_key: String) -> Self {
        Self {
            api_key,
            base_url: "https://generativelanguage.googleapis.com/v1beta".to_string(),
        }
    }
}

#[async_trait]
impl ProviderAdapter for GeminiProvider {
    fn id(&self) -> &str {
        "gemini"
    }

    fn name(&self) -> &str {
        "Google Gemini (AI Studio)"
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let client = reqwest::Client::new();
        let target_model = if model.is_empty() || model == "default" {
            "gemini-1.5-pro"
        } else {
            model
        };

        let url = format!(
            "{}/models/{}:streamGenerateContent?alt=sse",
            self.base_url.trim_end_matches('/'),
            target_model
        );

        let contents: Vec<serde_json::Value> = messages
            .iter()
            .map(|m| {
                let role = if m.role == "user" { "user" } else { "model" };
                json!({
                    "role": role,
                    "parts": [{ "text": m.content }]
                })
            })
            .collect();

        let payload = json!({
            "contents": contents,
            "generationConfig": {
                "temperature": 0.2,
                "maxOutputTokens": 8192
            }
        });

        let res = client
            .post(&url)
            .header("x-goog-api-key", &self.api_key)
            .header("content-type", "application/json")
            .json(&payload)
            .send()
            .await?;

        if !res.status().is_success() {
            let error_text = res.text().await.unwrap_or_else(|_| "Gemini error".into());
            anyhow::bail!("Gemini request failed: {}", error_text);
        }

        let mut stream = res.bytes_stream();
        let mut buffer = String::new();
        let mut prompt_tokens = 0i64;
        let mut completion_tokens = 0i64;

        while let Some(item) = stream.next().await {
            let chunk = item?;
            let text = String::from_utf8_lossy(&chunk);
            buffer.push_str(&text);

            while let Some(newline_pos) = buffer.find('\n') {
                let line = buffer[..newline_pos].trim().to_string();
                buffer.drain(..=newline_pos);

                if let Some(json_str) = line.strip_prefix("data: ") {
                    if let Ok(val) = serde_json::from_str::<serde_json::Value>(json_str) {
                        if let Some(candidates) = val.get("candidates").and_then(|c| c.as_array()) {
                            if let Some(first_candidate) = candidates.first() {
                                if let Some(parts) = first_candidate["content"]["parts"].as_array()
                                {
                                    for part in parts {
                                        if let Some(text) = part["text"].as_str() {
                                            let _ = sender
                                                .send(StreamChunk {
                                                    delta: text.to_string(),
                                                    is_done: false,
                                                    prompt_tokens: None,
                                                    completion_tokens: None,
                                                    cost_usd: None,
                                                })
                                                .await;
                                        }
                                    }
                                }
                            }
                        }

                        if let Some(usage) = val.get("usageMetadata") {
                            prompt_tokens =
                                usage["promptTokenCount"].as_i64().unwrap_or(prompt_tokens);
                            completion_tokens = usage["candidatesTokenCount"]
                                .as_i64()
                                .unwrap_or(completion_tokens);
                        }
                    }
                }
            }
        }

        let cost = self.price(
            target_model,
            prompt_tokens as usize,
            completion_tokens as usize,
        );
        let _ = sender
            .send(StreamChunk {
                delta: String::new(),
                is_done: true,
                prompt_tokens: Some(prompt_tokens),
                completion_tokens: Some(completion_tokens),
                cost_usd: Some(cost),
            })
            .await;

        Ok(())
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "gemini-1.5-pro".into(),
                name: "Gemini 1.5 Pro (2M Context)".into(),
                provider: "gemini".into(),
                context_window: 2000000,
                input_price_per_m: 1.25,
                output_price_per_m: 5.00,
                supports_streaming: true,
            },
            ModelInfo {
                id: "gemini-1.5-flash".into(),
                name: "Gemini 1.5 Flash (Ultra Fast)".into(),
                provider: "gemini".into(),
                context_window: 1000000,
                input_price_per_m: 0.075,
                output_price_per_m: 0.30,
                supports_streaming: true,
            },
            ModelInfo {
                id: "gemini-2.0-flash-exp".into(),
                name: "Gemini 2.0 Flash Experimental".into(),
                provider: "gemini".into(),
                context_window: 1000000,
                input_price_per_m: 0.10,
                output_price_per_m: 0.40,
                supports_streaming: true,
            },
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        text.len().div_ceil(4)
    }

    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let (in_rate, out_rate) = match model {
            m if m.contains("flash") => (0.075, 0.30),
            _ => (1.25, 5.00),
        };
        let in_cost = (input_tokens as f64 / 1_000_000.0) * in_rate;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * out_rate;
        in_cost + out_cost
    }

    fn capabilities(&self, _model: &str) -> ProviderCapabilities {
        ProviderCapabilities {
            streaming: true,
            tool_calling: true,
            prompt_caching: true,
            context_window: 2000000,
        }
    }
}
