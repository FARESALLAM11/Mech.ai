import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { CheckCircle2, Clock3, DollarSign, ListTodo, RefreshCw } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

type TaskRecord = { id: string; title: string; project_path: string; status: string; total_cost_usd: number; total_tokens: number; created_at: string; updated_at: string };

export const AnalyticsScreen: React.FC = () => {
  const { t, language } = useTaskStore();
  const strings = t();
  const isAr = language === 'ar';
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const refresh = useCallback(async () => {
    try { setTasks(await invoke<TaskRecord[]>('list_task_records')); setError(null); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  const metrics = useMemo(() => {
    const cost = tasks.reduce((sum, task) => sum + task.total_cost_usd, 0);
    const reviewed = tasks.filter(task => task.status === 'reviewing').length;
    const done = tasks.filter(task => task.status === 'done').length;
    const failed = tasks.filter(task => task.status === 'failed').length;
    return { cost, reviewed, done, failed, avg: tasks.length ? cost / tasks.length : 0 };
  }, [tasks]);
  const cards = [
    { label: isAr ? 'المهام المسجلة' : 'Recorded tasks', value: String(tasks.length), icon: <ListTodo size={19} /> },
    { label: isAr ? 'بانتظار مراجعة التغيير' : 'Diffs ready for review', value: String(metrics.reviewed), icon: <Clock3 size={19} /> },
    { label: isAr ? 'المهام المكتملة' : 'Completed tasks', value: String(metrics.done), icon: <CheckCircle2 size={19} /> },
    { label: isAr ? 'إجمالي التكلفة المسجلة' : 'Recorded total cost', value: `$${metrics.cost.toFixed(4)}`, icon: <DollarSign size={19} /> },
  ];

  return <div style={{ display: 'grid', gap: 18 }}>
    <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div><h2 style={{ fontSize: 21, fontWeight: 700 }}>{strings.analytics.title}</h2><p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{isAr ? 'تعرض هذه اللوحة سجلات المحرك المحلي فقط، دون أرقام تقديرية.' : 'This dashboard reports local engine records only; estimates are not shown.'}</p></div><button onClick={() => void refresh()} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '8px 12px', border: '1px solid var(--border-color)', borderRadius: 8, background: 'var(--bg-secondary)', color: 'var(--text-primary)' }}><RefreshCw size={14} />{isAr ? 'تحديث' : 'Refresh'}</button></header>
    {error && <div role="alert" style={{ padding: 12, borderRadius: 9, background: 'var(--color-error-light)', color: 'var(--color-error)' }}>{isAr ? 'تعذر تحميل سجلات المهام:' : 'Could not load task records:'} {error}</div>}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 12 }}>{cards.map(c => <article key={c.label} style={{ padding: 18, border: '1px solid var(--border-color)', borderRadius: 12, background: 'var(--bg-card)' }}><div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-secondary)', fontSize: 13 }}>{c.label}{c.icon}</div><div style={{ marginTop: 9, fontSize: 27, fontWeight: 700 }}>{c.value}</div></article>)}</div>
    <section style={{ padding: 18, border: '1px solid var(--border-color)', borderRadius: 12, background: 'var(--bg-card)' }}><h3 style={{ fontSize: 16 }}>{isAr ? 'سجل المهام' : 'Task history'}</h3><p style={{ color: 'var(--text-secondary)', fontSize: 12, margin: '4px 0 12px' }}>{isAr ? `متوسط التكلفة لكل مهمة: $${metrics.avg.toFixed(4)} · فشل مسجل: ${metrics.failed}` : `Average recorded cost per task: $${metrics.avg.toFixed(4)} · Failures recorded: ${metrics.failed}`}</p>
      {tasks.length === 0 ? <p style={{ color: 'var(--text-secondary)', padding: 18, textAlign: 'center' }}>{isAr ? 'لا توجد مهام في قاعدة البيانات بعد.' : 'No task records in the local database yet.'}</p> : <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 620 }}><thead><tr>{[isAr ? 'المهمة' : 'Task', isAr ? 'الحالة' : 'Status', isAr ? 'التكلفة' : 'Cost', isAr ? 'وقت الإنشاء' : 'Created'].map(label => <th key={label} style={{ textAlign: 'start', padding: 10, color: 'var(--text-secondary)', fontSize: 12, borderBottom: '1px solid var(--border-color)' }}>{label}</th>)}</tr></thead><tbody>{tasks.map(task => <tr key={task.id}><td style={{ padding: 10, borderBottom: '1px solid var(--border-color)' }}>{task.title}</td><td style={{ padding: 10, borderBottom: '1px solid var(--border-color)' }}>{task.status}</td><td style={{ padding: 10, borderBottom: '1px solid var(--border-color)' }}>${task.total_cost_usd.toFixed(4)}</td><td style={{ padding: 10, borderBottom: '1px solid var(--border-color)' }}>{new Date(task.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>}
    </section>
    <p style={{ color: 'var(--text-secondary)', fontSize: 11 }}>{isAr ? 'وقت التوفير وتوزيع التكلفة حسب المزود غير متاحين حتى يسجل المحرك هذه البيانات.' : 'Time saved and provider-level spend are omitted until the engine records those fields.'}</p>
  </div>;
};
