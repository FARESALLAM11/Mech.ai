import { create, type StateCreator } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { translations, Language } from '../i18n/translations';

export type TaskStatus =
  | 'idle'
  | 'planned'
  | 'running'
  | 'testing'
  | 'reviewing'
  | 'done'
  | 'failed'
  | 'paused';

export type ScreenId =
  | 'tasks'
  | 'diff'
  | 'providers'
  | 'memory'
  | 'analytics'
  | 'aiRepos'
  | 'settings'
  | 'beta'
  | 'agents';

export interface TimelineEvent {
  step_index: number;
  status: TaskStatus;
  description: string;
  diff_preview?: string;
  cost_usd: number;
  duration_ms: number;
  task_id?: string;
}

export interface ChatTurn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  at: number;
  status?: TaskStatus;
  steps?: TimelineEvent[];
  diff?: string;
  costUsd?: number;
  taskId?: string | null;
  error?: string | null;
  applied?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  projectPath: string;
  turns: ChatTurn[];
  status: TaskStatus;
  diff: string;
  taskId: string | null;
  totalCostUsd: number;
}

export const RUNNING_STATES: TaskStatus[] = ['planned', 'running', 'testing'];

export const isRunActive = (status: TaskStatus | undefined) =>
  status !== undefined && RUNNING_STATES.includes(status);

interface TaskState {
  currentScreen: ScreenId;
  projectPath: string;
  taskPrompt: string;
  budgetLimit: number;
  selectedModel: string;
  language: Language;
  theme: 'light' | 'dark';
  isCommandPaletteOpen: boolean;
  isOnboardingOpen: boolean;
  projectMemory: {
    decisions: string;
    rules: string;
  };

  conversations: Conversation[];
  activeConversationId: string;

  /* Legacy mirrors of the active conversation, kept for the secondary screens */
  currentStatus: TaskStatus;
  totalCostUsd: number;
  timeline: TimelineEvent[];
  currentDiff: string;
  currentTaskId: string | null;

  setCurrentScreen: (screen: ScreenId) => void;
  setProjectPath: (path: string) => void;
  setTaskPrompt: (prompt: string) => void;
  setBudgetLimit: (limit: number) => void;
  setSelectedModel: (model: string) => void;
  toggleLanguage: () => void;
  setLanguage: (language: Language) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setCommandPaletteOpen: (open: boolean) => void;
  setOnboardingOpen: (open: boolean) => void;
  updateProjectMemory: (decisions: string, rules: string) => void;
  t: () => typeof translations['ar'];

  ensureActiveConversation: () => Conversation;
  newConversation: () => string;
  selectConversation: (id: string) => void;
  appendUserTurn: (text: string) => void;
  beginAssistantTurn: () => void;
  addTimelineEvent: (event: TimelineEvent) => void;
  setTaskId: (taskId: string | null, conversationId?: string) => void;
  setConversationDiff: (diff: string, conversationId?: string) => void;
  failActiveTurn: (message: string, conversationId?: string) => void;
  markApplied: (conversationId?: string, turnId?: string) => void;
  resetTask: () => void;

  /* Kept for compatibility with the existing diff screen */
  setCurrentDiff: (diff: string) => void;
  setCurrentTaskId: (taskId: string | null) => void;
}

const now = () => Date.now();

const uid = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `id-${Math.random().toString(36).slice(2)}${now()}`;

const isTauriRuntime = () =>
  typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

const createConversation = (projectPath: string): Conversation => ({
  id: uid(),
  title: '',
  createdAt: now(),
  updatedAt: now(),
  projectPath,
  turns: [],
  status: 'idle',
  diff: '',
  taskId: null,
  totalCostUsd: 0,
});

const titleFrom = (text: string) => {
  const clean = text.replace(/\s+/g, ' ').trim();
  return clean.length > 48 ? `${clean.slice(0, 48).trimEnd()}…` : clean;
};

const replaceConversation = (list: Conversation[], next: Conversation) =>
  list.map(conversation => (conversation.id === next.id ? next : conversation));

const mirrors = (conversation: Conversation) => ({
  currentStatus: conversation.status,
  totalCostUsd: conversation.totalCostUsd,
  currentDiff: conversation.diff,
  currentTaskId: conversation.taskId,
  timeline: conversation.turns.flatMap(turn => turn.steps ?? []),
});

const findAssistantIndex = (turns: ChatTurn[]) => {
  for (let index = turns.length - 1; index >= 0; index -= 1) {
    if (turns[index].role === 'assistant') return index;
  }
  return -1;
};

/* Persist workspace history, but never block typing on a synchronous write. */
let pendingWrite: { name: string; value: string } | null = null;
let persistTimer: ReturnType<typeof setTimeout> | undefined;

const flushWorkspace = () => {
  if (!pendingWrite) return;
  try {
    localStorage.setItem(pendingWrite.name, pendingWrite.value);
  } catch {
    /* storage can be full or disabled */
  }
  pendingWrite = null;
};

const workspaceStorage = {
  getItem: (name: string) => {
    try {
      return localStorage.getItem(name);
    } catch {
      return null;
    }
  },
  setItem: (name: string, value: string) => {
    pendingWrite = { name, value };
    clearTimeout(persistTimer);
    persistTimer = setTimeout(flushWorkspace, 250);
  },
  removeItem: (name: string) => {
    try {
      localStorage.removeItem(name);
    } catch {
      /* optional */
    }
  },
};

if (typeof window !== 'undefined') {
  window.addEventListener('pagehide', flushWorkspace);
}

const createTaskState: StateCreator<TaskState> = (set, get) => ({
  currentScreen: 'tasks',
  projectPath: isTauriRuntime() ? '' : 'fixtures/sample-project',
  taskPrompt: '',
  budgetLimit: 2.0,
  selectedModel: '',
  language: (() => {
    try {
      return (localStorage.getItem('mech.language') as Language) || 'en';
    } catch {
      return 'en';
    }
  })(),
  theme: (() => {
    try {
      return localStorage.getItem('mech.theme') === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  })() as 'light' | 'dark',
  isCommandPaletteOpen: false,
  isOnboardingOpen: false,
  projectMemory: {
    decisions:
      '# Architectural Decisions\n- Use SQLite WAL mode for concurrency and zero corruption.\n- Enforce isolated Git Worktree for every coding task.\n- Keep frontend bundle under 100 KB gzipped.',
    rules:
      '# Project Rules\n- Maintain documentation integrity.\n- Never leak API keys in logs or git commits.\n- Code formatting: 2 spaces, strict TypeScript.',
  },

  conversations: [],
  activeConversationId: '',

  currentStatus: 'idle',
  totalCostUsd: 0,
  timeline: [],
  currentDiff: '',
  currentTaskId: null,

  setCurrentScreen: currentScreen => set({ currentScreen }),
  setProjectPath: projectPath => set({ projectPath }),
  setTaskPrompt: taskPrompt => set({ taskPrompt }),
  setBudgetLimit: budgetLimit => set({ budgetLimit }),
  setSelectedModel: selectedModel => set({ selectedModel }),

  toggleLanguage: () =>
    set(state => {
      const language: Language = state.language === 'ar' ? 'en' : 'ar';
      try {
        localStorage.setItem('mech.language', language);
      } catch {
        /* optional persistence */
      }
      return { language };
    }),

  setLanguage: language => {
    try {
      localStorage.setItem('mech.language', language);
    } catch {
      /* optional persistence */
    }
    set({ language });
  },

  setCommandPaletteOpen: isCommandPaletteOpen => set({ isCommandPaletteOpen }),

  setTheme: theme => {
    try {
      localStorage.setItem('mech.theme', theme);
    } catch {
      /* optional persistence */
    }
    set({ theme });
  },
  setOnboardingOpen: isOnboardingOpen => set({ isOnboardingOpen }),
  updateProjectMemory: (decisions, rules) => set({ projectMemory: { decisions, rules } }),

  t: () => translations[get().language],

  ensureActiveConversation: () => {
    const state = get();
    const active = state.conversations.find(item => item.id === state.activeConversationId);
    if (active) return active;
    const conversation = createConversation(state.projectPath);
    set({
      conversations: [conversation, ...state.conversations],
      activeConversationId: conversation.id,
      ...mirrors(conversation),
    });
    return conversation;
  },

  newConversation: () => {
    const conversation = createConversation(get().projectPath);
    set(state => ({
      conversations: [conversation, ...state.conversations],
      activeConversationId: conversation.id,
      taskPrompt: '',
      ...mirrors(conversation),
    }));
    return conversation.id;
  },

  selectConversation: id => {
    const conversation = get().conversations.find(item => item.id === id);
    if (!conversation) return;
    set({ activeConversationId: id, ...mirrors(conversation) });
  },

  appendUserTurn: text => {
    const active = get().ensureActiveConversation();
    const conversation: Conversation = {
      ...active,
      title: active.turns.length === 0 ? titleFrom(text) : active.title,
      projectPath: get().projectPath || active.projectPath,
      turns: [...active.turns, { id: uid(), role: 'user', text, at: now() }],
      updatedAt: now(),
    };
    set(state => ({
      conversations: replaceConversation(state.conversations, conversation),
      ...mirrors(conversation),
    }));
  },

  beginAssistantTurn: () => {
    const active = get().ensureActiveConversation();
    const turn: ChatTurn = {
      id: uid(),
      role: 'assistant',
      text: '',
      at: now(),
      status: 'planned',
      steps: [],
      taskId: null,
      applied: false,
      error: null,
    };
    const conversation: Conversation = {
      ...active,
      status: 'planned',
      turns: [...active.turns, turn],
      updatedAt: now(),
    };
    set(state => ({
      conversations: replaceConversation(state.conversations, conversation),
      ...mirrors(conversation),
    }));
  },

  addTimelineEvent: event => {
    const state = get();
    const target =
      (event.task_id
        ? state.conversations.find(item => item.taskId === event.task_id)
        : undefined) ??
      state.conversations.find(item => item.id === state.activeConversationId);
    if (!target) return;

    const assistantIndex = findAssistantIndex(target.turns);
    const turns = [...target.turns];

    if (assistantIndex === -1) {
      turns.push({
        id: uid(),
        role: 'assistant',
        text: '',
        at: now(),
        status: event.status,
        steps: [event],
        costUsd: event.cost_usd,
        taskId: event.task_id ?? null,
        applied: false,
        error: null,
      });
    } else {
      const turn = turns[assistantIndex];
      turns[assistantIndex] = {
        ...turn,
        status: event.status,
        steps: [...(turn.steps ?? []), event],
        diff: event.diff_preview ?? turn.diff,
        costUsd: event.cost_usd,
        taskId: event.task_id ?? turn.taskId ?? null,
      };
    }

    const conversation: Conversation = {
      ...target,
      turns,
      status: event.status,
      diff: event.diff_preview ?? target.diff,
      taskId: event.task_id ?? target.taskId,
      totalCostUsd: event.cost_usd,
      updatedAt: now(),
    };

    set(current => ({
      conversations: replaceConversation(current.conversations, conversation),
      ...(conversation.id === current.activeConversationId ? mirrors(conversation) : {}),
    }));
  },

  setTaskId: (taskId, conversationId) => {
    const state = get();
    const active = conversationId
      ? state.conversations.find(item => item.id === conversationId)
      : state.conversations.find(item => item.id === state.activeConversationId);
    if (!active) return;
    const assistantIndex = findAssistantIndex(active.turns);
    const turns = [...active.turns];
    if (assistantIndex >= 0) {
      turns[assistantIndex] = { ...turns[assistantIndex], taskId };
    }
    const conversation: Conversation = {
      ...active,
      taskId,
      turns,
      updatedAt: now(),
    };
    set(current => ({
      conversations: replaceConversation(current.conversations, conversation),
      ...(conversation.id === current.activeConversationId ? mirrors(conversation) : {}),
    }));
  },

  setConversationDiff: (diff, conversationId) => {
    const state = get();
    const active = conversationId
      ? state.conversations.find(item => item.id === conversationId)
      : state.conversations.find(item => item.id === state.activeConversationId);
    if (!active) return;
    const assistantIndex = findAssistantIndex(active.turns);
    const turns = [...active.turns];
    if (assistantIndex >= 0) {
      turns[assistantIndex] = { ...turns[assistantIndex], diff };
    }
    const conversation: Conversation = { ...active, diff, turns, updatedAt: now() };
    set(current => ({
      conversations: replaceConversation(current.conversations, conversation),
      ...(conversation.id === current.activeConversationId ? mirrors(conversation) : {}),
    }));
  },

  failActiveTurn: (message, conversationId) => {
    const state = get();
    const active = conversationId
      ? state.conversations.find(item => item.id === conversationId)
      : state.conversations.find(item => item.id === state.activeConversationId);
    if (!active) return;
    const assistantIndex = findAssistantIndex(active.turns);
    const turns = [...active.turns];
    if (assistantIndex >= 0) {
      turns[assistantIndex] = {
        ...turns[assistantIndex],
        status: 'failed',
        error: message,
      };
    }
    const conversation: Conversation = {
      ...active,
      turns,
      status: 'failed',
      updatedAt: now(),
    };
    set(current => ({
      conversations: replaceConversation(current.conversations, conversation),
      ...(conversation.id === current.activeConversationId ? mirrors(conversation) : {}),
    }));
  },

  markApplied: (conversationId, turnId) => {
    const state = get();
    const target = conversationId
      ? state.conversations.find(item => item.id === conversationId)
      : state.conversations.find(item => item.id === state.activeConversationId);
    if (!target) return;

    const assistantIndex = findAssistantIndex(target.turns);
    const turns = [...target.turns];
    const index = turnId ? turns.findIndex(turn => turn.id === turnId) : assistantIndex;
    if (index >= 0) {
      turns[index] = {
        ...turns[index],
        status: 'done',
        applied: true,
      };
    }
    const conversation: Conversation = {
      ...target,
      turns,
      status: 'done',
      taskId: null,
      updatedAt: now(),
    };
    set(current => ({
      conversations: replaceConversation(current.conversations, conversation),
      ...(conversation.id === current.activeConversationId ? mirrors(conversation) : {}),
    }));
  },

  resetTask: () => {
    get().newConversation();
  },

  setCurrentDiff: diff => get().setConversationDiff(diff),
  setCurrentTaskId: taskId => get().setTaskId(taskId),
});

export const useTaskStore = create<TaskState>()(
  persist(createTaskState, {
    name: 'mech.workspace.v1',
    storage: createJSONStorage(() => workspaceStorage),
    partialize: state => ({
      conversations: state.conversations,
      activeConversationId: state.activeConversationId,
      projectPath: state.projectPath,
      selectedModel: state.selectedModel,
      budgetLimit: state.budgetLimit,
    }),
    merge: (persisted, current) => {
      const saved = (persisted ?? {}) as Partial<TaskState>;
      const rawConversations = Array.isArray(saved.conversations)
        ? saved.conversations.filter(
            conversation => conversation && Array.isArray(conversation.turns),
          )
        : [];
      const conversations = rawConversations.map(conversation =>
        isRunActive(conversation.status)
          ? {
              ...conversation,
              status: 'paused' as TaskStatus,
              turns: conversation.turns.map(turn =>
                turn.role === 'assistant' && isRunActive(turn.status)
                  ? { ...turn, status: 'paused' as TaskStatus }
                  : turn,
              ),
            }
          : conversation,
      );
      const active =
        conversations.find(conversation => conversation.id === saved.activeConversationId) ??
        conversations[0];
      return {
        ...current,
        ...saved,
        conversations,
        activeConversationId: active?.id ?? '',
        ...(active ? mirrors(active) : {}),
      };
    },
  }),
);
