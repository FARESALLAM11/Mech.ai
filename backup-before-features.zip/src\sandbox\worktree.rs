use std::path::{Path, PathBuf};
use std::process::Command;
use similar::TextDiff;

pub struct WorktreeSession {
    pub original_path: PathBuf,
    pub isolated_path: PathBuf,
    pub baseline_path: PathBuf,
    pub branch_name: String,
    pub is_git_worktree: bool,
}

impl WorktreeSession {
    pub fn create(project_path: &Path, task_id: &str) -> anyhow::Result<Self> {
        let branch_name = format!("mech-task-{}", &task_id[..8.min(task_id.len())]);
        let root = std::env::temp_dir().join("mech_sandboxes");
        let temp_dir = root.join(&branch_name);
        let baseline_dir = root.join(format!("{}-baseline", branch_name));
        for path in [&temp_dir, &baseline_dir] {
            if path.exists() { std::fs::remove_dir_all(path)?; }
        }
        std::fs::create_dir_all(&temp_dir)?;
        std::fs::create_dir_all(&baseline_dir)?;
        // Two local copies preserve the exact working-tree baseline without creating Git branches.
        copy_dir_recursive(project_path, &temp_dir)?;
        copy_dir_recursive(project_path, &baseline_dir)?;

        Ok(Self {
            original_path: project_path.to_path_buf(),
            isolated_path: temp_dir,
            baseline_path: baseline_dir,
            branch_name,
            is_git_worktree: false,
        })
    }

    pub fn open_existing(project_path: &Path, task_id: &str) -> anyhow::Result<Self> {
        let branch_name = format!("mech-task-{}", &task_id[..8.min(task_id.len())]);
        let root = std::env::temp_dir().join("mech_sandboxes");
        let isolated_path = root.join(&branch_name);
        let baseline_path = root.join(format!("{}-baseline", branch_name));
        if !isolated_path.is_dir() || !baseline_path.is_dir() { anyhow::bail!("Task sandbox or its baseline no longer exists"); }
        Ok(Self { original_path: project_path.to_path_buf(), isolated_path, baseline_path, branch_name, is_git_worktree: false })
    }

    pub fn write_file_changes(&self, files: &[(String, String)]) -> anyhow::Result<()> {
        let root = self.isolated_path.canonicalize()?;
        for (relative, content) in files {
            let rel = Path::new(relative);
            if rel.as_os_str().is_empty() || rel.components().any(|c| !matches!(c, std::path::Component::Normal(_)))
                || rel.components().next().is_some_and(|c| matches!(c, std::path::Component::Normal(name) if matches!(name.to_string_lossy().as_ref(), ".git" | "node_modules" | "target" | "dist" | ".mech"))) {
                anyhow::bail!("Unsafe or reserved file path in model response: {relative}");
            }
            let path = root.join(rel);
            if let Some(parent) = path.parent() { std::fs::create_dir_all(parent)?; }
            let parent = path.parent().ok_or_else(|| anyhow::anyhow!("File path has no parent"))?.canonicalize()?;
            if !parent.starts_with(&root) { anyhow::bail!("File path escapes task sandbox: {relative}"); }
            if path.exists() && path.canonicalize()?.starts_with(&root) == false { anyhow::bail!("File path resolves outside task sandbox: {relative}"); }
            std::fs::write(path, content)?;
        }
        Ok(())
    }

    /// Run test command in the isolated worktree
    pub fn execute_test(&self, cmd_str: &str) -> anyhow::Result<(bool, String)> {
        #[cfg(target_os = "windows")]
        let output = Command::new("cmd")
            .current_dir(&self.isolated_path)
            .args(["/c", cmd_str])
            .output()?;

        #[cfg(not(target_os = "windows"))]
        let output = Command::new("sh")
            .current_dir(&self.isolated_path)
            .args(["-c", cmd_str])
            .output()?;

        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();
        let combined = format!("{stdout}\n{stderr}");

        Ok((output.status.success(), combined))
    }

    /// Generate Unified Diff between the isolated worktree and original project
    pub fn generate_unified_diff(&self, relative_file_path: &str) -> anyhow::Result<String> {
        let original_file = self.baseline_path.join(relative_file_path);
        let modified_file = self.isolated_path.join(relative_file_path);

        let orig_content = std::fs::read_to_string(&original_file).unwrap_or_default();
        let mod_content = std::fs::read_to_string(&modified_file).unwrap_or_default();

        let diff = TextDiff::from_lines(&orig_content, &mod_content);
        let unified = diff.unified_diff()
            .header(
                &format!("a/{}", relative_file_path),
                &format!("b/{}", relative_file_path)
            )
            .to_string();

        Ok(unified)
    }

    /// Compare local project and sandbox files and return a unified diff.
    /// File contents are read locally and are never sent by this method.
    pub fn generate_unified_diff_all(&self) -> anyhow::Result<String> {
        let mut paths = std::collections::BTreeSet::new();
        collect_diff_files(&self.baseline_path, &self.baseline_path, &mut paths)?;
        collect_diff_files(&self.isolated_path, &self.isolated_path, &mut paths)?;

        let mut output = String::new();
        for relative in paths {
            let original_path = self.baseline_path.join(&relative);
            let modified_path = self.isolated_path.join(&relative);
            let original = match std::fs::read_to_string(&original_path) {
                Ok(content) => content,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => String::new(),
                Err(error) if error.kind() == std::io::ErrorKind::InvalidData => continue,
                Err(error) => return Err(error.into()),
            };
            let modified = match std::fs::read_to_string(&modified_path) {
                Ok(content) => content,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => String::new(),
                Err(error) if error.kind() == std::io::ErrorKind::InvalidData => continue,
                Err(error) => return Err(error.into()),
            };
            if original == modified { continue; }
            let diff = TextDiff::from_lines(&original, &modified)
                .unified_diff()
                .header(&format!("a/{}", relative.display()), &format!("b/{}", relative.display()))
                .to_string();
            output.push_str(&diff);
        }
        Ok(output)
    }

    /// Apply accepted changes back to original project
    pub fn accept_changes(&self, relative_file_path: &str) -> anyhow::Result<()> {
        let rel = Path::new(relative_file_path);
        if rel.as_os_str().is_empty() || rel.components().any(|c| !matches!(c, std::path::Component::Normal(_))) {
            anyhow::bail!("Unsafe accepted file path");
        }
        let root = self.isolated_path.canonicalize()?;
        let original_root = self.original_path.canonicalize()?;
        let modified_file = root.join(rel);
        let destination_file = original_root.join(rel);

        if modified_file.exists() {
            let baseline_file = self.baseline_path.join(rel);
            let baseline = std::fs::read(&baseline_file).unwrap_or_default();
            let current = std::fs::read(&destination_file).unwrap_or_default();
            if baseline != current { anyhow::bail!("The project file changed after this task began: {relative_file_path}. No changes were applied to it."); }
            if let Some(parent) = destination_file.parent() {
                std::fs::create_dir_all(parent)?;
            }
            if !modified_file.canonicalize()?.starts_with(&root) { anyhow::bail!("Sandbox source escapes task sandbox"); }
            if !destination_file.parent().ok_or_else(|| anyhow::anyhow!("Destination has no parent"))?.canonicalize()?.starts_with(&original_root) { anyhow::bail!("Destination escapes selected project"); }
            if destination_file.exists() && !destination_file.canonicalize()?.starts_with(&original_root) { anyhow::bail!("Destination file resolves outside selected project"); }
            std::fs::copy(&modified_file, &destination_file)?;
        } else {
            anyhow::bail!("Changed file missing from task sandbox: {relative_file_path}");
        }

        Ok(())
    }

    /// Apply the sandbox files represented in the current diff after explicit user review.
    pub fn accept_all_changes(&self) -> anyhow::Result<usize> {
        let diff = self.generate_unified_diff_all()?;
        let paths: std::collections::BTreeSet<String> = diff.lines()
            .filter_map(|line| line.strip_prefix("+++ b/"))
            .map(str::to_string)
            .collect();
        if paths.is_empty() { anyhow::bail!("There are no file changes to apply."); }
        for path in &paths {
            let source = self.isolated_path.join(path);
            if !source.is_file() {
                anyhow::bail!("Applying deleted files is not supported yet; no changes were applied.");
            }
            let original = self.original_path.join(path);
            let baseline = self.baseline_path.join(path);
            if std::fs::read(&original).unwrap_or_default() != std::fs::read(&baseline).unwrap_or_default() {
                anyhow::bail!("Project file changed while the task was running: {path}. No changes were applied.");
            }
        }
        for path in &paths { self.accept_changes(path)?; }
        Ok(paths.len())
    }

    /// Cleanup sandbox directory and prune worktree
    pub fn cleanup(&self) {
        if self.is_git_worktree {
            let _ = Command::new("git")
                .current_dir(&self.original_path)
                .args(["worktree", "remove", "--force", self.isolated_path.to_str().unwrap()])
                .output();
        }
        let _ = std::fs::remove_dir_all(&self.isolated_path);
        let _ = std::fs::remove_dir_all(&self.baseline_path);
    }
}

fn collect_diff_files(root: &Path, current: &Path, paths: &mut std::collections::BTreeSet<PathBuf>) -> anyhow::Result<()> {
    for entry in std::fs::read_dir(current)? {
        let entry = entry?;
        let name = entry.file_name();
        let name = name.to_string_lossy();
        if matches!(name.as_ref(), ".git" | "node_modules" | "target" | "dist" | ".mech") { continue; }
        let path = entry.path();
        let kind = entry.file_type()?;
        if kind.is_dir() {
            collect_diff_files(root, &path, paths)?;
        } else if kind.is_file() {
            paths.insert(path.strip_prefix(root)?.to_path_buf());
        }
    }
    Ok(())
}

fn copy_dir_recursive(src: &Path, dst: &Path) -> std::io::Result<()> {
    if !dst.exists() {
        std::fs::create_dir_all(dst)?;
    }
    for entry in std::fs::read_dir(src)? {
        let entry = entry?;
        let file_type = entry.file_type()?;
        let dest_path = dst.join(entry.file_name());

        // Skip .git and node_modules in recursive copy to keep it lightweight
        let fname = entry.file_name();
        let fname_str = fname.to_string_lossy();
        if matches!(fname_str.as_ref(), ".git" | "node_modules" | "target" | "dist" | ".mech") {
            continue;
        }

        if file_type.is_dir() {
            copy_dir_recursive(&entry.path(), &dest_path)?;
        } else if file_type.is_file() {
            std::fs::copy(entry.path(), dest_path)?;
        }
    }
    Ok(())
}
