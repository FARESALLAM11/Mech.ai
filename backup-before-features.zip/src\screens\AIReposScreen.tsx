import React from 'react';
import { Sparkles } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

export const AIReposScreen: React.FC = () => {
  const { language } = useTaskStore();
  const isAr = language === 'ar';
  return <section style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 900 }}>
    <div><h2 style={{ fontSize: 20, fontWeight: 700 }}>{isAr ? 'إضافات AI Repos' : 'AI Repos'}</h2>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{isAr ? 'إدارة الإضافات غير متصلة بعد.' : 'Extension management is not connected yet.'}</p></div>
    <div role="status" style={{ padding: 20, border: '1px solid var(--border-color)', borderRadius: 'var(--radius-lg)', background: 'var(--bg-card)', display: 'flex', gap: 12, alignItems: 'flex-start' }}>
      <Sparkles size={20} color="var(--color-primary)" />
      <div><strong>{isAr ? 'التثبيت غير متاح حالياً' : 'Installation is unavailable'}</strong>
        <p style={{ marginTop: 8, fontSize: 13, color: 'var(--text-secondary)' }}>{isAr ? 'لم يتم توصيل فاحص الإضافات ومثبتها بعد، لذلك لا يمكن تثبيت أو حذف أو تفعيل إضافات من هذه الصفحة.' : 'The extension scanner and installer are not wired to this page yet, so this screen cannot install, remove, or enable extensions.'}</p></div>
    </div>
  </section>;
};
