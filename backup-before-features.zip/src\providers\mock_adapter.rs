use async_trait::async_trait;
use tokio::sync::mpsc;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct MockProvider;

#[async_trait]
impl ProviderAdapter for MockProvider {
    fn id(&self) -> &str {
        "mock"
    }

    fn name(&self) -> &str {
        "Mock Provider (Deterministic Testing)"
    }

    async fn chat_stream(
        &self,
        _model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let last_msg = messages.last().map(|m| m.content.as_str()).unwrap_or("");
        
        let response_parts = if last_msg.contains("Test failed") || last_msg.contains("error") {
            vec![
                "Analyzing failure log...\n",
                "Fixing issue in login authentication handler:\n",
                "```diff\n",
                "--- a/src/auth.ts\n",
                "+++ b/src/auth.ts\n",
                "@@ -10,3 +10,3 @@\n",
                "-  if (password === null) return false;\n",
                "+  if (!password || password.trim().length === 0) return false;\n",
                "```\n",
                "All tests verified successfully."
            ]
        } else {
            vec![
                "I have analyzed the project structure and identified the problem.\n",
                "Step 1: Locating buggy validation in `auth.ts`.\n",
                "Step 2: Adding boundary null check and trimming whitespace.\n",
                "Step 3: Generating unified diff for review."
            ]
        };

        for part in response_parts {
            tokio::time::sleep(tokio::time::Duration::from_millis(25)).await;
            let _ = sender.send(StreamChunk {
                delta: part.to_string(),
                is_done: false,
                prompt_tokens: None,
                completion_tokens: None,
                cost_usd: None,
            }).await;
        }

        // Final completion chunk with cost metadata
        let _ = sender.send(StreamChunk {
            delta: String::new(),
            is_done: true,
            prompt_tokens: Some(120),
            completion_tokens: Some(65),
            cost_usd: Some(0.0003),
        }).await;

        Ok(())
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![ModelInfo {
            id: "mock-fast".into(),
            name: "Mock Fast Engine (PoC)".into(),
            provider: "mock".into(),
            context_window: 128000,
            input_price_per_m: 0.15,
            output_price_per_m: 0.60,
            supports_streaming: true,
        }])
    }

    fn count_tokens(&self, text: &str) -> usize {
        // Fast approximation: 1 token ~ 4 chars
        text.len().div_ceil(4)
    }

    fn price(&self, _model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let in_cost = (input_tokens as f64 / 1_000_000.0) * 0.15;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * 0.60;
        in_cost + out_cost
    }

    fn capabilities(&self, _model: &str) -> ProviderCapabilities {
        ProviderCapabilities {
            streaming: true,
            tool_calling: true,
            prompt_caching: false,
            context_window: 128000,
        }
    }
}
