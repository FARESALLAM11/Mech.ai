import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowUp,
  Check,
  ChevronDown,
  DollarSign,
  FolderGit2,
  LoaderCircle,
  Server,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useTaskStore } from '../store/taskStore';
import { isDesktop, listModels, type LocalModel } from '../lib/runtime';
import { basename } from '../lib/format';

interface ComposerProps {
  onSubmit: () => void;
  busy: boolean;
  focusToken?: number;
}

type Menu = 'folder' | 'model' | 'budget' | null;

export const Composer: React.FC<ComposerProps> = ({ onSubmit, busy, focusToken = 0 }) => {
  const {
    taskPrompt,
    setTaskPrompt,
    projectPath,
    setProjectPath,
    selectedModel,
    setSelectedModel,
    budgetLimit,
    setBudgetLimit,
    language,
    setCurrentScreen,
    t,
  } = useTaskStore();

  const strings = t();
  const isAr = language === 'ar';
  const preview = !isDesktop();
  const [models, setModels] = useState<LocalModel[]>([]);
  const [menu, setMenu] = useState<Menu>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    let alive = true;
    void listModels().then(list => {
      if (!alive) return;
      setModels(list);
      const current = useTaskStore.getState().selectedModel;
      if (list.length && !list.some(model => `${model.provider}::${model.id}` === current)) {
        setSelectedModel(`${list[0].provider}::${list[0].id}`);
      }
    });
    return () => {
      alive = false;
    };
  }, [setSelectedModel]);

  useEffect(() => {
    if (focusToken > 0) textareaRef.current?.focus();
  }, [focusToken]);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, [taskPrompt]);

  useEffect(() => {
    if (!menu) return;
    const onPointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setMenu(null);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenu(null);
    };
    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [menu]);

  const modelLabel = models.find(model => `${model.provider}::${model.id}` === selectedModel)?.name;
  const canSend = taskPrompt.trim().length > 0 && !busy;

  const submit = () => {
    if (!canSend) return;
    if (!preview && !projectPath.trim()) {
      setMenu('folder');
      return;
    }
    if (!preview && !selectedModel) {
      setMenu('model');
      return;
    }
    setMenu(null);
    onSubmit();
    textareaRef.current?.focus();
  };

  const toggle = (next: Exclude<Menu, null>) => setMenu(current => (current === next ? null : next));

  return (
    <div className="composer-wrap" ref={rootRef}>
      <div className="composer">
        <textarea
          ref={textareaRef}
          className="composer-textarea"
          rows={2}
          value={taskPrompt}
          onChange={event => setTaskPrompt(event.target.value)}
          onKeyDown={event => {
            if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
              event.preventDefault();
              submit();
            }
          }}
          placeholder={strings.chat.placeholder}
          aria-label={strings.chat.placeholder}
        />

        <div className="composer-toolbar">
          <div className="menu-anchor">
            <button
              type="button"
              className={`chip${projectPath ? '' : ' is-warning'}${menu === 'folder' ? ' is-active' : ''}`}
              onClick={() => toggle('folder')}
              title={projectPath || strings.chat.chooseProject}
              aria-haspopup="menu"
              aria-expanded={menu === 'folder'}
            >
              <FolderGit2 size={14} />
              <span>{projectPath ? basename(projectPath) : strings.chat.chooseProject}</span>
              <ChevronDown size={11} className="chev" />
            </button>

            {menu === 'folder' && (
              <div className="menu menu-up" role="menu">
                <div className="menu-label">{strings.chat.project}</div>
                <div className="menu-field">
                  <label htmlFor="mech-project-path">{strings.chat.chooseProject}</label>
                  <input
                    id="mech-project-path"
                    autoFocus
                    value={projectPath}
                    onChange={event => setProjectPath(event.target.value)}
                    placeholder={isAr ? 'C:\\Projects\\my-app' : 'C:\\Projects\\my-app'}
                    spellCheck={false}
                  />
                </div>
                <p className="menu-hint">{strings.chat.folderHint}</p>
                <button
                  type="button"
                  className="menu-item"
                  onClick={() => {
                    setProjectPath('fixtures/sample-project');
                    setMenu(null);
                    textareaRef.current?.focus();
                  }}
                >
                  <FolderGit2 size={14} />
                  {strings.chat.sampleProject}
                </button>
              </div>
            )}
          </div>

          <div className="menu-anchor">
            <button
              type="button"
              className={`chip${menu === 'model' ? ' is-active' : ''}`}
              onClick={() => toggle('model')}
              aria-haspopup="menu"
              aria-expanded={menu === 'model'}
            >
              <Sparkles size={14} />
              <span>{modelLabel ?? strings.chat.model}</span>
              <ChevronDown size={11} className="chev" />
            </button>

            {menu === 'model' && (
              <div className="menu menu-up" role="menu">
                <div className="menu-label">{strings.chat.model}</div>
                {models.length > 0 ? (
                  models.map(model => {
                    const value = `${model.provider}::${model.id}`;
                    const selected = value === selectedModel;
                    return (
                      <button
                        type="button"
                        key={value}
                        className="menu-item"
                        role="menuitemradio"
                        aria-checked={selected}
                        onClick={() => {
                          setSelectedModel(value);
                          setMenu(null);
                          textareaRef.current?.focus();
                        }}
                      >
                        <Sparkles size={14} />
                        <span>{model.name}</span>
                        <span className="menu-sub">{model.provider}</span>
                        {selected && <Check size={14} className="check" />}
                      </button>
                    );
                  })
                ) : (
                  <>
                    <button
                      type="button"
                      className="menu-item"
                      onClick={() => {
                        setMenu(null);
                        setCurrentScreen('providers');
                      }}
                    >
                      <Server size={14} />
                      {strings.chat.addProvider}
                    </button>
                    <p className="menu-hint">{strings.chat.noModels}</p>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="menu-anchor budget-chip">
            <button
              type="button"
              className={`chip${menu === 'budget' ? ' is-active' : ''}`}
              onClick={() => toggle('budget')}
              title={strings.chat.budget}
              aria-haspopup="menu"
              aria-expanded={menu === 'budget'}
            >
              <DollarSign size={14} />
              <span>{budgetLimit.toFixed(2)}</span>
            </button>

            {menu === 'budget' && (
              <div className="menu menu-up" role="menu">
                <div className="menu-label">{strings.chat.budget} (USD)</div>
                <div className="menu-field">
                  <input
                    type="number"
                    min="0.5"
                    max="50"
                    step="0.5"
                    autoFocus
                    value={budgetLimit}
                    onChange={event =>
                      setBudgetLimit(Math.min(50, Math.max(0.5, Number(event.target.value) || 0.5)))
                    }
                    aria-label={strings.chat.budget}
                  />
                </div>
                <p className="menu-hint">
                  {isAr
                    ? 'يتوقف Mech قبل تجاوز هذا الحد.'
                    : 'Mech stops before it goes over this limit.'}
                </p>
                <div className="menu-quick">
                  {[1, 2, 5].map(value => (
                    <button type="button" key={value} onClick={() => setBudgetLimit(value)}>
                      ${value}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <span className="composer-spacer" />

          <button
            type="button"
            className={`send-btn${busy ? ' is-busy' : ''}`}
            onClick={submit}
            disabled={!canSend}
            aria-label={busy ? strings.chat.working : strings.chat.send}
            title={busy ? strings.chat.working : strings.chat.send}
          >
            {busy ? <LoaderCircle size={17} className="spin" /> : <ArrowUp size={17} />}
          </button>
        </div>
      </div>

      <div className="composer-hint">
        {preview ? (
          <>
            <AlertCircle size={12} className="hint-warning" />
            <span className="hint-warning">{strings.chat.previewHint}</span>
          </>
        ) : (
          <>
            <ShieldCheck size={12} />
            <span>{strings.chat.privacyHint}</span>
          </>
        )}
        <span className="spacer" />
        <span className="keys">{strings.chat.keysHint}</span>
      </div>
    </div>
  );
};
