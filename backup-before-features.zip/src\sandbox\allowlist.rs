pub struct AllowlistValidator;

impl AllowlistValidator {
    /// Safe test command prefixes
    const ALLOWED_TEST_PREFIXES: &'static [&'static str] = &[
        "npm test",
        "npm run test",
        "cargo test",
        "pytest",
        "go test",
        "pnpm test",
        "yarn test",
        "node --test",
    ];

    /// Check if command is strictly within allowlist
    pub fn is_allowed(cmd: &str) -> bool {
        let trimmed = cmd.trim();

        // Immediate rejection for dangerous command injections
        let dangerous_tokens = [
            "rm -rf", "sudo", "del /f", "format", "curl ", "wget ", 
            ";", "&&", "||", "| sh", "| bash", "| powershell"
        ];
        for token in dangerous_tokens {
            if trimmed.contains(token) {
                return false;
            }
        }

        // Must match an allowed safe prefix
        Self::ALLOWED_TEST_PREFIXES.iter().any(|prefix| trimmed.starts_with(prefix))
    }
}
