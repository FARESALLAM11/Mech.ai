use async_trait::async_trait;
use tokio::sync::mpsc;
use crate::providers::openai_adapter::OpenAiCompatibleProvider;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct DeepSeekProvider {
    inner: OpenAiCompatibleProvider,
}

impl DeepSeekProvider {
    pub fn new(api_key: String) -> Self {
        Self {
            inner: OpenAiCompatibleProvider::new(
                "deepseek".into(),
                "DeepSeek AI".into(),
                "https://api.deepseek.com".into(),
                Some(api_key),
            ),
        }
    }
}

#[async_trait]
impl ProviderAdapter for DeepSeekProvider {
    fn id(&self) -> &str {
        "deepseek"
    }

    fn name(&self) -> &str {
        "DeepSeek AI (V3 & R1 Reasoning)"
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let target_model = if model.is_empty() || model == "default" {
            "deepseek-chat"
        } else {
            model
        };
        self.inner.chat_stream(target_model, messages, sender).await
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "deepseek-chat".into(),
                name: "DeepSeek V3 (Chat & Coding)".into(),
                provider: "deepseek".into(),
                context_window: 64000,
                input_price_per_m: 0.14,
                output_price_per_m: 0.28,
                supports_streaming: true,
            },
            ModelInfo {
                id: "deepseek-reasoner".into(),
                name: "DeepSeek R1 (Deep Reasoning)".into(),
                provider: "deepseek".into(),
                context_window: 64000,
                input_price_per_m: 0.55,
                output_price_per_m: 2.19,
                supports_streaming: true,
            },
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        self.inner.count_tokens(text)
    }

    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let (in_rate, out_rate) = match model {
            m if m.contains("reasoner") => (0.55, 2.19),
            _ => (0.14, 0.28),
        };
        let in_cost = (input_tokens as f64 / 1_000_000.0) * in_rate;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * out_rate;
        in_cost + out_cost
    }

    fn capabilities(&self, model: &str) -> ProviderCapabilities {
        self.inner.capabilities(model)
    }
}
