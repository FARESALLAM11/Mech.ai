use async_trait::async_trait;
use tokio::sync::mpsc;
use crate::providers::openai_adapter::OpenAiCompatibleProvider;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct GroqProvider {
    inner: OpenAiCompatibleProvider,
}

impl GroqProvider {
    pub fn new(api_key: String) -> Self {
        Self {
            inner: OpenAiCompatibleProvider::new(
                "groq".into(),
                "Groq (Ultra-Fast Inference)".into(),
                "https://api.groq.com/openai/v1".into(),
                Some(api_key),
            ),
        }
    }
}

#[async_trait]
impl ProviderAdapter for GroqProvider {
    fn id(&self) -> &str {
        "groq"
    }

    fn name(&self) -> &str {
        "Groq (Ultra-Fast Inference)"
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let target_model = if model.is_empty() || model == "default" {
            "llama-3.3-70b-versatile"
        } else {
            model
        };
        self.inner.chat_stream(target_model, messages, sender).await
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "llama-3.3-70b-versatile".into(),
                name: "Llama 3.3 70B Versatile (Groq LPU)".into(),
                provider: "groq".into(),
                context_window: 128000,
                input_price_per_m: 0.59,
                output_price_per_m: 0.79,
                supports_streaming: true,
            },
            ModelInfo {
                id: "llama-3.1-8b-instant".into(),
                name: "Llama 3.1 8B Instant (Ultra-Fast)".into(),
                provider: "groq".into(),
                context_window: 128000,
                input_price_per_m: 0.05,
                output_price_per_m: 0.08,
                supports_streaming: true,
            },
            ModelInfo {
                id: "mixtral-8x7b-32768".into(),
                name: "Mixtral 8x7B 32k".into(),
                provider: "groq".into(),
                context_window: 32768,
                input_price_per_m: 0.24,
                output_price_per_m: 0.24,
                supports_streaming: true,
            },
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        self.inner.count_tokens(text)
    }

    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let (in_rate, out_rate) = match model {
            m if m.contains("8b") => (0.05, 0.08),
            _ => (0.59, 0.79),
        };
        let in_cost = (input_tokens as f64 / 1_000_000.0) * in_rate;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * out_rate;
        in_cost + out_cost
    }

    fn capabilities(&self, model: &str) -> ProviderCapabilities {
        self.inner.capabilities(model)
    }
}
