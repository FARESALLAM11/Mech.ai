use async_trait::async_trait;
use tokio::sync::mpsc;
use crate::providers::openai_adapter::OpenAiCompatibleProvider;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct MistralProvider {
    inner: OpenAiCompatibleProvider,
}

impl MistralProvider {
    pub fn new(api_key: String) -> Self {
        Self {
            inner: OpenAiCompatibleProvider::new(
                "mistral".into(),
                "Mistral AI".into(),
                "https://api.mistral.ai/v1".into(),
                Some(api_key),
            ),
        }
    }
}

#[async_trait]
impl ProviderAdapter for MistralProvider {
    fn id(&self) -> &str {
        "mistral"
    }

    fn name(&self) -> &str {
        "Mistral AI (Codestral & Mistral Large)"
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let target_model = if model.is_empty() || model == "default" {
            "codestral-latest"
        } else {
            model
        };
        self.inner.chat_stream(target_model, messages, sender).await
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "codestral-latest".into(),
                name: "Codestral (Specialized Coding)".into(),
                provider: "mistral".into(),
                context_window: 256000,
                input_price_per_m: 0.20,
                output_price_per_m: 0.60,
                supports_streaming: true,
            },
            ModelInfo {
                id: "mistral-large-latest".into(),
                name: "Mistral Large 2".into(),
                provider: "mistral".into(),
                context_window: 128000,
                input_price_per_m: 2.00,
                output_price_per_m: 6.00,
                supports_streaming: true,
            },
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        self.inner.count_tokens(text)
    }

    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let (in_rate, out_rate) = match model {
            m if m.contains("codestral") => (0.20, 0.60),
            _ => (2.00, 6.00),
        };
        let in_cost = (input_tokens as f64 / 1_000_000.0) * in_rate;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * out_rate;
        in_cost + out_cost
    }

    fn capabilities(&self, model: &str) -> ProviderCapabilities {
        self.inner.capabilities(model)
    }
}
