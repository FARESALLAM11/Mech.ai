pub mod manifest;
pub mod detector;
pub mod installer;
pub mod hook_runner;
pub mod mcp_host;

pub use manifest::{ExtensionPermissions, ExtensionType, MechExtensionManifest};
pub use detector::ExtensionDetector;
pub use installer::ExtensionInstaller;
pub use hook_runner::HookRunner;
pub use mcp_host::{McpCallResult, McpHost, McpToolDefinition};
