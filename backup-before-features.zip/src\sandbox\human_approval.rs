use serde::{Deserialize, Serialize};
use tokio::sync::oneshot;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use crate::sandbox::policy::SensitiveAction;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalRequest {
    pub id: String,
    pub task_id: String,
    pub action: SensitiveAction,
    pub command: String,
    pub explanation: String,
    pub timestamp: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalResponse {
    pub request_id: String,
    pub approved: bool,
    pub remember_for_project: bool,
}

#[derive(Clone)]
pub struct HumanApprovalManager {
    pending: Arc<Mutex<HashMap<String, oneshot::Sender<bool>>>>,
}

impl HumanApprovalManager {
    pub fn new() -> Self {
        Self {
            pending: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Register a pending approval request and await user confirmation
    pub async fn request_approval(
        &self,
        request_id: &str,
    ) -> anyhow::Result<bool> {
        let (tx, rx) = oneshot::channel::<bool>();

        {
            let mut map = self.pending.lock().map_err(|e| anyhow::anyhow!("Lock error: {}", e))?;
            map.insert(request_id.to_string(), tx);
        }

        // Wait for user interaction or timeout after 5 minutes
        match tokio::time::timeout(std::time::Duration::from_secs(300), rx).await {
            Ok(Ok(decision)) => Ok(decision),
            Ok(Err(_)) => Ok(false), // Channel closed / dropped
            Err(_) => {
                // Timeout: default deny
                let mut map = self.pending.lock().map_err(|e| anyhow::anyhow!("Lock error: {}", e))?;
                map.remove(request_id);
                anyhow::bail!("Approval request {} timed out (default rejected)", request_id);
            }
        }
    }

    /// Deliver user decision back to the waiting task thread
    pub fn resolve_approval(&self, response: &ApprovalResponse) -> bool {
        if let Ok(mut map) = self.pending.lock() {
            if let Some(sender) = map.remove(&response.request_id) {
                let _ = sender.send(response.approved);
                return true;
            }
        }
        false
    }
}
