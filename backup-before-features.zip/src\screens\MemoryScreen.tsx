import React, { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { Download, Save, CheckCircle2, BookOpen, Scale } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

export const MemoryScreen: React.FC = () => {
  const { projectMemory, updateProjectMemory, projectPath, t } = useTaskStore();
  const strings = t();

  const [decisions, setDecisions] = useState(projectMemory.decisions);
  const [rules, setRules] = useState(projectMemory.rules);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    let active = true;
    invoke<{ decisions: string; rules: string }>('load_project_memory', { projectPath })
      .then(memory => { if (active) { setDecisions(memory.decisions); setRules(memory.rules); updateProjectMemory(memory.decisions, memory.rules); } })
      .catch(() => { if (active) setFeedback('تعذر قراءة .mech من المشروع. افتح التطبيق المكتبي واختر مسار مشروع صالح.'); });
    return () => { active = false; };
  }, [projectPath, updateProjectMemory]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await invoke('save_project_memory', { projectPath, decisions, rules });
      updateProjectMemory(decisions, rules);
      setFeedback('تم حفظ الذاكرة في .mech/ داخل المشروع.');
    } catch (error) {
      setFeedback(`فشل حفظ ذاكرة المشروع: ${error instanceof Error ? error.message : String(error)}`);
    } finally { setIsSaving(false); }
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ decisions, rules }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "mech-project-memory.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setFeedback('تم تصدير ملف الذاكرة بنجاح!');
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 700 }}>{strings.memory.title}</h2>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>{strings.memory.description}</p>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={handleExport}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 14px',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-color)',
              background: 'var(--bg-secondary)',
              fontSize: '13px',
              fontWeight: 600,
            }}
          >
            <Download size={15} />
            <span>{strings.memory.exportBtn}</span>
          </button>

          <button
            onClick={handleSave}
            disabled={isSaving}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 18px',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-primary)',
              color: 'var(--color-on-primary)',
              fontSize: '13px',
              fontWeight: 600,
            }}
          >
            <Save size={15} />
            <span>{isSaving ? 'جارٍ الحفظ…' : strings.memory.saveBtn}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div style={{
          padding: '12px 16px',
          background: 'var(--color-success-light)',
          color: 'var(--color-success)',
          borderRadius: 'var(--radius-md)',
          fontSize: '13.5px',
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
        }}>
          <CheckCircle2 size={18} />
          <span>{feedback}</span>
        </div>
      )}

      {/* Editor Columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Architectural Decisions (.mech/decisions.md) */}
        <div style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-lg)',
          padding: '18px',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '15px' }}>
            <Scale size={18} color="var(--color-primary)" />
            <span>{strings.memory.architectureDecisions} (.mech/decisions.md)</span>
          </div>
          <textarea
            rows={14}
            value={decisions}
            onChange={(e) => setDecisions(e.target.value)}
            style={{
              width: '100%',
              padding: '12px',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-color)',
              fontFamily: 'var(--font-mono)',
              fontSize: '13px',
              lineHeight: 1.6,
              background: 'var(--bg-secondary)',
              color: 'var(--text-primary)',
              resize: 'vertical',
            }}
          />
        </div>

        {/* Project Rules (.mech/rules.md) */}
        <div style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-lg)',
          padding: '18px',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '15px' }}>
            <BookOpen size={18} color="var(--color-warning)" />
            <span>{strings.memory.projectRules} (.mech/rules.md)</span>
          </div>
          <textarea
            rows={14}
            value={rules}
            onChange={(e) => setRules(e.target.value)}
            style={{
              width: '100%',
              padding: '12px',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-color)',
              fontFamily: 'var(--font-mono)',
              fontSize: '13px',
              lineHeight: 1.6,
              background: 'var(--bg-secondary)',
              color: 'var(--text-primary)',
              resize: 'vertical',
            }}
          />
        </div>
      </div>
    </div>
  );
};
