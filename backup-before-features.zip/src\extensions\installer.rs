use std::path::{Path, PathBuf};
use crate::extensions::manifest::MechExtensionManifest;

pub struct ExtensionInstaller;

impl ExtensionInstaller {
    /// Base directory for extensions: ~/.mech/extensions
    pub fn get_extensions_dir() -> PathBuf {
        let home = std::env::var("USERPROFILE")
            .or_else(|_| std::env::var("HOME"))
            .unwrap_or_else(|_| ".".into());
        let dir = Path::new(&home).join(".mech").join("extensions");
        let _ = std::fs::create_dir_all(&dir);
        dir
    }

    /// Install extension pinned to a specific commit SHA
    pub fn install_extension(
        manifest: &MechExtensionManifest,
        files: &[(&str, &str)],
    ) -> anyhow::Result<PathBuf> {
        let target_dir = Self::get_extensions_dir().join(&manifest.name);
        
        if target_dir.exists() {
            let _ = std::fs::remove_dir_all(&target_dir);
        }
        std::fs::create_dir_all(&target_dir)?;

        // Write files
        for (rel_path, content) in files {
            let file_path = target_dir.join(rel_path);
            if let Some(parent) = file_path.parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::write(&file_path, content)?;
        }

        // Save official manifest file
        let manifest_json = serde_json::to_string_pretty(manifest)?;
        std::fs::write(target_dir.join("mech-extension.json"), manifest_json)?;

        Ok(target_dir)
    }

    /// Cleanly remove an extension by deleting its directory
    pub fn remove_extension(name: &str) -> anyhow::Result<()> {
        let target_dir = Self::get_extensions_dir().join(name);
        if target_dir.exists() {
            std::fs::remove_dir_all(&target_dir)?;
        }
        Ok(())
    }

    /// List all currently installed extensions
    pub fn list_installed() -> Vec<MechExtensionManifest> {
        let mut list = Vec::new();
        let base_dir = Self::get_extensions_dir();

        if let Ok(entries) = std::fs::read_dir(base_dir) {
            for entry in entries.flatten() {
                let manifest_path = entry.path().join("mech-extension.json");
                if manifest_path.exists() {
                    if let Ok(content) = std::fs::read_to_string(manifest_path) {
                        if let Ok(parsed) = serde_json::from_str::<MechExtensionManifest>(&content) {
                            list.push(parsed);
                        }
                    }
                }
            }
        }

        list
    }
}
