use std::path::Path;
use std::sync::Arc;
use tokio::sync::mpsc;
use crate::context::ContextEngine;
use crate::engine::state_machine::{TaskContext, TaskState};
use crate::engine::task::TaskStepEvent;
use crate::providers::registry::ProviderRegistry;
use crate::providers::types::{ChatMessage, StreamChunk};
use crate::sandbox::worktree::WorktreeSession;
use crate::store::{CheckpointRecord, DatabaseStore, SecretStore, TaskRecord};

#[derive(serde::Deserialize)]
struct ModelFileChange { path: String, content: String }
#[derive(serde::Deserialize)]
struct ModelFileChangeSet { files: Vec<ModelFileChange> }

fn read_local_source_context(project_path: &Path, repo_map: &[crate::context::FileSummary]) -> anyhow::Result<String> {
    let mut output = String::new();
    for file in repo_map.iter().take(60) {
        let path = project_path.join(&file.relative_path);
        let Ok(content) = std::fs::read_to_string(path) else { continue; };
        if content.len() > 24_000 || output.len() + content.len() > 160_000 { continue; }
        output.push_str(&format!("\n--- FILE {} ---\n{}\n", file.relative_path, content));
    }
    if output.is_empty() {
        anyhow::bail!("No readable source files were found in the selected project.");
    }
    Ok(output)
}

fn parse_model_file_changes(raw: &str) -> anyhow::Result<Vec<(String, String)>> {
    let start = raw.find('{').ok_or_else(|| anyhow::anyhow!("Local model did not return the required JSON file changes."))?;
    let end = raw.rfind('}').ok_or_else(|| anyhow::anyhow!("Local model returned incomplete JSON."))?;
    let parsed: ModelFileChangeSet = serde_json::from_str(&raw[start..=end])?;
    if parsed.files.len() > 80 { anyhow::bail!("Local model returned too many file changes (maximum 80)."); }
    Ok(parsed.files.into_iter().map(|file| (file.path, file.content)).collect())
}

pub struct TaskEngineRunner {
    store: Arc<DatabaseStore>,
    registry: Arc<ProviderRegistry>,
}

impl TaskEngineRunner {
    pub fn new(store: Arc<DatabaseStore>, registry: Arc<ProviderRegistry>) -> Self {
        Self { store, registry }
    }

    /// Execute single complete end-to-end task with fallback and state machine
    pub async fn run_task(
        &self,
        task_id: &str,
        project_path: &str,
        user_prompt: &str,
        preferred_provider: &str,
        model: &str,
        budget_limit_usd: f64,
        event_sender: mpsc::Sender<TaskStepEvent>,
    ) -> anyhow::Result<String> {
        let p_path = Path::new(project_path);
        let start_time = std::time::Instant::now();
        let mut ctx = TaskContext::new(task_id.to_string(), budget_limit_usd);

        // 1. Initial State: Planned
        self.store.insert_task(&TaskRecord {
            id: task_id.to_string(),
            title: user_prompt.to_string(),
            project_path: project_path.to_string(),
            status: TaskState::Planned.as_str().to_string(),
            total_cost_usd: 0.0,
            total_tokens: 0,
            created_at: chrono::Utc::now().to_rfc3339(),
            updated_at: chrono::Utc::now().to_rfc3339(),
        })?;

        self.save_and_emit(
            task_id,
            &mut ctx,
            TaskState::Planned,
            "Analyzing project structure and constructing Repo Map...",
            None,
            start_time.elapsed().as_millis() as u64,
            &event_sender,
        ).await?;

        // 2. Build Repo Map
        let repo_map = ContextEngine::build_repo_map(p_path)?;
        let mut repo_summary = String::new();
        for file in repo_map.iter().take(25) {
            repo_summary.push_str(&format!("- {} ({} lines)\n", file.relative_path, file.line_count));
        }

        let source_context = read_local_source_context(p_path, &repo_map)?;

        // 3. State: Running (Isolated Worktree Execution)
        self.save_and_emit(
            task_id,
            &mut ctx,
            TaskState::Running,
            "Creating an isolated workspace and sending project context to the selected model...",
            None,
            start_time.elapsed().as_millis() as u64,
            &event_sender,
        ).await?;

        let worktree = WorktreeSession::create(p_path, task_id)?;

        // Execute via Provider Registry with automatic Fallback Chain
        let (stream_tx, mut stream_rx) = mpsc::channel::<StreamChunk>(32);
        let prompt_msg = vec![
            ChatMessage {
                role: "system".into(),
                content: format!("You are Mech, a local coding agent. Project structure:\n{}\n\nLocal source files:\n{}\n\nReturn only valid JSON in this exact shape: {{\"files\":[{{\"path\":\"relative/path\",\"content\":\"complete new file content\"}}]}}. Include only files that need changes. Do not use Markdown fences. Do not include absolute paths, explanations, or files outside the provided project.", repo_summary, source_context),
            },
            ChatMessage {
                role: "user".into(),
                content: user_prompt.to_string(),
            },
        ];

        let reg_clone = Arc::clone(&self.registry);
        let model_clone = model.to_string();

        // Send project context only to the provider explicitly selected for this task.
        let provider_id = preferred_provider.to_string();
        let provider_task = tokio::spawn(async move {
            let provider = reg_clone.get(&provider_id).ok_or_else(|| anyhow::anyhow!("Selected provider '{}' is unavailable. Save its API key or select an available model.", provider_id))?;
            provider.chat_stream(&model_clone, &prompt_msg, stream_tx).await?;
            Ok::<String, anyhow::Error>(provider_id)
        });

        let mut model_output = String::new();
        let mut prompt_tokens = 0i64;
        let mut completion_tokens = 0i64;
        while let Some(chunk) = stream_rx.recv().await {
            if let Some(cost) = chunk.cost_usd { ctx.add_cost(cost); }
            if let Some(tokens) = chunk.prompt_tokens { prompt_tokens += tokens; }
            if let Some(tokens) = chunk.completion_tokens { completion_tokens += tokens; }
            if !chunk.delta.is_empty() {
                model_output.push_str(&chunk.delta);
                if model_output.len() > 1_000_000 {
                    anyhow::bail!("Local model response exceeded the 1 MB safety limit.");
                }
            }
        }
        let _used_provider = provider_task.await??;
        let file_changes = parse_model_file_changes(&model_output)?;
        if file_changes.is_empty() {
            anyhow::bail!("The local model returned no file changes. No project files were modified.");
        }
        worktree.write_file_changes(&file_changes)?;

        // 4. State: Testing
        self.save_and_emit(
            task_id,
            &mut ctx,
            TaskState::Testing,
            "No test command was approved for this task; checking the isolated workspace for a real diff.",
            None,
            start_time.elapsed().as_millis() as u64,
            &event_sender,
        ).await?;

        // 5. State: Reviewing (Unified Diff Ready)
        let diff_output = worktree.generate_unified_diff_all()?;
        if diff_output.trim().is_empty() {
            anyhow::bail!("The model returned no file changes. No project files were modified.");
        }

        self.save_and_emit(
            task_id,
            &mut ctx,
            TaskState::Reviewing,
            "Real file changes are isolated and ready for human review. No tests were run automatically.",
            Some(diff_output.clone()),
            start_time.elapsed().as_millis() as u64,
            &event_sender,
        ).await?;

        self.store.add_cost_and_tokens(task_id, ctx.total_cost_usd, prompt_tokens + completion_tokens)?;

        Ok(diff_output)
    }

    /// Resume task from latest checkpoint without repeating completed steps (Section 7 & 8)
    pub async fn resume_task(
        &self,
        task_id: &str,
        event_sender: mpsc::Sender<TaskStepEvent>,
    ) -> anyhow::Result<Option<String>> {
        let cp = self.store.get_latest_checkpoint(task_id)?;
        let latest = match cp {
            Some(c) => c,
            None => anyhow::bail!("No previous checkpoint found for task {}", task_id),
        };

        let last_state = TaskState::from_str(&latest.state).unwrap_or(TaskState::Planned);
        let restored_diff: Option<String> = serde_json::from_str(&latest.payload_json).ok().flatten();

        let _ = event_sender.send(TaskStepEvent {
            task_id: task_id.to_string(),
            step_index: latest.step_index + 1,
            status: crate::engine::task::TaskStatus::Running,
            description: format!("Resuming task from checkpoint: '{}' (step {})", last_state.as_str(), latest.step_index),
            diff_preview: restored_diff.clone(),
            cost_usd: 0.0,
            duration_ms: 50,
        }).await;

        self.store.insert_log(task_id, "INFO", &format!("Resumed task from checkpoint at step {}", latest.step_index))?;

        Ok(restored_diff)
    }

    /// Pause task gracefully
    pub async fn pause_task(&self, task_id: &str) -> anyhow::Result<()> {
        let cp = self.store.get_latest_checkpoint(task_id)?;
        let step_index = cp.as_ref().map(|c| c.step_index + 1).unwrap_or(1);

        let pause_cp = CheckpointRecord {
            id: uuid::Uuid::new_v4().to_string(),
            task_id: task_id.to_string(),
            step_index,
            state: TaskState::Paused.as_str().to_string(),
            payload_json: "{}".to_string(),
            created_at: chrono::Utc::now().to_rfc3339(),
        };

        self.store.save_checkpoint(&pause_cp)?;
        self.store.update_task_status(task_id, TaskState::Paused.as_str())?;
        self.store.insert_log(task_id, "WARN", "Task execution paused by user.")?;

        Ok(())
    }

    async fn save_and_emit(
        &self,
        task_id: &str,
        ctx: &mut TaskContext,
        target_state: TaskState,
        desc: &str,
        diff: Option<String>,
        duration: u64,
        event_sender: &mpsc::Sender<TaskStepEvent>,
    ) -> anyhow::Result<()> {
        ctx.transition(target_state)?;

        let cp = CheckpointRecord {
            id: uuid::Uuid::new_v4().to_string(),
            task_id: task_id.to_string(),
            step_index: ctx.step_index,
            state: target_state.as_str().to_string(),
            payload_json: serde_json::to_string(&diff)?,
            created_at: chrono::Utc::now().to_rfc3339(),
        };
        self.store.save_checkpoint(&cp)?;
        self.store.update_task_status(task_id, target_state.as_str())?;

        let ui_status = match target_state {
            TaskState::Planned => crate::engine::task::TaskStatus::Planned,
            TaskState::Running => crate::engine::task::TaskStatus::Running,
            TaskState::Testing => crate::engine::task::TaskStatus::Testing,
            TaskState::Reviewing => crate::engine::task::TaskStatus::Reviewing,
            TaskState::Done => crate::engine::task::TaskStatus::Done,
            TaskState::Failed => crate::engine::task::TaskStatus::Failed,
            TaskState::Paused => crate::engine::task::TaskStatus::Paused,
        };

        let _ = event_sender.send(TaskStepEvent {
            task_id: task_id.to_string(),
            step_index: ctx.step_index,
            status: ui_status,
            description: desc.to_string(),
            diff_preview: diff,
            cost_usd: ctx.total_cost_usd,
            duration_ms: duration,
        }).await;

        Ok(())
    }
}
