import React from 'react';
import { Coins, Clock, ShieldCheck } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

export const CostBadge: React.FC = () => {
  const { totalCostUsd, currentStatus, language } = useTaskStore();

  const isArabic = language === 'ar';

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      padding: '8px 16px',
      background: 'var(--bg-secondary)',
      border: '1px solid var(--border-color)',
      borderRadius: 'var(--radius-md)',
      fontSize: '13px',
      fontWeight: 500,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--color-primary)' }}>
        <Coins size={16} />
        <span>{isArabic ? 'التكلفة الإجمالية:' : 'Total Cost:'}</span>
        <strong style={{ color: 'var(--text-primary)' }}>${totalCostUsd.toFixed(4)}</strong>
      </div>

      <div style={{ width: '1px', height: '16px', background: 'var(--border-color)' }} />

      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--color-success)' }}>
        <ShieldCheck size={16} />
        <span>{isArabic ? 'العزل: محمي' : 'Sandbox: Isolated'}</span>
      </div>

      <div style={{ width: '1px', height: '16px', background: 'var(--border-color)' }} />

      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)' }}>
        <Clock size={16} />
        <span style={{ textTransform: 'capitalize' }}>{currentStatus}</span>
      </div>
    </div>
  );
};
