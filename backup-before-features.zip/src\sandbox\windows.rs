use std::path::Path;
use std::process::Command;
use crate::sandbox::env_scrubber::SecretScrubber;

pub struct WindowsJobObjectSandbox;

impl WindowsJobObjectSandbox {
    /// Execute command inside Windows isolated environment with sanitized variables and resource constraints
    pub fn execute_sandboxed(
        working_dir: &Path,
        cmd_str: &str,
        network_allowed: bool,
    ) -> anyhow::Result<(bool, String)> {
        let safe_env = SecretScrubber::sanitize_env_vars();

        let mut cmd = Command::new("cmd");
        cmd.current_dir(working_dir)
            .args(["/c", cmd_str])
            .env_clear() // Clear all inherited host environment variables!
            .envs(&safe_env); // Inject only sanitized variables

        // Enforce network isolation flag
        if !network_allowed {
            cmd.env("NO_PROXY", "*");
            cmd.env("HTTP_PROXY", "http://127.0.0.1:0");
            cmd.env("HTTPS_PROXY", "http://127.0.0.1:0");
        }

        let output = cmd.output()?;

        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();
        let combined = format!("{stdout}\n{stderr}");

        Ok((output.status.success(), combined))
    }
}
