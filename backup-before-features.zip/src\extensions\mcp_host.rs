use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct McpToolDefinition {
    pub name: String,
    pub description: String,
    pub input_schema_json: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct McpCallResult {
    pub is_error: bool,
    pub content: String,
}

pub struct McpHost;

impl McpHost {
    /// Formats a tool call for MCP JSON-RPC protocol
    pub fn build_jsonrpc_request(tool_name: &str, arguments_json: &str, req_id: u64) -> String {
        format!(
            r#"{{"jsonrpc":"2.0","id":{},"method":"tools/call","params":{{"name":"{}","arguments":{}}}}}"#,
            req_id, tool_name, arguments_json
        )
    }

    /// Parses MCP response content
    pub fn parse_jsonrpc_response(raw_json: &str) -> Option<McpCallResult> {
        let val: serde_json::Value = serde_json::from_str(raw_json).ok()?;
        if let Some(err) = val.get("error") {
            return Some(McpCallResult {
                is_error: true,
                content: err.to_string(),
            });
        }

        let content = val["result"]["content"][0]["text"].as_str().unwrap_or("ok");
        Some(McpCallResult {
            is_error: false,
            content: content.to_string(),
        })
    }
}
