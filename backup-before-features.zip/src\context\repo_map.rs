use std::path::Path;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FileSummary {
    pub relative_path: String,
    pub line_count: usize,
}

pub struct ContextEngine;

impl ContextEngine {
    /// Builds a lightweight Repo Map of the target project
    pub fn build_repo_map(project_path: &Path) -> anyhow::Result<Vec<FileSummary>> {
        let mut summaries = Vec::new();
        Self::scan_dir(project_path, project_path, &mut summaries)?;
        // Sort by path for determinism
        summaries.sort_by(|a, b| a.relative_path.cmp(&b.relative_path));
        Ok(summaries)
    }

    fn scan_dir(base: &Path, current: &Path, list: &mut Vec<FileSummary>) -> anyhow::Result<()> {
        if !current.exists() || !current.is_dir() {
            return Ok(());
        }

        for entry in std::fs::read_dir(current)? {
            let entry = entry?;
            let path = entry.path();
            let fname = entry.file_name();
            let fname_str = fname.to_string_lossy();

            // Ignore common heavy folders
            if fname_str.starts_with('.') || fname_str == "node_modules" || fname_str == "target" || fname_str == "dist" {
                continue;
            }

            let file_type = entry.file_type()?;
            if file_type.is_dir() {
                Self::scan_dir(base, &path, list)?;
            } else if file_type.is_file() {
                // Focus on code and configuration files
                let ext = path.extension().and_then(|s| s.to_str()).unwrap_or("");
                if matches!(ext, "ts" | "tsx" | "js" | "jsx" | "rs" | "py" | "go" | "json" | "toml" | "html" | "css" | "scss" | "vue" | "svelte" | "yaml" | "yml" | "md" | "sql" | "sh" | "bat" | "c" | "cpp" | "h" | "cs" | "java" | "rb" | "php" | "xml") {
                    let rel = path.strip_prefix(base)?.to_string_lossy().to_string();
                    let content = std::fs::read_to_string(&path).unwrap_or_default();
                    list.push(FileSummary {
                        relative_path: rel,
                        line_count: content.lines().count(),
                    });
                }
            }
        }
        Ok(())
    }
}
