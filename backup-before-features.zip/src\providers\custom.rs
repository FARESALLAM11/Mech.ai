use async_trait::async_trait;
use tokio::sync::mpsc;
use crate::providers::openai_adapter::OpenAiCompatibleProvider;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct CustomProvider {
    inner: OpenAiCompatibleProvider,
}

impl CustomProvider {
    pub fn new(id: String, name: String, base_url: String, api_key: Option<String>) -> Self {
        Self {
            inner: OpenAiCompatibleProvider::new(id, name, base_url, api_key),
        }
    }
}

#[async_trait]
impl ProviderAdapter for CustomProvider {
    fn id(&self) -> &str {
        self.inner.id()
    }

    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        self.inner.chat_stream(model, messages, sender).await
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "custom-default".into(),
                name: format!("{} Default Model", self.inner.name()),
                provider: self.inner.id().to_string(),
                context_window: 128000,
                input_price_per_m: 0.50,
                output_price_per_m: 1.50,
                supports_streaming: true,
            }
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        self.inner.count_tokens(text)
    }

    fn price(&self, _model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let in_cost = (input_tokens as f64 / 1_000_000.0) * 0.50;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * 1.50;
        in_cost + out_cost
    }

    fn capabilities(&self, model: &str) -> ProviderCapabilities {
        self.inner.capabilities(model)
    }
}
