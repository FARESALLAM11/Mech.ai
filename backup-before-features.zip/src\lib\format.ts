export const basename = (path: string) =>
  path.split(/[\\/]/).filter(Boolean).pop() ?? '';

export const formatCost = (cost: number | undefined) => {
  if (!cost || cost <= 0) return '';
  return cost < 0.01 ? `$${cost.toFixed(4)}` : `$${cost.toFixed(2)}`;
};

export const formatDuration = (ms: number | undefined) => {
  if (!ms || ms <= 0) return '';
  return ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${Math.round(ms)}ms`;
};

export const relativeTime = (timestamp: number, isArabic: boolean, now = Date.now()) => {
  const diff = Math.max(0, now - timestamp);
  const minutes = Math.floor(diff / 60_000);
  if (minutes < 1) return isArabic ? 'الآن' : 'just now';
  if (minutes < 60) return isArabic ? `قبل ${minutes} د` : `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return isArabic ? `قبل ${hours} س` : `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return isArabic ? 'أمس' : 'yesterday';
  if (days < 7) return isArabic ? `قبل ${days} أيام` : `${days}d ago`;
  return new Date(timestamp).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', {
    month: 'short',
    day: 'numeric',
  });
};
