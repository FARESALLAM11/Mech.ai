use async_trait::async_trait;
use tokio::sync::mpsc;
use crate::providers::types::{ChatMessage, StreamChunk, ModelInfo, ProviderCapabilities};

#[async_trait]
pub trait ProviderAdapter: Send + Sync {
    /// Unique provider identifier (e.g. "openai", "anthropic", "ollama", "mock")
    fn id(&self) -> &str;

    /// Provider human-readable display name
    fn name(&self) -> &str;

    /// Stream completions via channel sender
    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()>;

    /// List available models dynamically
    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>>;

    /// Token counter for prompt budgeting
    fn count_tokens(&self, text: &str) -> usize;

    /// Calculate real cost based on input/output tokens
    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64;

    /// Provider capabilities
    fn capabilities(&self, model: &str) -> ProviderCapabilities;
}
