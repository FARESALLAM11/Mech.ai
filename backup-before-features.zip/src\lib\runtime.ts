import { invoke } from '@tauri-apps/api/core';

export interface LocalModel {
  id: string;
  name: string;
  provider: string;
}

export interface StartTaskResult {
  task_id: string;
  diff: string;
}

export const PREVIEW_MODELS: LocalModel[] = [
  { id: 'llama3.2', name: 'Llama 3.2', provider: 'ollama' },
  { id: 'qwen2.5-coder', name: 'Qwen2.5 Coder', provider: 'ollama' },
];

/** True when the UI is hosted by the Tauri shell rather than a browser tab. */
export const isDesktop = () =>
  typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

export async function listModels(): Promise<LocalModel[]> {
  if (!isDesktop()) return PREVIEW_MODELS;
  try {
    return await invoke<LocalModel[]>('list_available_models');
  } catch {
    return [];
  }
}

export async function startTask(input: {
  projectPath: string;
  prompt: string;
  preferredProvider: string;
  model: string;
  budgetLimit: number;
}): Promise<StartTaskResult> {
  return invoke<StartTaskResult>('start_task', input);
}

export async function acceptTaskChanges(
  projectPath: string,
  taskId: string,
): Promise<number> {
  return invoke<number>('accept_task_changes', { projectPath, taskId });
}
