use std::sync::Arc;
use tauri::{AppHandle, Emitter, State};
use tokio::sync::mpsc;

pub mod context;
pub mod engine;
pub mod extensions;
pub mod providers;
pub mod sandbox;
pub mod store;

use engine::{TaskEngineRunner, TaskStepEvent};
use providers::{
    AnthropicProvider, DeepSeekProvider, GeminiProvider, GroqProvider, MistralProvider, ModelInfo,
    OllamaProvider, OpenAiCompatibleProvider, ProviderAdapter, ProviderRegistry,
};
use store::{DatabaseStore, SecretStore, TaskRecord};

pub struct AppState {
    pub db: Arc<DatabaseStore>,
    pub registry: Arc<ProviderRegistry>,
}

#[derive(serde::Serialize)]
pub struct ProviderKeyStatus {
    pub id: String,
    pub configured: bool,
    pub masked_key: Option<String>,
}

#[derive(serde::Serialize, serde::Deserialize)]
pub struct ProjectMemory {
    pub decisions: String,
    pub rules: String,
}

fn project_memory_dir(project_path: &str) -> Result<std::path::PathBuf, String> {
    let project = std::path::Path::new(project_path);
    if !project.is_dir() {
        return Err("Project folder does not exist or is not a directory".into());
    }
    let canonical_project = project.canonicalize().map_err(|e| e.to_string())?;
    let memory = canonical_project.join(".mech");
    std::fs::create_dir_all(&memory).map_err(|e| e.to_string())?;
    let canonical_memory = memory.canonicalize().map_err(|e| e.to_string())?;
    if !canonical_memory.starts_with(&canonical_project) {
        return Err("Project memory folder resolves outside the selected project".into());
    }
    Ok(canonical_memory)
}

#[tauri::command]
fn load_project_memory(project_path: String) -> Result<ProjectMemory, String> {
    let dir = project_memory_dir(&project_path)?;
    let read = |name: &str, default: &str| {
        std::fs::read_to_string(dir.join(name))
            .or_else(|e| {
                if e.kind() == std::io::ErrorKind::NotFound {
                    Ok(default.to_string())
                } else {
                    Err(e)
                }
            })
            .map_err(|e| e.to_string())
    };
    Ok(ProjectMemory {
        decisions: read("decisions.md", "# Architectural Decisions\n")?,
        rules: read("rules.md", "# Project Rules\n")?,
    })
}

#[tauri::command]
fn save_project_memory(
    project_path: String,
    decisions: String,
    rules: String,
) -> Result<(), String> {
    let dir = project_memory_dir(&project_path)?;
    std::fs::write(dir.join("decisions.md"), decisions).map_err(|e| e.to_string())?;
    std::fs::write(dir.join("rules.md"), rules).map_err(|e| e.to_string())
}

fn register_key_provider(
    registry: &ProviderRegistry,
    provider_id: &str,
    key: String,
) -> Result<(), String> {
    let provider: Arc<dyn ProviderAdapter> = match provider_id {
        "openai" => Arc::new(OpenAiCompatibleProvider::new(
            "openai".into(),
            "OpenAI".into(),
            "https://api.openai.com/v1".into(),
            Some(key),
        )),
        "anthropic" => Arc::new(AnthropicProvider::new(key)),
        "gemini" => Arc::new(GeminiProvider::new(key)),
        "groq" => Arc::new(GroqProvider::new(key)),
        "deepseek" => Arc::new(DeepSeekProvider::new(key)),
        "mistral" => Arc::new(MistralProvider::new(key)),
        _ => return Err(format!("Unsupported provider: {provider_id}")),
    };
    registry.register(provider);
    Ok(())
}

#[derive(serde::Serialize)]
pub struct TaskRunResult { pub task_id: String, pub diff: String }

#[tauri::command]
async fn start_task(
    app: AppHandle,
    state: State<'_, AppState>,
    project_path: String,
    prompt: String,
    preferred_provider: Option<String>,
    model: Option<String>,
    budget_limit: Option<f64>,
) -> Result<TaskRunResult, String> {
    let task_id = uuid::Uuid::new_v4().to_string();
    let runner = TaskEngineRunner::new(Arc::clone(&state.db), Arc::clone(&state.registry));

    let (tx, mut rx) = mpsc::channel::<TaskStepEvent>(16);

    let app_handle = app.clone();
    tokio::spawn(async move {
        while let Some(event) = rx.recv().await {
            let _ = app_handle.emit("task-event", &event);
        }
    });

    let pref =
        preferred_provider.ok_or_else(|| "Choose a provider before starting a task".to_string())?;
    let mdl = model.unwrap_or_else(|| "default".into());
    let budget = budget_limit.unwrap_or(2.0);

    let diff = runner
        .run_task(&task_id, &project_path, &prompt, &pref, &mdl, budget, tx)
        .await
        .map_err(|e| e.to_string())?;

    Ok(TaskRunResult { task_id, diff })
}

#[tauri::command]
fn accept_task_changes(
    state: State<'_, AppState>,
    project_path: String,
    task_id: String,
) -> Result<usize, String> {
    let record = state.db.list_tasks().map_err(|e| e.to_string())?
        .into_iter().find(|task| task.id == task_id)
        .ok_or_else(|| "Task record was not found.".to_string())?;
    if record.status != "reviewing" {
        return Err("Only a task with a reviewable diff can be applied.".into());
    }
    let recorded_path = std::path::Path::new(&record.project_path).canonicalize().map_err(|e| e.to_string())?;
    let requested_path = std::path::Path::new(&project_path).canonicalize().map_err(|e| e.to_string())?;
    if recorded_path != requested_path {
        return Err("Selected project path does not match the project used for this task.".into());
    }
    let worktree = crate::sandbox::worktree::WorktreeSession::open_existing(&recorded_path, &task_id)
        .map_err(|e| e.to_string())?;
    worktree.accept_all_changes().map_err(|e| e.to_string())
}

#[tauri::command]
async fn resume_task(
    app: AppHandle,
    state: State<'_, AppState>,
    task_id: String,
) -> Result<Option<String>, String> {
    let runner = TaskEngineRunner::new(Arc::clone(&state.db), Arc::clone(&state.registry));
    let (tx, mut rx) = mpsc::channel::<TaskStepEvent>(16);

    let app_handle = app.clone();
    tokio::spawn(async move {
        while let Some(event) = rx.recv().await {
            let _ = app_handle.emit("task-event", &event);
        }
    });

    runner
        .resume_task(&task_id, tx)
        .await
        .map_err(|e| e.to_string())
}

#[tauri::command]
async fn pause_task(state: State<'_, AppState>, task_id: String) -> Result<(), String> {
    let runner = TaskEngineRunner::new(Arc::clone(&state.db), Arc::clone(&state.registry));
    runner.pause_task(&task_id).await.map_err(|e| e.to_string())
}

#[tauri::command]
async fn list_available_models(state: State<'_, AppState>) -> Result<Vec<ModelInfo>, String> {
    Ok(state.registry.list_all_models().await)
}

#[tauri::command]
fn store_api_key(
    state: State<'_, AppState>,
    provider_id: String,
    key_value: String,
) -> Result<String, String> {
    if key_value.trim().is_empty() || key_value.chars().any(char::is_control) {
        return Err("API key is empty or contains invalid control characters".into());
    }
    let key_value = key_value.trim().to_string();
    SecretStore::set_secret(&provider_id, &key_value)
        .map_err(|e| format!("Could not save key in the operating system credential store: {e}"))?;
    register_key_provider(&state.registry, &provider_id, key_value.clone())?;
    Ok(SecretStore::mask_key(&key_value))
}

#[tauri::command]
fn get_provider_key_status() -> Vec<ProviderKeyStatus> {
    [
        "openai",
        "anthropic",
        "gemini",
        "groq",
        "deepseek",
        "mistral",
    ]
    .iter()
    .map(|id| match SecretStore::get_secret(id) {
        Ok(key) => ProviderKeyStatus {
            id: (*id).into(),
            configured: true,
            masked_key: Some(SecretStore::mask_key(&key)),
        },
        Err(_) => ProviderKeyStatus {
            id: (*id).into(),
            configured: false,
            masked_key: None,
        },
    })
    .collect()
}

#[tauri::command]
async fn test_provider_connection(
    provider_id: String,
    key_value: Option<String>,
) -> Result<String, String> {
    let key = match key_value.filter(|k| !k.trim().is_empty()) {
        Some(key) => key.trim().to_string(),
        None => SecretStore::get_secret(&provider_id)
            .map_err(|_| "No API key is saved for this provider".to_string())?,
    };
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(12))
        .build()
        .map_err(|e| e.to_string())?;
    let response = match provider_id.as_str() {
        "openai" => {
            client
                .get("https://api.openai.com/v1/models")
                .bearer_auth(&key)
                .send()
                .await
        }
        "groq" => {
            client
                .get("https://api.groq.com/openai/v1/models")
                .bearer_auth(&key)
                .send()
                .await
        }
        "deepseek" => {
            client
                .get("https://api.deepseek.com/models")
                .bearer_auth(&key)
                .send()
                .await
        }
        "mistral" => {
            client
                .get("https://api.mistral.ai/v1/models")
                .bearer_auth(&key)
                .send()
                .await
        }
        "anthropic" => {
            client
                .get("https://api.anthropic.com/v1/models?limit=1")
                .header("x-api-key", &key)
                .header("anthropic-version", "2023-06-01")
                .send()
                .await
        }
        "gemini" => {
            client
                .get("https://generativelanguage.googleapis.com/v1beta/models")
                .header("x-goog-api-key", &key)
                .send()
                .await
        }
        _ => return Err(format!("Unsupported provider: {provider_id}")),
    }
    .map_err(|e| format!("Connection failed: {e}"))?;
    if response.status().is_success() {
        Ok("Connection successful".into())
    } else {
        Err(format!("Provider rejected the request (HTTP {}). Check the key and provider account permissions.", response.status()))
    }
}

#[tauri::command]
fn delete_provider_key(state: State<'_, AppState>, provider_id: String) -> Result<(), String> {
    SecretStore::delete_secret(&provider_id)
        .map_err(|e| format!("Could not delete the key: {e}"))?;
    state.registry.unregister(&provider_id);
    Ok(())
}

#[tauri::command]
fn set_provider_budget(
    state: State<'_, AppState>,
    provider_id: String,
    limit_usd: f64,
) -> Result<(), String> {
    state
        .db
        .set_provider_budget(&provider_id, limit_usd)
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn list_task_records(state: State<'_, AppState>) -> Result<Vec<TaskRecord>, String> {
    state.db.list_tasks().map_err(|e| e.to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let home = std::env::var("USERPROFILE")
        .or_else(|_| std::env::var("HOME"))
        .unwrap_or_else(|_| ".".into());
    let db_dir = std::path::Path::new(&home).join(".mech");
    let _ = std::fs::create_dir_all(&db_dir);
    let db_path = db_dir.join("mech.db");

    let db = DatabaseStore::new(db_path)
        .unwrap_or_else(|_| DatabaseStore::new_in_memory().expect("In memory DB"));

    let mut registry = ProviderRegistry::new();

    // Register Ollama (Local - auto discovers port 11434)
    registry.register(Arc::new(OllamaProvider::new()));

    // Register OpenAI
    if let Ok(key) = SecretStore::get_secret("openai") {
        registry.register(Arc::new(OpenAiCompatibleProvider::new(
            "openai".into(),
            "OpenAI".into(),
            "https://api.openai.com/v1".into(),
            Some(key),
        )));
    }

    // Register Anthropic
    if let Ok(key) = SecretStore::get_secret("anthropic") {
        registry.register(Arc::new(AnthropicProvider::new(key)));
    }

    // Register Gemini
    if let Ok(key) = SecretStore::get_secret("gemini") {
        registry.register(Arc::new(GeminiProvider::new(key)));
    }

    // Register Groq
    if let Ok(key) = SecretStore::get_secret("groq") {
        registry.register(Arc::new(GroqProvider::new(key)));
    }
    if let Ok(key) = SecretStore::get_secret("deepseek") {
        registry.register(Arc::new(DeepSeekProvider::new(key)));
    }
    if let Ok(key) = SecretStore::get_secret("mistral") {
        registry.register(Arc::new(MistralProvider::new(key)));
    }

    // Set fallback priority order
    registry.set_fallback_chain(vec![
        "anthropic".into(),
        "openai".into(),
        "gemini".into(),
        "groq".into(),
        "ollama".into(),
    ]);

    let state = AppState {
        db: Arc::new(db),
        registry: Arc::new(registry),
    };

    tauri::Builder::default()
        .manage(state)
        .invoke_handler(tauri::generate_handler![
            start_task,
            accept_task_changes,
            resume_task,
            pause_task,
            list_available_models,
            store_api_key,
            get_provider_key_status,
            test_provider_connection,
            delete_provider_key,
            load_project_memory,
            save_project_memory,
            set_provider_budget,
            list_task_records
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
