import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  BarChart3,
  Bot,
  BrainCircuit,
  FileDiff,
  FlaskConical,
  FolderGit2,
  Languages,
  MoreHorizontal,
  Moon,
  Package,
  PanelLeftClose,
  Plus,
  Search,
  Server,
  Settings2,
  Sun,
} from 'lucide-react';
import mechMark from '../mech-mark.svg';
import { useTaskStore, type ScreenId } from '../store/taskStore';
import { basename, relativeTime } from '../lib/format';
import { parseDiff } from '../lib/diff';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  open: boolean;
  onNavigate: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  onToggleCollapse,
  open,
  onNavigate,
  theme,
  onToggleTheme,
}) => {
  const {
    conversations,
    activeConversationId,
    currentScreen,
    projectPath,
    currentDiff,
    language,
    setCurrentScreen,
    setCommandPaletteOpen,
    newConversation,
    selectConversation,
    toggleLanguage,
    t,
  } = useTaskStore();

  const strings = t();
  const isAr = language === 'ar';
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!moreOpen) return;
    const onPointerDown = (event: MouseEvent) => {
      if (!moreRef.current?.contains(event.target as Node)) setMoreOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMoreOpen(false);
    };
    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [moreOpen]);

  const recent = useMemo(
    () =>
      conversations
        .filter(conversation => conversation.turns.length > 0)
        .slice()
        .sort((a, b) => b.updatedAt - a.updatedAt),
    [conversations],
  );

  const changedFiles = useMemo(() => parseDiff(currentDiff).files.length, [currentDiff]);

  const startNewTask = () => {
    newConversation();
    setCurrentScreen('tasks');
    onNavigate();
  };

  const go = (screen: ScreenId) => {
    setCurrentScreen(screen);
    onNavigate();
  };

  const navItems: Array<{ id: ScreenId; label: string; icon: React.ReactNode; count?: number }> = [
    {
      id: 'diff',
      label: isAr ? 'التغييرات' : 'Changes',
      icon: <FileDiff size={16} />,
      count: changedFiles || undefined,
    },
    { id: 'providers', label: isAr ? 'المزودون' : 'Providers', icon: <Server size={16} /> },
    { id: 'memory', label: isAr ? 'ذاكرة المشروع' : 'Memory', icon: <BrainCircuit size={16} /> },
    { id: 'settings', label: isAr ? 'الإعدادات' : 'Settings', icon: <Settings2 size={16} /> },
  ];

  return (
    <aside
      className={`sidebar${collapsed ? ' is-collapsed' : ''}${open ? ' is-open' : ''}`}
      aria-label={isAr ? 'مساحة العمل' : 'Workspace'}
    >
      <div className="brand-row">
        {collapsed ? (
          <button
            type="button"
            className="brand-mark-btn"
            onClick={onToggleCollapse}
            title={isAr ? 'فتح الشريط الجانبي' : 'Expand sidebar'}
            aria-label={isAr ? 'فتح الشريط الجانبي' : 'Expand sidebar'}
          >
            <img className="brand-mark" src={mechMark} alt="Mech" width={27} height={27} />
          </button>
        ) : (
          <>
            <img className="brand-mark" src={mechMark} alt="" width={27} height={27} />
            <span className="brand-name">Mech</span>
            <button
              type="button"
              className="icon-btn brand-collapse"
              onClick={onToggleCollapse}
              title={isAr ? 'طي الشريط الجانبي' : 'Collapse sidebar'}
              aria-label={isAr ? 'طي الشريط الجانبي' : 'Collapse sidebar'}
            >
              <PanelLeftClose size={16} />
            </button>
          </>
        )}
      </div>

      <div className="sidebar-actions">
        <button type="button" className="new-task" onClick={startNewTask} aria-label={strings.chat.newTask}>
          <Plus size={16} />
          <span>{strings.chat.newTask}</span>
          <kbd>Ctrl N</kbd>
        </button>
        <button
          type="button"
          className="sidebar-search"
          onClick={() => setCommandPaletteOpen(true)}
          aria-label={strings.chat.search}
        >
          <Search size={15} />
          <span>{strings.chat.search}</span>
          <kbd>Ctrl K</kbd>
        </button>
      </div>

      <div className="sidebar-scroll">
        <div className="section-label">{strings.chat.recent}</div>
        <div className="thread-list">
          {recent.length === 0 ? (
            <p className="sidebar-empty">{strings.chat.recentsEmpty}</p>
          ) : (
            recent.map(conversation => (
              <button
                type="button"
                key={conversation.id}
                className={`thread-item${conversation.id === activeConversationId ? ' is-active' : ''}`}
                onClick={() => {
                  selectConversation(conversation.id);
                  setCurrentScreen('tasks');
                  onNavigate();
                }}
                title={conversation.title}
                aria-label={conversation.title}
              >
                <span className="thread-dot" data-status={conversation.status} />
                <span className="thread-body">
                  <span className="thread-title">{conversation.title}</span>
                  <span className="thread-time">
                    {relativeTime(conversation.updatedAt, isAr)}
                  </span>
                </span>
              </button>
            ))
          )}
        </div>
      </div>

      <nav className="sidebar-nav" aria-label={isAr ? 'التنقل' : 'Navigation'}>
        {navItems.map(item => (
          <button
            type="button"
            key={item.id}
            className={`nav-item${currentScreen === item.id ? ' is-active' : ''}`}
            onClick={() => go(item.id)}
            aria-current={currentScreen === item.id ? 'page' : undefined}
            title={item.label}
            aria-label={item.label}
          >
            {item.icon}
            <span>{item.label}</span>
            {item.count ? <span className="count">{item.count}</span> : null}
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="project-chip" title={projectPath || strings.chat.chooseProject}>
          <FolderGit2 size={15} />
          <span>{projectPath ? basename(projectPath) : strings.chat.chooseProject}</span>
        </div>

        <button
          type="button"
          className="icon-btn keep"
          onClick={onToggleTheme}
          title={theme === 'dark' ? (isAr ? 'الوضع الفاتح' : 'Light theme') : isAr ? 'الوضع الداكن' : 'Dark theme'}
          aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
        >
          {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
        </button>

        <div className="menu-anchor" ref={moreRef}>
          <button
            type="button"
            className="icon-btn keep"
            onClick={() => setMoreOpen(value => !value)}
            aria-haspopup="menu"
            aria-expanded={moreOpen}
            aria-label={isAr ? 'المزيد' : 'More'}
            title={isAr ? 'المزيد' : 'More'}
          >
            <MoreHorizontal size={16} />
          </button>

          {moreOpen && (
            <div className="menu menu-up-end more-menu" role="menu">
              <button
                type="button"
                className="menu-item"
                onClick={() => {
                  go('agents');
                  setMoreOpen(false);
                }}
              >
                <Bot size={15} />
                {isAr ? 'الوكلاء' : 'Agents'}
              </button>
              <button
                type="button"
                className="menu-item"
                onClick={() => {
                  go('analytics');
                  setMoreOpen(false);
                }}
              >
                <BarChart3 size={15} />
                {isAr ? 'التكلفة والإحصاءات' : 'Cost & analytics'}
              </button>
              <button
                type="button"
                className="menu-item"
                onClick={() => {
                  go('aiRepos');
                  setMoreOpen(false);
                }}
              >
                <Package size={15} />
                {isAr ? 'إضافات AI Repos' : 'AI repos'}
              </button>
              <button
                type="button"
                className="menu-item"
                onClick={() => {
                  go('beta');
                  setMoreOpen(false);
                }}
              >
                <FlaskConical size={15} />
                {isAr ? 'التجربة المغلقة' : 'Closed beta'}
              </button>
              <div className="menu-sep" />
              <button
                type="button"
                className="menu-item"
                onClick={() => {
                  toggleLanguage();
                  setMoreOpen(false);
                }}
              >
                <Languages size={15} />
                {isAr ? 'English' : 'العربية'}
                <span className="menu-sub">{isAr ? 'EN' : 'AR'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
