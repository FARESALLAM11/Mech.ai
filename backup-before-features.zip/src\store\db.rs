use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::{Arc, Mutex};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskRecord {
    pub id: String,
    pub title: String,
    pub project_path: String,
    pub status: String,
    pub total_cost_usd: f64,
    pub total_tokens: i64,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CheckpointRecord {
    pub id: String,
    pub task_id: String,
    pub step_index: i32,
    pub state: String,
    pub payload_json: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderBudgetRecord {
    pub provider_id: String,
    pub monthly_limit_usd: f64,
    pub current_spent_usd: f64,
    pub alert_threshold_percent: f64,
    pub updated_at: String,
}

#[derive(Clone)]
pub struct DatabaseStore {
    conn: Arc<Mutex<Connection>>,
}

impl DatabaseStore {
    pub fn new<P: AsRef<Path>>(path: P) -> anyhow::Result<Self> {
        let conn = Connection::open(path)?;

        // Enforce WAL mode for speed, concurrency and data safety
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = NORMAL;
             PRAGMA foreign_keys = ON;",
        )?;

        let store = Self {
            conn: Arc::new(Mutex::new(conn)),
        };

        store.init_schema()?;
        Ok(store)
    }

    pub fn new_in_memory() -> anyhow::Result<Self> {
        let conn = Connection::open_in_memory()?;
        let store = Self {
            conn: Arc::new(Mutex::new(conn)),
        };
        store.init_schema()?;
        Ok(store)
    }

    fn init_schema(&self) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB Lock error: {}", e))?;

        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                project_path TEXT NOT NULL,
                status TEXT NOT NULL,
                total_cost_usd REAL DEFAULT 0.0,
                total_tokens INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS checkpoints (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                step_index INTEGER NOT NULL,
                state TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS task_logs (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS provider_budgets (
                provider_id TEXT PRIMARY KEY,
                monthly_limit_usd REAL NOT NULL,
                current_spent_usd REAL DEFAULT 0.0,
                alert_threshold_percent REAL DEFAULT 80.0,
                updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_checkpoints_task ON checkpoints(task_id, step_index);
            CREATE INDEX IF NOT EXISTS idx_logs_task ON task_logs(task_id, created_at);",
        )?;

        Ok(())
    }

    pub fn insert_task(&self, task: &TaskRecord) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        conn.execute(
            "INSERT INTO tasks (id, title, project_path, status, total_cost_usd, total_tokens, created_at, updated_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)
             ON CONFLICT(id) DO UPDATE SET status = ?4, updated_at = ?8",
            params![
                task.id,
                task.title,
                task.project_path,
                task.status,
                task.total_cost_usd,
                task.total_tokens,
                task.created_at,
                task.updated_at
            ],
        )?;
        Ok(())
    }

    pub fn list_tasks(&self) -> anyhow::Result<Vec<TaskRecord>> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let mut stmt = conn.prepare("SELECT id, title, project_path, status, total_cost_usd, total_tokens, created_at, updated_at FROM tasks ORDER BY created_at DESC")?;
        let rows = stmt.query_map([], |row| {
            Ok(TaskRecord {
                id: row.get(0)?,
                title: row.get(1)?,
                project_path: row.get(2)?,
                status: row.get(3)?,
                total_cost_usd: row.get(4)?,
                total_tokens: row.get(5)?,
                created_at: row.get(6)?,
                updated_at: row.get(7)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub fn update_task_status(&self, task_id: &str, status: &str) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let now = chrono::Utc::now().to_rfc3339();
        conn.execute(
            "UPDATE tasks SET status = ?1, updated_at = ?2 WHERE id = ?3",
            params![status, now, task_id],
        )?;
        Ok(())
    }

    pub fn add_cost_and_tokens(&self, task_id: &str, cost: f64, tokens: i64) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let now = chrono::Utc::now().to_rfc3339();
        conn.execute(
            "UPDATE tasks 
             SET total_cost_usd = total_cost_usd + ?1, 
                 total_tokens = total_tokens + ?2,
                 updated_at = ?3 
             WHERE id = ?4",
            params![cost, tokens, now, task_id],
        )?;
        Ok(())
    }

    pub fn save_checkpoint(&self, cp: &CheckpointRecord) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        conn.execute(
            "INSERT INTO checkpoints (id, task_id, step_index, state, payload_json, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
            params![
                cp.id,
                cp.task_id,
                cp.step_index,
                cp.state,
                cp.payload_json,
                cp.created_at
            ],
        )?;
        Ok(())
    }

    pub fn get_latest_checkpoint(&self, task_id: &str) -> anyhow::Result<Option<CheckpointRecord>> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let mut stmt = conn.prepare(
            "SELECT id, task_id, step_index, state, payload_json, created_at
             FROM checkpoints
             WHERE task_id = ?1
             ORDER BY step_index DESC
             LIMIT 1",
        )?;

        let mut rows = stmt.query(params![task_id])?;
        if let Some(row) = rows.next()? {
            Ok(Some(CheckpointRecord {
                id: row.get(0)?,
                task_id: row.get(1)?,
                step_index: row.get(2)?,
                state: row.get(3)?,
                payload_json: row.get(4)?,
                created_at: row.get(5)?,
            }))
        } else {
            Ok(None)
        }
    }

    pub fn insert_log(&self, task_id: &str, level: &str, message: &str) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let id = uuid::Uuid::new_v4().to_string();
        let now = chrono::Utc::now().to_rfc3339();
        conn.execute(
            "INSERT INTO task_logs (id, task_id, level, message, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![id, task_id, level, message, now],
        )?;
        Ok(())
    }

    /// Set monthly budget for provider
    pub fn set_provider_budget(&self, provider_id: &str, limit_usd: f64) -> anyhow::Result<()> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let now = chrono::Utc::now().to_rfc3339();
        conn.execute(
            "INSERT INTO provider_budgets (provider_id, monthly_limit_usd, current_spent_usd, alert_threshold_percent, updated_at)
             VALUES (?1, ?2, 0.0, 80.0, ?3)
             ON CONFLICT(provider_id) DO UPDATE SET monthly_limit_usd = ?2, updated_at = ?3",
            params![provider_id, limit_usd, now],
        )?;
        Ok(())
    }

    /// Check provider budget status: Returns (can_proceed, is_warning_80_percent, current_spent, limit)
    pub fn check_provider_budget(
        &self,
        provider_id: &str,
    ) -> anyhow::Result<(bool, bool, f64, f64)> {
        let conn = self
            .conn
            .lock()
            .map_err(|e| anyhow::anyhow!("DB lock error: {}", e))?;
        let mut stmt = conn.prepare(
            "SELECT monthly_limit_usd, current_spent_usd, alert_threshold_percent
             FROM provider_budgets
             WHERE provider_id = ?1",
        )?;

        let mut rows = stmt.query(params![provider_id])?;
        if let Some(row) = rows.next()? {
            let limit: f64 = row.get(0)?;
            let spent: f64 = row.get(1)?;
            let threshold: f64 = row.get(2)?;

            let percent = if limit > 0.0 {
                (spent / limit) * 100.0
            } else {
                0.0
            };
            let can_proceed = spent < limit;
            let is_warning = percent >= threshold;

            Ok((can_proceed, is_warning, spent, limit))
        } else {
            // No budget limit set: default allow
            Ok((true, false, 0.0, 0.0))
        }
    }
}
