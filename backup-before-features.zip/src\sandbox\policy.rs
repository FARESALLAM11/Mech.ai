use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SensitiveAction {
    GitPush,
    DeleteFile,
    InstallPackage,
    NetworkAccess,
    ModifyOutsideWorktree,
    UnlistedCommand,
}

impl SensitiveAction {
    pub fn description(&self) -> &'static str {
        match self {
            Self::GitPush => "Pushing commits to remote git repository (git push)",
            Self::DeleteFile => "Deleting files from the project directory",
            Self::InstallPackage => "Installing third-party packages or dependencies",
            Self::NetworkAccess => "Making external network requests from sandbox",
            Self::ModifyOutsideWorktree => "Modifying files outside isolated worktree",
            Self::UnlistedCommand => "Executing a command not in the project allowlist",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityPolicy {
    pub network_allowed: bool,
    pub allowed_domains: Vec<String>,
    pub allow_files_outside_worktree: bool,
    pub allowlist_commands: Vec<String>,
    pub require_approval_for: Vec<SensitiveAction>,
    pub max_memory_mb: usize,
    pub max_cpu_time_seconds: u64,
}

impl Default for SecurityPolicy {
    fn default() -> Self {
        Self {
            network_allowed: false, // Network blocked by default!
            allowed_domains: vec!["registry.npmjs.org".into(), "crates.io".into()],
            allow_files_outside_worktree: false,
            allowlist_commands: vec![
                "npm test".into(),
                "npm run test".into(),
                "node test.js".into(),
                "node --test".into(),
                "cargo test".into(),
                "pytest".into(),
                "go test".into(),
                "git status".into(),
                "git diff".into(),
            ],
            require_approval_for: vec![
                SensitiveAction::GitPush,
                SensitiveAction::DeleteFile,
                SensitiveAction::InstallPackage,
                SensitiveAction::NetworkAccess,
                SensitiveAction::ModifyOutsideWorktree,
                SensitiveAction::UnlistedCommand,
            ],
            max_memory_mb: 1024, // 1 GB RAM cap per sandbox process tree
            max_cpu_time_seconds: 120, // 2 minutes max CPU per command
        }
    }
}

impl SecurityPolicy {
    /// Check if a command is explicitly allowed without requiring human approval
    pub fn is_command_preapproved(&self, cmd: &str) -> bool {
        let trimmed = cmd.trim();
        self.allowlist_commands.iter().any(|allowed| trimmed == allowed || trimmed.starts_with(&format!("{} ", allowed)))
    }

    /// Identify which sensitive action is being attempted
    pub fn detect_sensitive_action(&self, cmd: &str) -> Option<SensitiveAction> {
        let trimmed = cmd.trim();

        if trimmed.starts_with("git push") {
            return Some(SensitiveAction::GitPush);
        }
        if trimmed.contains("rm ") || trimmed.contains("del ") || trimmed.contains("unlink ") {
            return Some(SensitiveAction::DeleteFile);
        }
        if trimmed.starts_with("npm install") || trimmed.starts_with("npm i ") ||
           trimmed.starts_with("yarn add") || trimmed.starts_with("pnpm add") ||
           trimmed.starts_with("cargo add") || trimmed.starts_with("pip install") {
            return Some(SensitiveAction::InstallPackage);
        }
        if trimmed.contains("curl ") || trimmed.contains("wget ") || trimmed.contains("fetch ") {
            return Some(SensitiveAction::NetworkAccess);
        }
        if !self.is_command_preapproved(cmd) {
            return Some(SensitiveAction::UnlistedCommand);
        }

        None
    }
}
