use keyring::Entry;

const SERVICE_NAME: &str = "mech_ai_orchestrator";

pub struct SecretStore;

impl SecretStore {
    /// Save an API key securely to the OS credential manager/keychain
    pub fn set_secret(provider_id: &str, secret_value: &str) -> anyhow::Result<()> {
        let entry = Entry::new(SERVICE_NAME, provider_id)?;
        entry.set_password(secret_value)?;
        Ok(())
    }

    /// Retrieve an API key securely from OS credential manager
    pub fn get_secret(provider_id: &str) -> anyhow::Result<String> {
        let entry = Entry::new(SERVICE_NAME, provider_id)?;
        let secret = entry.get_password()?;
        Ok(secret)
    }

    /// Delete an API key from OS credential manager
    pub fn delete_secret(provider_id: &str) -> anyhow::Result<()> {
        let entry = Entry::new(SERVICE_NAME, provider_id)?;
        let _ = entry.delete_credential();
        Ok(())
    }

    /// Masks any secret so it never leaks to logs or UI: e.g. "sk-1234567890abcdef" -> "sk-...cdef"
    pub fn mask_key(key: &str) -> String {
        if key.len() <= 8 {
            return "********".to_string();
        }
        let prefix = &key[0..3.min(key.len())];
        let suffix = &key[key.len().saturating_sub(4)..];
        format!("{prefix}...{suffix}")
    }

    /// Log Scrubber: cleanses any potential API keys from logs before writing
    pub fn scrub_logs(text: &str) -> String {
        let mut scrubbed = text.to_string();
        // Regex-free fast replacement of common key patterns
        let patterns = ["sk-", "gsk_", "AIzaSy", "ghp_"];
        for pattern in &patterns {
            let mut start = 0;
            while let Some(idx) = scrubbed[start..].find(pattern) {
                let actual_idx = start + idx;
                let end = scrubbed[actual_idx..]
                    .find(|c: char| c.is_whitespace() || c == '"' || c == '\'' || c == ',')
                    .map(|e| actual_idx + e)
                    .unwrap_or(scrubbed.len());
                
                let key_slice = &scrubbed[actual_idx..end];
                if key_slice.len() > 10 {
                    let masked = Self::mask_key(key_slice);
                    scrubbed.replace_range(actual_idx..end, &masked);
                    start = actual_idx + masked.len();
                } else {
                    start = end;
                }
            }
        }
        scrubbed
    }
}
