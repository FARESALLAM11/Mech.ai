import React, { useState } from 'react';
import { X, Play, Scale, Clock, Coins } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

interface ModelComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ModelComparisonModal: React.FC<ModelComparisonModalProps> = ({ isOpen, onClose }) => {
  const { language } = useTaskStore();
  const isAr = language === 'ar';

  const [modelA, setModelA] = useState('gpt-4o-mini');
  const [modelB, setModelB] = useState('claude-3-5-sonnet');
  const [isComparing, setIsComparing] = useState(false);
  const [hasResults, setHasResults] = useState(false);

  if (!isOpen) return null;

  const handleStartComparison = () => {
    setIsComparing(true);
    setHasResults(false);

    setTimeout(() => {
      setIsComparing(false);
      setHasResults(true);
    }, 1200);
  };

  const resultA = {
    model: 'GPT-4o Mini',
    status: 'Verified (Pass)',
    cost: '$0.0003',
    duration: '210 ms',
    tokens: '290',
    diff: `--- a/src/auth.js
+++ b/src/auth.js
@@ -3,4 +3,4 @@
- if (!password) return true;
+ if (!password || !password.trim()) return false;`,
  };

  const resultB = {
    model: 'Claude 3.5 Sonnet',
    status: 'Verified (Pass)',
    cost: '$0.0032',
    duration: '340 ms',
    tokens: '410',
    diff: `--- a/src/auth.js
+++ b/src/auth.js
@@ -3,6 +3,6 @@
- if (!password) {
-   return true;
- }
+ if (typeof password !== "string" || password.trim().length === 0) {
+   return false;
+ }`,
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.6)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 4000,
      padding: '24px',
    }}>
      <div style={{
        background: 'var(--bg-primary)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        maxWidth: '920px',
        width: '100%',
        maxHeight: '90vh',
        overflowY: 'auto',
        boxShadow: '0 20px 50px rgba(0,0,0,0.2)',
        display: 'flex',
        flexDirection: 'column',
        gap: '20px',
        padding: '24px',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              padding: '8px',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-primary-light)',
              color: 'var(--color-primary)',
            }}>
              <Scale size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 700 }}>
                {isAr ? 'مقارنة نتيجتين (Dual-Model Benchmark)' : 'Dual-Model Benchmark & Comparison'}
              </h2>
              <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)' }}>
                {isAr ? 'تشغيل نفس المهمة بنموذجين مختلفين ومقارنة الجودة والتكلفة والسرعة.' : 'Execute the same task on two models to compare code quality, latency, and cost.'}
              </p>
            </div>
          </div>
          <button onClick={onClose} style={{ padding: '6px' }}><X size={20} /></button>
        </div>

        {/* Model Selectors & Prompt */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr auto',
          gap: '12px',
          alignItems: 'flex-end',
          background: 'var(--bg-secondary)',
          padding: '16px',
          borderRadius: 'var(--radius-md)',
          border: '1px solid var(--border-color)',
        }}>
          <div>
            <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '4px' }}>
              {isAr ? 'النموذج الأول (A)' : 'Model A'}
            </label>
            <select
              value={modelA}
              onChange={(e) => setModelA(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--border-color)',
                fontSize: '13px',
                background: '#fff',
              }}
            >
              <option value="gpt-4o-mini">GPT-4o Mini (سريع واقتصادي)</option>
              <option value="deepseek-chat">DeepSeek V3</option>
              <option value="ollama-llama3">Ollama Local ($0)</option>
            </select>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '4px' }}>
              {isAr ? 'النموذج الثاني (B)' : 'Model B'}
            </label>
            <select
              value={modelB}
              onChange={(e) => setModelB(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--border-color)',
                fontSize: '13px',
                background: '#fff',
              }}
            >
              <option value="claude-3-5-sonnet">Claude 3.5 Sonnet</option>
              <option value="deepseek-reasoner">DeepSeek R1 Reasoning</option>
              <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
            </select>
          </div>

          <button
            onClick={handleStartComparison}
            disabled={isComparing}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '9px 18px',
              borderRadius: 'var(--radius-sm)',
              background: 'var(--color-primary)',
              color: '#fff',
              fontSize: '13px',
              fontWeight: 600,
              cursor: isComparing ? 'not-allowed' : 'pointer',
            }}
          >
            <Play size={15} fill="#fff" />
            <span>{isComparing ? (isAr ? 'جاري القياس...' : 'Evaluating...') : (isAr ? 'بدء المقارنة' : 'Run Benchmark')}</span>
          </button>
        </div>

        {/* Benchmark Results */}
        {hasResults && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            {/* Column A */}
            <div style={{
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              padding: '16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 700, fontSize: '15px' }}>{resultA.model}</span>
                <span style={{
                  fontSize: '12px',
                  fontWeight: 600,
                  color: 'var(--color-success)',
                  background: 'var(--color-success-light)',
                  padding: '2px 8px',
                  borderRadius: '10px',
                }}>
                  {resultA.status}
                </span>
              </div>

              <div style={{ display: 'flex', gap: '12px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Coins size={13} color="var(--color-primary)" /> {resultA.cost}
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Clock size={13} /> {resultA.duration}
                </span>
                <span>{resultA.tokens} tokens</span>
              </div>

              <div style={{
                background: '#1E1E1E',
                color: '#fff',
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                lineHeight: 1.5,
                padding: '12px',
                borderRadius: 'var(--radius-sm)',
                whiteSpace: 'pre',
                direction: 'ltr',
                textAlign: 'left',
                overflowX: 'auto',
              }}>
                {resultA.diff}
              </div>
            </div>

            {/* Column B */}
            <div style={{
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              padding: '16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 700, fontSize: '15px' }}>{resultB.model}</span>
                <span style={{
                  fontSize: '12px',
                  fontWeight: 600,
                  color: 'var(--color-success)',
                  background: 'var(--color-success-light)',
                  padding: '2px 8px',
                  borderRadius: '10px',
                }}>
                  {resultB.status}
                </span>
              </div>

              <div style={{ display: 'flex', gap: '12px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Coins size={13} color="var(--color-primary)" /> {resultB.cost}
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Clock size={13} /> {resultB.duration}
                </span>
                <span>{resultB.tokens} tokens</span>
              </div>

              <div style={{
                background: '#1E1E1E',
                color: '#fff',
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                lineHeight: 1.5,
                padding: '12px',
                borderRadius: 'var(--radius-sm)',
                whiteSpace: 'pre',
                direction: 'ltr',
                textAlign: 'left',
                overflowX: 'auto',
              }}>
                {resultB.diff}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
