import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { CommandPalette } from './components/CommandPalette';
import { HomeScreen } from './screens/HomeScreen';
import { AgentsScreen } from './screens/AgentsScreen';
import { DiffReviewScreen } from './screens/DiffReviewScreen';
import { ProvidersScreen } from './screens/ProvidersScreen';
import { MemoryScreen } from './screens/MemoryScreen';
import { AnalyticsScreen } from './screens/AnalyticsScreen';
import { AIReposScreen } from './screens/AIReposScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { ClosedBetaScreen } from './screens/ClosedBetaScreen';
import { useTaskStore } from './store/taskStore';

export const App: React.FC = () => {
  const {
    currentScreen,
    setCurrentScreen,
    language,
    theme,
    setTheme,
    addTimelineEvent,
    newConversation,
    setCommandPaletteOpen,
  } = useTaskStore();

  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem('mech.sidebarCollapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [isCompact, setIsCompact] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(max-width: 920px)').matches,
  );

  useEffect(() => {
    const query = window.matchMedia('(max-width: 920px)');
    const onChange = (event: MediaQueryListEvent) => setIsCompact(event.matches);
    query.addEventListener('change', onChange);
    return () => query.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    void (async () => {
      try {
        const { listen } = await import('@tauri-apps/api/event');
        unlisten = await listen<Parameters<typeof addTimelineEvent>[0]>('task-event', event => {
          addTimelineEvent(event.payload);
        });
      } catch {
        /* browser preview: no Tauri event bridge */
      }
    })();
    return () => unlisten?.();
  }, [addTimelineEvent]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const meta = event.ctrlKey || event.metaKey;
      if (meta && !event.shiftKey && event.key.toLowerCase() === 'n') {
        event.preventDefault();
        newConversation();
        setCurrentScreen('tasks');
      }
      if (meta && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setCommandPaletteOpen(!useTaskStore.getState().isCommandPaletteOpen);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [newConversation, setCurrentScreen, setCommandPaletteOpen]);

  useEffect(() => {
    setMobileNavOpen(false);
  }, [currentScreen]);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'agents':
        return <AgentsScreen />;
      case 'diff':
        return <DiffReviewScreen />;
      case 'providers':
        return <ProvidersScreen />;
      case 'memory':
        return <MemoryScreen />;
      case 'analytics':
        return <AnalyticsScreen />;
      case 'aiRepos':
        return <AIReposScreen />;
      case 'settings':
        return <SettingsScreen />;
      case 'beta':
        return <ClosedBetaScreen />;
      default:
        return <HomeScreen />;
    }
  };

  const isChat = currentScreen === 'tasks';

  return (
    <div className="app">
      {mobileNavOpen && (
        <button
          type="button"
          className="sidebar-scrim"
          aria-label="Close sidebar"
          onClick={() => setMobileNavOpen(false)}
        />
      )}

      <Sidebar
        collapsed={isCompact ? false : collapsed}
        onToggleCollapse={() => {
          setCollapsed(value => {
            try {
              localStorage.setItem('mech.sidebarCollapsed', String(!value));
            } catch {
              /* optional persistence */
            }
            return !value;
          });
        }}
        open={mobileNavOpen}
        onNavigate={() => setMobileNavOpen(false)}
        theme={theme}
        onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      />

      <div className="main">
        <Navbar
          onOpenPalette={() => setCommandPaletteOpen(true)}
          onOpenSidebar={() => setMobileNavOpen(true)}
        />

        <div className={`screen${isChat ? '' : ' screen-page'}`}>
          {isChat ? <HomeScreen /> : <div className="page">{renderScreen()}</div>}
        </div>
      </div>

      <CommandPalette />
    </div>
  );
};
