import React, { useState } from 'react';
import { X, FolderGit2, Key, Play } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

export const OnboardingModal: React.FC = () => {
  const { isOnboardingOpen, setOnboardingOpen, setCurrentScreen, setProjectPath, t } = useTaskStore();
  const strings = t();
  const [step, setStep] = useState(1);

  if (!isOnboardingOpen) return null;

  const handleFinish = () => {
    setOnboardingOpen(false);
    setCurrentScreen('tasks');
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.5)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 3000,
      padding: '20px',
    }}>
      <div style={{
        background: 'var(--bg-primary)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        maxWidth: '560px',
        width: '100%',
        padding: '32px',
        boxShadow: '0 16px 40px rgba(0,0,0,0.18)',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h2 style={{ fontSize: '22px', fontWeight: 700 }}>{strings.onboarding.welcome}</h2>
            <p style={{ fontSize: '13.5px', color: 'var(--text-secondary)', marginTop: '4px' }}>
              {strings.onboarding.subtitle}
            </p>
          </div>
          <button onClick={() => setOnboardingOpen(false)} style={{ padding: '4px' }}>
            <X size={20} />
          </button>
        </div>

        {/* Step Indicator */}
        <div style={{ display: 'flex', gap: '8px' }}>
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              style={{
                flex: 1,
                height: '4px',
                borderRadius: '2px',
                background: s <= step ? 'var(--color-primary)' : 'var(--border-color)',
                transition: 'background var(--transition-fast)',
              }}
            />
          ))}
        </div>

        {/* Step Contents */}
        {step === 1 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '15px' }}>
              <FolderGit2 size={18} color="var(--color-primary)" />
              <span>{strings.onboarding.step1}</span>
            </div>
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
              يتم عزل كل مهمة برمجية داخل `git worktree` مستقل لضمان بقاء كودك الأصلي دون مساس حتى تقبل الـ Diff.
            </p>
            <input
              type="text"
              defaultValue="C:\Users\Fares Sayed\.gemini\antigravity\scratch\mech\fixtures\sample-project"
              onChange={(e) => setProjectPath(e.target.value)}
              style={{
                padding: '10px 14px',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--border-color)',
                fontSize: '13px',
                background: 'var(--bg-secondary)',
              }}
            />
            <button
              onClick={() => setStep(2)}
              style={{
                alignSelf: 'flex-end',
                padding: '10px 20px',
                borderRadius: 'var(--radius-md)',
                background: 'var(--color-primary)',
                color: '#fff',
                fontSize: '13.5px',
                fontWeight: 600,
              }}
            >
              التالي
            </button>
          </div>
        )}

        {step === 2 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '15px' }}>
              <Key size={18} color="var(--color-primary)" />
              <span>{strings.onboarding.step2}</span>
            </div>
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
              Mech يدعم نماذج Ollama المحلية مجاناً ($0.00)، أو يمكنك إدخال مفتاح API لمزود مثل OpenAI أو Anthropic ويُحفظ في مخزن النظام المشفر.
            </p>
            <div style={{
              padding: '12px',
              borderRadius: 'var(--radius-md)',
              background: 'var(--color-success-light)',
              color: 'var(--color-success)',
              fontSize: '13px',
              fontWeight: 500,
            }}>
              ✓ تم التعرف على Ollama المحلي والمفاتيح الافتراضية بنجاح!
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button onClick={() => setStep(1)} style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>السابق</button>
              <button
                onClick={() => setStep(3)}
                style={{
                  padding: '10px 20px',
                  borderRadius: 'var(--radius-md)',
                  background: 'var(--color-primary)',
                  color: '#fff',
                  fontSize: '13.5px',
                  fontWeight: 600,
                }}
              >
                التالي
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '15px' }}>
              <Play size={18} color="var(--color-success)" />
              <span>{strings.onboarding.step3}</span>
            </div>
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
              أنت جاهز تماماً! تم تهيئة بيئة الاختبار التجريبية `sample-project` لإصلاح أول خطأ وتسليم Diff معتمد.
            </p>
            <button
              onClick={handleFinish}
              style={{
                width: '100%',
                padding: '12px',
                borderRadius: 'var(--radius-md)',
                background: 'var(--color-success)',
                color: '#fff',
                fontSize: '14px',
                fontWeight: 600,
              }}
            >
              {strings.onboarding.finishBtn}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
