use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum TaskState {
    Planned,
    Running,
    Testing,
    Reviewing,
    Done,
    Failed,
    Paused,
}

impl TaskState {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Planned => "planned",
            Self::Running => "running",
            Self::Testing => "testing",
            Self::Reviewing => "reviewing",
            Self::Done => "done",
            Self::Failed => "failed",
            Self::Paused => "paused",
        }
    }

    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            "planned" => Some(Self::Planned),
            "running" => Some(Self::Running),
            "testing" => Some(Self::Testing),
            "reviewing" => Some(Self::Reviewing),
            "done" => Some(Self::Done),
            "failed" => Some(Self::Failed),
            "paused" => Some(Self::Paused),
            _ => None,
        }
    }

    /// Strict transition validation
    pub fn can_transition_to(&self, next: TaskState) -> bool {
        match (self, next) {
            (Self::Planned, TaskState::Planned) => true, // Initial checkpoint records the current planned state.
            (Self::Planned, TaskState::Running) => true,
            (Self::Planned, TaskState::Failed) => true,

            (Self::Running, TaskState::Testing) => true,
            (Self::Running, TaskState::Paused) => true,
            (Self::Running, TaskState::Failed) => true,

            (Self::Testing, TaskState::Reviewing) => true,
            (Self::Testing, TaskState::Running) => true, // Retry loop
            (Self::Testing, TaskState::Paused) => true,
            (Self::Testing, TaskState::Failed) => true,

            (Self::Reviewing, TaskState::Done) => true,
            (Self::Reviewing, TaskState::Failed) => true,
            (Self::Reviewing, TaskState::Running) => true, // User requested further adjustments

            (Self::Paused, TaskState::Running) => true, // Resume execution
            (Self::Paused, TaskState::Failed) => true,

            _ => false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskContext {
    pub task_id: String,
    pub current_state: TaskState,
    pub step_index: i32,
    pub total_cost_usd: f64,
    pub max_cost_limit_usd: f64,
    pub max_steps: i32,
    pub is_interrupted: bool,
}

impl TaskContext {
    pub fn new(task_id: String, max_cost_limit_usd: f64) -> Self {
        Self {
            task_id,
            current_state: TaskState::Planned,
            step_index: 0,
            total_cost_usd: 0.0,
            max_cost_limit_usd,
            max_steps: 15,
            is_interrupted: false,
        }
    }

    /// Advance state machine with budget and step validation
    pub fn transition(&mut self, next_state: TaskState) -> anyhow::Result<()> {
        if self.is_interrupted && next_state != TaskState::Paused && next_state != TaskState::Failed {
            anyhow::bail!("Task {} was paused/interrupted", self.task_id);
        }

        if !self.current_state.can_transition_to(next_state) {
            anyhow::bail!(
                "Invalid state transition: cannot move from '{}' to '{}'",
                self.current_state.as_str(),
                next_state.as_str()
            );
        }

        if self.total_cost_usd >= self.max_cost_limit_usd {
            self.current_state = TaskState::Failed;
            anyhow::bail!(
                "Budget exceeded! Cost ${:.4} reached limit ${:.4}",
                self.total_cost_usd,
                self.max_cost_limit_usd
            );
        }

        if self.step_index >= self.max_steps && next_state != TaskState::Done && next_state != TaskState::Failed {
            self.current_state = TaskState::Failed;
            anyhow::bail!("Max steps limit ({}) reached!", self.max_steps);
        }

        self.current_state = next_state;
        self.step_index += 1;
        Ok(())
    }

    pub fn add_cost(&mut self, cost: f64) {
        self.total_cost_usd += cost;
    }

    pub fn pause(&mut self) {
        self.is_interrupted = true;
        self.current_state = TaskState::Paused;
    }
}
