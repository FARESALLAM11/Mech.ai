import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart3,
  Bot,
  BrainCircuit,
  FileDiff,
  Languages,
  Plus,
  Search,
  Server,
  Settings2,
} from 'lucide-react';
import { useTaskStore, type ScreenId } from '../store/taskStore';

interface PaletteAction {
  id: string;
  label: string;
  hint?: string;
  icon: React.ReactNode;
  screen?: ScreenId;
  run?: () => void;
}

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setCommandPaletteOpen,
    setCurrentScreen,
    toggleLanguage,
    newConversation,
    t,
  } = useTaskStore();

  const strings = t();
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (isCommandPaletteOpen) {
      setQuery('');
      setActiveIndex(0);
    }
  }, [isCommandPaletteOpen]);

  useEffect(() => {
    if (!isCommandPaletteOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setCommandPaletteOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isCommandPaletteOpen, setCommandPaletteOpen]);

  const actions = useMemo<PaletteAction[]>(
    () => [
      {
        id: 'new',
        label: strings.chat.newTask,
        hint: 'Ctrl N',
        icon: <Plus size={16} />,
        run: () => {
          newConversation();
          setCurrentScreen('tasks');
        },
      },
      {
        id: 'diff',
        label: strings.chat.changes,
        icon: <FileDiff size={16} />,
        screen: 'diff',
      },
      {
        id: 'providers',
        label: strings.nav.providers,
        icon: <Server size={16} />,
        screen: 'providers',
      },
      {
        id: 'memory',
        label: strings.nav.memory,
        icon: <BrainCircuit size={16} />,
        screen: 'memory',
      },
      {
        id: 'agents',
        label: 'Agents',
        icon: <Bot size={16} />,
        screen: 'agents',
      },
      {
        id: 'analytics',
        label: strings.commandPalette.viewStats,
        icon: <BarChart3 size={16} />,
        screen: 'analytics',
      },
      {
        id: 'settings',
        label: strings.nav.settings,
        icon: <Settings2 size={16} />,
        screen: 'settings',
      },
      {
        id: 'lang',
        label: strings.commandPalette.toggleLang,
        icon: <Languages size={16} />,
        run: () => toggleLanguage(),
      },
    ],
    [newConversation, setCurrentScreen, strings, toggleLanguage],
  );

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return actions;
    return actions.filter(action => action.label.toLowerCase().includes(needle));
  }, [actions, query]);

  if (!isCommandPaletteOpen) return null;

  const runAction = (action: PaletteAction) => {
    setCommandPaletteOpen(false);
    if (action.run) action.run();
    if (action.screen) setCurrentScreen(action.screen);
  };

  return (
    <div className="palette-scrim" onMouseDown={() => setCommandPaletteOpen(false)}>
      <div
        className="palette"
        role="dialog"
        aria-modal="true"
        aria-label={strings.commandPalette.placeholder}
        onMouseDown={event => event.stopPropagation()}
      >
        <div className="palette-search">
          <Search size={17} />
          <input
            autoFocus
            value={query}
            onChange={event => {
              setQuery(event.target.value);
              setActiveIndex(0);
            }}
            onKeyDown={event => {
              if (event.key === 'ArrowDown') {
                event.preventDefault();
                setActiveIndex(index => Math.min(index + 1, filtered.length - 1));
              }
              if (event.key === 'ArrowUp') {
                event.preventDefault();
                setActiveIndex(index => Math.max(index - 1, 0));
              }
              if (event.key === 'Enter' && filtered[activeIndex]) {
                event.preventDefault();
                runAction(filtered[activeIndex]);
              }
            }}
            placeholder={strings.commandPalette.placeholder}
            aria-label={strings.commandPalette.placeholder}
          />
          <kbd>ESC</kbd>
        </div>

        <div className="palette-list" role="listbox" aria-label={strings.commandPalette.placeholder}>
          {filtered.length === 0 ? (
            <p className="palette-empty">
              {query.trim()
                ? strings.commandPalette.noResults
                : strings.commandPalette.placeholder}
            </p>
          ) : (
            filtered.map((action, index) => (
              <button
                type="button"
                key={action.id}
                role="option"
                aria-selected={index === activeIndex}
                className={`palette-item${index === activeIndex ? ' is-active' : ''}`}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => runAction(action)}
              >
                <span className="palette-icon">{action.icon}</span>
                <span>{action.label}</span>
                {action.hint && <kbd>{action.hint}</kbd>}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
