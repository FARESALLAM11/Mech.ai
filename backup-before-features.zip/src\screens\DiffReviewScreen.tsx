import React from 'react';
import { FileDiff } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';
import { DiffCard } from '../components/DiffCard';
import { parseDiff } from '../lib/diff';

export const DiffReviewScreen: React.FC = () => {
  const {
    conversations,
    activeConversationId,
    currentDiff,
    currentTaskId,
    language,
    setCurrentScreen,
    t,
  } = useTaskStore();

  const strings = t();
  const isAr = language === 'ar';
  const conversation = conversations.find(item => item.id === activeConversationId);
  const lastAssistant = [...(conversation?.turns ?? [])]
    .reverse()
    .find(turn => turn.role === 'assistant' && turn.diff);
  const diff = lastAssistant?.diff ?? currentDiff;
  const taskId = lastAssistant?.taskId ?? currentTaskId ?? conversation?.taskId ?? null;
  const parsed = parseDiff(diff);

  if (!diff.trim()) {
    return (
      <div className="empty-page">
        <span className="empty-page-icon">
          <FileDiff size={22} />
        </span>
        <h2>{isAr ? 'لا توجد تغييرات بعد' : 'No changes yet'}</h2>
        <p>
          {isAr
            ? 'ابدأ مهمة في المحادثة، وسيظهر الفرق هنا للمراجعة قبل التطبيق.'
            : 'Start a task in the chat and its diff will land here for review before anything is applied.'}
        </p>
        <button type="button" className="btn btn-primary" onClick={() => setCurrentScreen('tasks')}>
          {isAr ? 'العودة إلى المحادثة' : 'Back to chat'}
        </button>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <header className="page-head">
        <div>
          <h2>{strings.chat.changes}</h2>
          <p>
            {isAr
              ? 'هذه التغييرات موجودة في مساحة العمل المعزولة فقط، وتحتاج موافقتك قبل التطبيق.'
              : 'These changes live in the isolated worktree only. They are applied after your approval.'}
          </p>
        </div>
        <div className="page-head-meta">
          <span className="diff-add">+{parsed.additions}</span>
          <span className="diff-del">−{parsed.deletions}</span>
          <span className="pill">
            {parsed.files.length}{' '}
            {parsed.files.length === 1
              ? isAr
                ? 'ملف'
                : 'file'
              : isAr
                ? 'ملفات'
                : 'files'}
          </span>
        </div>
      </header>

      <DiffCard
        diff={diff}
        projectPath={conversation?.projectPath ?? ''}
        taskId={taskId}
        conversationId={conversation?.id ?? ''}
        turnId={lastAssistant?.id ?? ''}
        applied={lastAssistant?.applied}
        full
      />
    </div>
  );
};
