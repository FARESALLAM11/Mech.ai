use std::path::Path;
use std::process::Command;
use crate::sandbox::env_scrubber::SecretScrubber;

pub struct MacSeatbeltSandbox;

impl MacSeatbeltSandbox {
    /// Generates Apple Seatbelt (sandbox-exec) configuration profile
    pub fn generate_seatbelt_profile(worktree_dir: &Path, network_allowed: bool) -> String {
        let worktree_str = worktree_dir.to_string_lossy();
        let net_rule = if network_allowed {
            "(allow network*)"
        } else {
            "(deny network*)"
        };

        format!(
            r#"(version 1)
(deny default)
(allow process-exec)
(allow process-fork)
(allow sysctl-read)
{}
(allow file-read*)
(allow file-write* (subpath "{}"))
(allow file-write* (subpath "/tmp"))
(allow file-write* (subpath "/private/tmp"))"#,
            net_rule, worktree_str
        )
    }

    /// Execute command under macOS Seatbelt sandbox
    pub fn execute_sandboxed(
        working_dir: &Path,
        cmd_str: &str,
        network_allowed: bool,
    ) -> anyhow::Result<(bool, String)> {
        let safe_env = SecretScrubber::sanitize_env_vars();
        let profile = Self::generate_seatbelt_profile(working_dir, network_allowed);

        let mut cmd = Command::new("sandbox-exec");
        cmd.current_dir(working_dir)
            .args(["-p", &profile, "sh", "-c", cmd_str])
            .env_clear()
            .envs(&safe_env);

        let output = cmd.output()?;

        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();
        let combined = format!("{stdout}\n{stderr}");

        Ok((output.status.success(), combined))
    }
}
