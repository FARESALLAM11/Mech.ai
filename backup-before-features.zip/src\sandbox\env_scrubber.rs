use std::collections::HashMap;

pub struct SecretScrubber;

impl SecretScrubber {
    /// List of environment variable substrings to purge before spawning any sandbox process
    const SENSITIVE_ENV_PATTERNS: &'static [&'static str] = &[
        "KEY", "SECRET", "TOKEN", "PASSWORD", "PASS", "AUTH",
        "CREDENTIAL", "AWS_", "OPENAI_", "ANTHROPIC_", "GEMINI_",
        "GROQ_", "GITHUB_", "GH_TOKEN", "DATABASE_URL"
    ];

    /// Filter host environment variables to prevent accidental credential leakage into child sandbox processes
    pub fn sanitize_env_vars() -> HashMap<String, String> {
        let mut safe_env = HashMap::new();

        for (key, val) in std::env::vars() {
            let key_upper = key.to_uppercase();
            let is_sensitive = Self::SENSITIVE_ENV_PATTERNS.iter().any(|pattern| key_upper.contains(pattern));

            if !is_sensitive {
                safe_env.insert(key, val);
            }
        }

        // Set safe deterministic locale & defaults
        safe_env.insert("MECH_SANDBOX".into(), "1".into());
        safe_env.insert("CI".into(), "true".into());
        safe_env
    }

    /// Redacts secrets from text (such as file contents, .env files, or prompt snippets) before LLM submission
    pub fn redact_secrets_from_context(content: &str) -> String {
        let mut redacted = content.to_string();

        // 1. Redact common API key patterns
        let token_patterns = [
            ("sk-[a-zA-Z0-9_-]{20,}", "sk-[REDACTED_API_KEY]"),
            ("ghp_[a-zA-Z0-9]{36,}", "ghp_[REDACTED_GITHUB_TOKEN]"),
            ("AIzaSy[a-zA-Z0-9_-]{33}", "AIzaSy[REDACTED_GOOGLE_KEY]"),
            ("gsk_[a-zA-Z0-9]{20,}", "gsk_[REDACTED_GROQ_KEY]"),
        ];

        for (pattern, replacement) in &token_patterns {
            if let Ok(re) = regex::Regex::new(pattern) {
                redacted = re.replace_all(&redacted, *replacement).to_string();
            }
        }

        // 2. Redact .env style assignments: KEY=secret_value
        let lines: Vec<String> = redacted
            .lines()
            .map(|line| {
                let trimmed = line.trim();
                if let Some(eq_pos) = trimmed.find('=') {
                    let key = &trimmed[..eq_pos].trim().to_uppercase();
                    if Self::SENSITIVE_ENV_PATTERNS.iter().any(|p| key.contains(p)) {
                        return format!("{}=[REDACTED_SECRET]", &trimmed[..eq_pos]);
                    }
                }
                line.to_string()
            })
            .collect();

        lines.join("\n")
    }
}
