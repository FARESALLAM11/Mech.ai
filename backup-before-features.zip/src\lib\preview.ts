import { useTaskStore, type TimelineEvent } from '../store/taskStore';

/**
 * A browser-only preview of the agent loop. The desktop build streams real
 * `task-event`s from the Rust engine; when the UI runs in a plain browser tab
 * there is no engine, so we replay a clearly-labelled simulated run against the
 * bundled sample project. Nothing is written to disk.
 */
export const PREVIEW_DIFF = `diff --git a/src/auth.js b/src/auth.js
index 8f1b4c2..0c7a1e9 100644
--- a/src/auth.js
+++ b/src/auth.js
@@ -1,13 +1,15 @@
 // Fixture authentication module with a known bug for Phase 1 verification
 function authenticateUser(username, password) {
-  // BUG: Fails to check empty or uninitialized passwords when user is found
-  if (username === "admin") {
-    if (!password) {
-      return true; // Vulnerability: Allows login with empty password!
-    }
-    return password.trim() === "secret123";
+  if (typeof username !== "string" || typeof password !== "string") {
+    return false;
+  }
+
+  if (!password.trim()) {
+    return false;
   }
-  return false;
+
+  return username === "admin" && password.trim() === "secret123";
 }
 
 module.exports = { authenticateUser };
`;

const script: Array<Omit<TimelineEvent, 'task_id'>> = [
  {
    step_index: 0,
    status: 'planned',
    description: 'Reading fixtures/sample-project and planning a fix for src/auth.js',
    cost_usd: 0.0011,
    duration_ms: 720,
  },
  {
    step_index: 1,
    status: 'running',
    description: 'Editing src/auth.js to reject empty and whitespace-only passwords',
    cost_usd: 0.0043,
    duration_ms: 1180,
  },
  {
    step_index: 2,
    status: 'testing',
    description: 'Running the project test suite inside the isolated worktree',
    cost_usd: 0.0006,
    duration_ms: 940,
  },
  {
    step_index: 3,
    status: 'reviewing',
    description: 'Reviewable diff ready: 1 file changed, +8 −7',
    diff_preview: PREVIEW_DIFF,
    cost_usd: 0.0043,
    duration_ms: 380,
  },
];

let runCount = 0;

const wait = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));

export const runPreviewTask = async (conversationId?: string): Promise<void> => {
  runCount += 1;
  const taskId = `preview-${Date.now()}-${runCount}`;
  const store = useTaskStore.getState();
  store.setTaskId(taskId, conversationId);

  for (const step of script) {
    await wait(700 + Math.round(Math.random() * 500));
    useTaskStore.getState().addTimelineEvent({ ...step, task_id: taskId });
  }
};
