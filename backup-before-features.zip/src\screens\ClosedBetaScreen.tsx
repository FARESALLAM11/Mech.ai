import React, { useEffect, useMemo, useState } from 'react';
import { Download, Plus, Search, Users, CheckCircle2, Clock3, DollarSign, MessageSquareText } from 'lucide-react';

type PilotTeam = { id: string; name: string; lead: string; started: string; status: 'Active' | 'Follow-up' | 'Completed' };
type PilotTask = { id: string; teamId: string; task: string; outcome: 'success' | 'failure'; accepted: boolean; cost: number; interventions: number; durationMinutes: number; recordedAt: string };

const TEAMS_KEY = 'mech.phase7.teams.v1';
const TASKS_KEY = 'mech.phase7.tasks.v1';
const FEEDBACK_KEY = 'mech.phase7.feedback.v1';

const styles: Record<string, React.CSSProperties> = {
  card: { background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 14, padding: 18 },
  muted: { color: 'var(--text-secondary)', fontSize: 13 },
  button: { display: 'inline-flex', gap: 8, alignItems: 'center', padding: '9px 13px', borderRadius: 9, background: 'var(--color-primary)', color: 'var(--color-on-primary)', fontWeight: 600 },
  secondary: { display: 'inline-flex', gap: 8, alignItems: 'center', padding: '8px 12px', borderRadius: 9, border: '1px solid var(--border-color)', color: 'var(--text-primary)', background: 'var(--bg-card)' },
  input: { padding: '9px 11px', border: '1px solid var(--border-color)', borderRadius: 8, background: 'var(--bg-card)', color: 'var(--text-primary)', font: 'inherit' },
};

function downloadCsv(teams: PilotTeam[], tasks: PilotTask[]) {
  const rows = [['Team', 'Lead', 'Task', 'Outcome', 'Diff accepted', 'Cost USD', 'Interventions', 'Duration minutes', 'Recorded at'], ...tasks.filter(task => teams.some(team => team.id === task.teamId)).map(task => { const team = teams.find(t => t.id === task.teamId)!; return [team.name, team.lead, task.task, task.outcome, String(task.accepted), task.cost.toFixed(4), String(task.interventions), String(task.durationMinutes), task.recordedAt]; })];
  const csv = '\ufeff' + rows.map(row => row.map(v => `"${v.replace(/"/g, '""')}"`).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a'); link.href = url; link.download = 'mech-closed-beta.csv'; link.click(); URL.revokeObjectURL(url);
}

export const ClosedBetaScreen: React.FC = () => {
  const [teams, setTeams] = useState<PilotTeam[]>(() => { try { return JSON.parse(localStorage.getItem(TEAMS_KEY) || '[]'); } catch { return []; } });
  const [tasks, setTasks] = useState<PilotTask[]>(() => { try { return JSON.parse(localStorage.getItem(TASKS_KEY) || '[]'); } catch { return []; } });
  const [feedback, setFeedback] = useState<{ teamId: string; text: string; date: string }[]>(() => { try { return JSON.parse(localStorage.getItem(FEEDBACK_KEY) || '[]'); } catch { return []; } });
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const [showTeamForm, setShowTeamForm] = useState(false);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [teamName, setTeamName] = useState('');
  const [lead, setLead] = useState('');
  const [feedbackTeam, setFeedbackTeam] = useState('');
  const [feedbackText, setFeedbackText] = useState('');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [taskTeam, setTaskTeam] = useState('');
  const [taskTitle, setTaskTitle] = useState('');
  const [taskOutcome, setTaskOutcome] = useState<PilotTask['outcome']>('success');
  const [taskAccepted, setTaskAccepted] = useState(false);
  const [taskCost, setTaskCost] = useState('');
  const [taskInterventions, setTaskInterventions] = useState('0');
  const [taskDuration, setTaskDuration] = useState('');

  useEffect(() => { localStorage.setItem(TEAMS_KEY, JSON.stringify(teams)); }, [teams]);
  useEffect(() => { localStorage.setItem(TASKS_KEY, JSON.stringify(tasks)); }, [tasks]);
  useEffect(() => { localStorage.setItem(FEEDBACK_KEY, JSON.stringify(feedback)); }, [feedback]);

  const visibleTeams = useMemo(() => teams.filter(t => (filter === 'All' || t.status === filter) && `${t.name} ${t.lead}`.toLowerCase().includes(query.toLowerCase())), [teams, filter, query]);
  const totals = useMemo(() => tasks.reduce((a, t) => ({ tasks: a.tasks + 1, successes: a.successes + (t.outcome === 'success' ? 1 : 0), cost: a.cost + t.cost, interventions: a.interventions + t.interventions }), { tasks: 0, successes: 0, cost: 0, interventions: 0 }), [tasks]);
  const successRate = totals.tasks ? totals.successes / totals.tasks * 100 : 0;
  const avgCost = totals.tasks ? totals.cost / totals.tasks : 0;
  const avgInterventions = totals.tasks ? totals.interventions / totals.tasks : 0;
  const completedTeams = teams.filter(t => t.status === 'Completed' && tasks.some(task => task.teamId === t.id)).length;
  const metricsFor = (teamId: string) => { const teamTasks = tasks.filter(task => task.teamId === teamId); const successes = teamTasks.filter(task => task.outcome === 'success').length; return { count: teamTasks.length, success: teamTasks.length ? successes / teamTasks.length * 100 : 0, cost: teamTasks.length ? teamTasks.reduce((n, task) => n + task.cost, 0) / teamTasks.length : 0, interventions: teamTasks.length ? teamTasks.reduce((n, task) => n + task.interventions, 0) / teamTasks.length : 0 }; };
  const statusStyle = (status: PilotTeam['status']): React.CSSProperties => ({ borderRadius: 999, padding: '4px 9px', fontSize: 12, color: status === 'Completed' ? 'var(--color-success)' : status === 'Follow-up' ? 'var(--color-warning)' : 'var(--color-primary)', background: status === 'Completed' ? 'var(--color-success-light)' : status === 'Follow-up' ? 'var(--color-warning-light)' : 'var(--color-primary-light)' });

  return <div style={{ maxWidth: 1200, margin: '0 auto' }}>
    <div style={{ color: 'var(--color-primary)', fontSize: 13, fontWeight: 700 }}>PHASE 7 · CLOSED BETA</div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: 18, margin: '8px 0 22px', flexWrap: 'wrap' }}>
      <div><h1 style={{ fontSize: 28, marginBottom: 6 }}>Closed beta evaluation</h1><p style={styles.muted}>Track real team usage, cost, task outcomes, and feedback before deciding whether to expand.</p></div>
      <button style={styles.button} onClick={() => setShowTeamForm(v => !v)}><Plus size={16} /> Add team</button>
    </div>

    {showTeamForm && <form onSubmit={e => { e.preventDefault(); if (!teamName.trim()) return; setTeams(ts => [...ts, { id: crypto.randomUUID(), name: teamName.trim(), lead: lead.trim() || 'Unassigned', started: new Date().toLocaleDateString(), status: 'Active' }]); setTeamName(''); setLead(''); setShowTeamForm(false); }} style={{ ...styles.card, display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 16 }}><input required aria-label="Team name" placeholder="Team name" value={teamName} onChange={e => setTeamName(e.target.value)} style={styles.input} /><input aria-label="Team lead" placeholder="Team lead" value={lead} onChange={e => setLead(e.target.value)} style={styles.input} /><button style={styles.button}>Save team</button><button type="button" style={styles.secondary} onClick={() => setShowTeamForm(false)}>Cancel</button></form>}

    {showTaskForm && <form onSubmit={e => { e.preventDefault(); if (!taskTeam || !taskTitle.trim()) return; setTasks(ts => [{ id: crypto.randomUUID(), teamId: taskTeam, task: taskTitle.trim(), outcome: taskOutcome, accepted: taskAccepted, cost: Math.max(0, Number(taskCost) || 0), interventions: Math.max(0, Number(taskInterventions) || 0), durationMinutes: Math.max(0, Number(taskDuration) || 0), recordedAt: new Date().toISOString() }, ...ts]); setTaskTitle(''); setTaskCost(''); setTaskDuration(''); setTaskInterventions('0'); setTaskAccepted(false); setShowTaskForm(false); }} style={{ ...styles.card, display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(170px,1fr))', gap: 10, marginBottom: 16 }}><strong style={{ gridColumn: '1 / -1' }}>Record a completed pilot task</strong><select required aria-label="Team" value={taskTeam} onChange={e => setTaskTeam(e.target.value)} style={styles.input}><option value="">Choose team</option>{teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select><input required aria-label="Task summary" placeholder="Short task summary" value={taskTitle} onChange={e => setTaskTitle(e.target.value)} style={styles.input} /><select aria-label="Outcome" value={taskOutcome} onChange={e => setTaskOutcome(e.target.value as PilotTask['outcome'])} style={styles.input}><option value="success">Successful</option><option value="failure">Failed</option></select><label style={{ ...styles.input, display: 'flex', alignItems: 'center', gap: 8 }}><input type="checkbox" checked={taskAccepted} onChange={e => setTaskAccepted(e.target.checked)} /> Diff accepted</label><input type="number" min="0" step="0.0001" aria-label="Cost USD" placeholder="Cost (USD)" value={taskCost} onChange={e => setTaskCost(e.target.value)} style={styles.input} /><input type="number" min="0" step="1" aria-label="Manual interventions" placeholder="Interventions" value={taskInterventions} onChange={e => setTaskInterventions(e.target.value)} style={styles.input} /><input type="number" min="0" step="1" aria-label="Duration minutes" placeholder="Duration (minutes)" value={taskDuration} onChange={e => setTaskDuration(e.target.value)} style={styles.input} /><div style={{ gridColumn: '1 / -1', display: 'flex', gap: 8 }}><button style={styles.button}>Save task record</button><button type="button" style={styles.secondary} onClick={() => setShowTaskForm(false)}>Cancel</button></div></form>}

    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 12 }}>
      {[{ label: 'Participating teams', value: String(teams.length), icon: <Users size={17} /> }, { label: 'Tasks recorded', value: String(totals.tasks), icon: <CheckCircle2 size={17} /> }, { label: 'Task success rate', value: totals.tasks ? `${successRate.toFixed(1)}%` : '—', icon: <CheckCircle2 size={17} /> }, { label: 'Average cost / task', value: totals.tasks ? `$${avgCost.toFixed(4)}` : '—', icon: <DollarSign size={17} /> }].map(m => <div key={m.label} style={styles.card}><div style={{ ...styles.muted, display: 'flex', justifyContent: 'space-between' }}>{m.label}{m.icon}</div><div style={{ fontSize: 27, fontWeight: 700, marginTop: 8 }}>{m.value}</div></div>)}
    </div>

    <section style={{ ...styles.card, padding: 0, marginTop: 18, overflow: 'hidden' }}>
      <div style={{ padding: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', gap: 12, flexWrap: 'wrap' }}><div><h2 style={{ fontSize: 17 }}>Participating teams</h2><span style={styles.muted}>Team level pilot measures</span></div><div style={{ display: 'flex', gap: 8 }}><button style={styles.secondary} onClick={() => downloadCsv(visibleTeams, tasks)}><Download size={15} /> Export CSV</button><button style={styles.button} onClick={() => { setTaskTeam(teams[0]?.id || ''); setShowTaskForm(v => !v); }} disabled={!teams.length}><Plus size={15} /> Record task</button></div></div>
      <div style={{ padding: '12px 18px', display: 'flex', gap: 10, flexWrap: 'wrap', borderBottom: '1px solid var(--border-color)' }}><label style={{ ...styles.input, display: 'flex', gap: 8, alignItems: 'center' }}><Search size={15} /><input aria-label="Search teams" placeholder="Search teams or leads" value={query} onChange={e => setQuery(e.target.value)} style={{ border: 0, outline: 0, background: 'transparent', color: 'inherit', font: 'inherit' }} /></label><select aria-label="Filter by status" value={filter} onChange={e => setFilter(e.target.value)} style={styles.input}><option>All</option><option>Active</option><option>Follow-up</option><option>Completed</option></select></div>
      <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 760, textAlign: 'start' }}><thead><tr>{['Team / lead', 'Tasks', 'Success', 'Avg. cost', 'Interventions / task', 'Status', ''].map(h => <th key={h} style={{ padding: '12px 16px', color: 'var(--text-secondary)', fontWeight: 500, fontSize: 12, textAlign: 'start', borderBottom: '1px solid var(--border-color)' }}>{h}</th>)}</tr></thead><tbody>{visibleTeams.map(t => { const m = metricsFor(t.id); return <tr key={t.id}>
        <td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}><strong>{t.name}</strong><div style={styles.muted}>{t.lead} · {t.started}</div></td><td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}>{m.count}</td><td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}>{m.count ? `${m.success.toFixed(0)}%` : '—'}</td><td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}>{m.count ? `$${m.cost.toFixed(4)}` : '—'}</td><td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}>{m.count ? m.interventions.toFixed(1) : '—'}</td><td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}><span style={statusStyle(t.status)}>{t.status}</span></td><td style={{ padding: 14, borderBottom: '1px solid var(--border-color)' }}><select aria-label={`Update ${t.name} status`} value={t.status} onChange={e => setTeams(ts => ts.map(x => x.id === t.id ? { ...x, status: e.target.value as PilotTeam['status'] } : x))} style={{ ...styles.input, padding: '6px 8px', fontSize: 12 }}><option>Active</option><option>Follow-up</option><option>Completed</option></select></td>
      </tr>; })}</tbody></table>{visibleTeams.length === 0 && <p style={{ ...styles.muted, padding: 24, textAlign: 'center' }}>{teams.length ? 'No teams match this search.' : 'Add your pilot teams to begin recording results.'}</p>}</div>
      <div style={{ padding: '10px 18px', ...styles.muted, fontSize: 11 }}>Pilot records are stored locally in this browser profile. Enter measured results only; no sample outcomes are preloaded.</div>
    </section>

    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 14, marginTop: 16 }}>
      <section style={styles.card}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div><h2 style={{ fontSize: 16 }}>Launch decision gates</h2><p style={styles.muted}>Proposed thresholds from the project brief</p></div><Clock3 size={18} color="var(--text-secondary)" /></div><div style={{ display: 'grid', gap: 12, marginTop: 16 }}>{[{ label: 'Task success', target: '≥ 80%', value: totals.tasks ? `${successRate.toFixed(1)}%` : 'No task records', ok: totals.tasks > 0 && successRate >= 80 }, { label: 'Manual interventions', target: '≤ 2 / task', value: totals.tasks ? `${avgInterventions.toFixed(1)} / task` : 'No task records', ok: totals.tasks > 0 && avgInterventions <= 2 }, { label: 'Teams completing pilot', target: '3–5 teams', value: `${completedTeams} completed`, ok: completedTeams >= 3 }].map(g => <div key={g.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--border-color)', paddingTop: 11 }}><div><strong style={{ fontSize: 13 }}>{g.label}</strong><div style={styles.muted}>Target {g.target}</div></div><span style={statusStyle(g.ok ? 'Completed' : 'Follow-up')}>{g.value}</span></div>)}</div></section>
      <section style={styles.card}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div><h2 style={{ fontSize: 16 }}>Team feedback</h2><p style={styles.muted}>Record observations during the pilot</p></div><MessageSquareText size={18} color="var(--text-secondary)" /></div>
        {showFeedbackForm ? <form onSubmit={e => { e.preventDefault(); if (!feedbackTeam || !feedbackText.trim()) return; setFeedback(f => [{ teamId: feedbackTeam, text: feedbackText.trim(), date: new Date().toLocaleDateString() }, ...f]); setFeedbackTeam(''); setFeedbackText(''); setShowFeedbackForm(false); }} style={{ display: 'grid', gap: 8, marginTop: 12 }}><select required value={feedbackTeam} onChange={e => setFeedbackTeam(e.target.value)} style={styles.input}><option value="">Choose team</option>{teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select><textarea required aria-label="Feedback" placeholder="What did the team observe?" value={feedbackText} onChange={e => setFeedbackText(e.target.value)} style={{ ...styles.input, minHeight: 72, resize: 'vertical' }} /><div><button style={styles.button}>Save feedback</button><button type="button" style={{ ...styles.secondary, marginInlineStart: 8 }} onClick={() => setShowFeedbackForm(false)}>Cancel</button></div></form> : <button style={{ ...styles.secondary, marginTop: 12 }} onClick={() => setShowFeedbackForm(true)} disabled={!teams.length}><Plus size={14} /> Add feedback</button>}
        <div style={{ display: 'grid', gap: 10, marginTop: 14 }}>{feedback.map((f, i) => <article key={`${f.teamId}-${i}`} style={{ borderTop: '1px solid var(--border-color)', paddingTop: 10 }}><div style={{ display: 'flex', justifyContent: 'space-between', ...styles.muted }}><strong>{teams.find(t => t.id === f.teamId)?.name || 'Unknown team'}</strong><span>{f.date}</span></div><p style={{ fontSize: 13, marginTop: 4 }}>{f.text}</p></article>)}</div>
      </section>
    </div>
  </div>;
};
