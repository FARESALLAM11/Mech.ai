export type DiffLineType = 'add' | 'del' | 'meta' | 'context';

export interface DiffLine {
  type: DiffLineType;
  text: string;
}

export interface ParsedDiff {
  files: string[];
  lines: DiffLine[];
  additions: number;
  deletions: number;
}

const META_PREFIXES = ['diff --git', 'index ', '--- ', '+++ ', 'new file', 'deleted file', 'similarity index'];

/**
 * Minimal unified-diff parser used by the inline artifact card and the
 * full-screen review view. It only needs to highlight lines, not to apply them.
 */
export const parseDiff = (diff: string): ParsedDiff => {
  const files = [...diff.matchAll(/^\+\+\+ b\/(.+)$/gm)].map(match => match[1]);
  const lines: DiffLine[] = [];
  let additions = 0;
  let deletions = 0;

  for (const raw of diff.split('\n')) {
    if (!raw) {
      lines.push({ type: 'context', text: ' ' });
      continue;
    }
    const isMeta =
      raw.startsWith('@@') || META_PREFIXES.some(prefix => raw.startsWith(prefix));
    if (isMeta) {
      lines.push({ type: 'meta', text: raw });
      continue;
    }
    if (raw.startsWith('+')) {
      additions += 1;
      lines.push({ type: 'add', text: raw });
      continue;
    }
    if (raw.startsWith('-')) {
      deletions += 1;
      lines.push({ type: 'del', text: raw });
      continue;
    }
    lines.push({ type: 'context', text: raw });
  }

  return { files, lines, additions, deletions };
};
