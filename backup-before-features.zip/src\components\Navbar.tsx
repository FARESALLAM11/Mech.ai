import React from 'react';
import { ArrowLeft, Menu, Search, Settings2, TriangleAlert } from 'lucide-react';
import { isRunActive, useTaskStore } from '../store/taskStore';
import { isDesktop } from '../lib/runtime';

interface NavbarProps {
  onOpenPalette: () => void;
  onOpenSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenPalette, onOpenSidebar }) => {
  const { currentScreen, setCurrentScreen, conversations, activeConversationId, language, t } =
    useTaskStore();
  const strings = t();
  const isAr = language === 'ar';
  const preview = !isDesktop();

  const conversation = conversations.find(item => item.id === activeConversationId);
  const isChat = currentScreen === 'tasks';

  const screenTitles: Record<string, string> = {
    diff: strings.chat.changes,
    providers: strings.nav.providers,
    memory: strings.nav.memory,
    settings: strings.nav.settings,
    agents: isAr ? 'الوكلاء' : 'Agents',
    analytics: isAr ? 'التكلفة والإحصاءات' : 'Cost & analytics',
    aiRepos: isAr ? 'إضافات AI Repos' : 'AI repos',
    beta: isAr ? 'التجربة المغلقة' : 'Closed beta',
  };

  const title = isChat
    ? conversation && conversation.turns.length > 0
      ? conversation.title
      : strings.chat.newTask
    : screenTitles[currentScreen] ?? '';

  return (
    <header className="topbar">
      <button
        type="button"
        className="icon-btn mobile-only"
        onClick={onOpenSidebar}
        aria-label={isAr ? 'فتح القائمة' : 'Open menu'}
      >
        <Menu size={18} />
      </button>

      {!isChat && (
        <button
          type="button"
          className="icon-btn"
          onClick={() => setCurrentScreen('tasks')}
          title={isAr ? 'العودة إلى المحادثة' : 'Back to chat'}
          aria-label={isAr ? 'العودة إلى المحادثة' : 'Back to chat'}
        >
          <ArrowLeft size={17} />
        </button>
      )}

      <div className="topbar-left">
        <span className="topbar-title">{title}</span>
        {isChat && conversation && isRunActive(conversation.status) && (
          <span className="pill pill-running">
            <span className="dot" />
            {strings.chat.working}
          </span>
        )}
      </div>

      <div className="topbar-actions">
        {preview && (
          <span className="pill pill-preview" title={strings.chat.previewHint}>
            <TriangleAlert size={12} />
            {strings.chat.preview}
          </span>
        )}
        <span className="topbar-divider" />
        <button
          type="button"
          className="icon-btn topbar-search"
          onClick={onOpenPalette}
          title={isAr ? 'الأوامر (Ctrl+K)' : 'Commands (Ctrl+K)'}
          aria-label={isAr ? 'فتح لوحة الأوامر' : 'Open command palette'}
        >
          <Search size={17} />
        </button>
        <button
          type="button"
          className={`icon-btn${currentScreen === 'settings' ? ' is-active' : ''}`}
          onClick={() => setCurrentScreen(currentScreen === 'settings' ? 'tasks' : 'settings')}
          title={strings.nav.settings}
          aria-label={strings.nav.settings}
        >
          <Settings2 size={17} />
        </button>
      </div>
    </header>
  );
};
