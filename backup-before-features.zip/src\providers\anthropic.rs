use async_trait::async_trait;
use tokio::sync::mpsc;
use serde_json::json;
use futures_util::StreamExt;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct AnthropicProvider {
    pub api_key: String,
    pub base_url: String,
}

impl AnthropicProvider {
    pub fn new(api_key: String) -> Self {
        Self {
            api_key,
            base_url: "https://api.anthropic.com/v1".to_string(),
        }
    }

    pub fn with_base_url(api_key: String, base_url: String) -> Self {
        Self { api_key, base_url }
    }
}

#[async_trait]
impl ProviderAdapter for AnthropicProvider {
    fn id(&self) -> &str {
        "anthropic"
    }

    fn name(&self) -> &str {
        "Anthropic Claude"
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let client = reqwest::Client::new();
        let url = format!("{}/messages", self.base_url.trim_end_matches('/'));

        // Separate system message if present
        let mut system_prompt = String::new();
        let mut formatted_messages = Vec::new();

        for m in messages {
            if m.role == "system" {
                system_prompt.push_str(&m.content);
                system_prompt.push('\n');
            } else {
                formatted_messages.push(json!({
                    "role": m.role,
                    "content": m.content
                }));
            }
        }

        let mut payload = json!({
            "model": model,
            "max_tokens": 4096,
            "messages": formatted_messages,
            "stream": true
        });

        if !system_prompt.is_empty() {
            payload["system"] = json!(system_prompt.trim());
        }

        let res = client
            .post(&url)
            .header("x-api-key", &self.api_key)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .json(&payload)
            .send()
            .await?;

        if !res.status().is_success() {
            let error_text = res.text().await.unwrap_or_else(|_| "Anthropic error".into());
            anyhow::bail!("Anthropic request failed: {}", error_text);
        }

        let mut stream = res.bytes_stream();
        let mut buffer = String::new();
        let mut prompt_tokens = 0i64;
        let mut completion_tokens = 0i64;

        while let Some(item) = stream.next().await {
            let chunk = item?;
            let text = String::from_utf8_lossy(&chunk);
            buffer.push_str(&text);

            while let Some(newline_pos) = buffer.find('\n') {
                let line = buffer[..newline_pos].trim().to_string();
                buffer.drain(..=newline_pos);

                if line.starts_with("data: ") {
                    let json_str = &line[6..];
                    if let Ok(val) = serde_json::from_str::<serde_json::Value>(json_str) {
                        let event_type = val["type"].as_str().unwrap_or("");
                        
                        if event_type == "content_block_delta" {
                            if let Some(delta_text) = val["delta"]["text"].as_str() {
                                let _ = sender.send(StreamChunk {
                                    delta: delta_text.to_string(),
                                    is_done: false,
                                    prompt_tokens: None,
                                    completion_tokens: None,
                                    cost_usd: None,
                                }).await;
                            }
                        } else if event_type == "message_start" {
                            if let Some(usage) = val["message"]["usage"].as_object() {
                                prompt_tokens = usage.get("input_tokens").and_then(|v| v.as_i64()).unwrap_or(0);
                            }
                        } else if event_type == "message_delta" {
                            if let Some(usage) = val["usage"].as_object() {
                                completion_tokens = usage.get("output_tokens").and_then(|v| v.as_i64()).unwrap_or(0);
                            }
                        } else if event_type == "message_stop" {
                            let cost = self.price(model, prompt_tokens as usize, completion_tokens as usize);
                            let _ = sender.send(StreamChunk {
                                delta: String::new(),
                                is_done: true,
                                prompt_tokens: Some(prompt_tokens),
                                completion_tokens: Some(completion_tokens),
                                cost_usd: Some(cost),
                            }).await;
                            break;
                        }
                    }
                }
            }
        }

        Ok(())
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "claude-3-5-sonnet-20241022".into(),
                name: "Claude 3.5 Sonnet (Latest)".into(),
                provider: "anthropic".into(),
                context_window: 200000,
                input_price_per_m: 3.00,
                output_price_per_m: 15.00,
                supports_streaming: true,
            },
            ModelInfo {
                id: "claude-3-5-haiku-20241022".into(),
                name: "Claude 3.5 Haiku".into(),
                provider: "anthropic".into(),
                context_window: 200000,
                input_price_per_m: 1.00,
                output_price_per_m: 5.00,
                supports_streaming: true,
            },
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        text.len().div_ceil(4)
    }

    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let (in_rate, out_rate) = match model {
            m if m.contains("haiku") => (1.00, 5.00),
            _ => (3.00, 15.00),
        };
        let in_cost = (input_tokens as f64 / 1_000_000.0) * in_rate;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * out_rate;
        in_cost + out_cost
    }

    fn capabilities(&self, _model: &str) -> ProviderCapabilities {
        ProviderCapabilities {
            streaming: true,
            tool_calling: true,
            prompt_caching: true,
            context_window: 200000,
        }
    }
}
