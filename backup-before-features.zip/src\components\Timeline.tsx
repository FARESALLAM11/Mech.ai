import React from 'react';
import { CheckCircle2, CircleDashed, AlertCircle, Clock } from 'lucide-react';
import { TimelineEvent, TaskStatus, useTaskStore } from '../store/taskStore';

interface TimelineProps {
  events: TimelineEvent[];
}

export const Timeline: React.FC<TimelineProps> = ({ events }) => {
  const { language } = useTaskStore();
  const isAr = language === 'ar';

  const getStatusIcon = (status: TaskStatus) => {
    switch (status) {
      case 'done':
      case 'reviewing':
        return <CheckCircle2 size={18} color="var(--color-success)" />;
      case 'running':
      case 'testing':
      case 'planned':
        return <CircleDashed size={18} color="var(--color-primary)" style={{ animation: 'spin 1.5s linear infinite' }} />;
      case 'failed':
        return <AlertCircle size={18} color="var(--color-error)" />;
      default:
        return <Clock size={18} color="var(--text-secondary)" />;
    }
  };

  return (
    <div style={{
      background: 'var(--bg-card)',
      border: '1px solid var(--border-color)',
      borderRadius: 'var(--radius-lg)',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    }}>
      <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-primary)' }}>
        {isAr ? 'الخط الزمني لتنفيذ المهمة (Timeline)' : 'Execution Timeline'}
      </h3>

      {events.length === 0 ? (
        <div style={{ color: 'var(--text-secondary)', fontSize: '13px', padding: '12px 0' }}>
          {isAr ? 'في انتظار بدء المهمة...' : 'Waiting to start task...'}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {events.map((event, index) => (
            <div
              key={index}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '12px',
                padding: '12px 14px',
                background: 'var(--bg-secondary)',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--border-color)',
              }}
            >
              <div style={{ marginTop: '2px' }}>
                {getStatusIcon(event.status)}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '14px', fontWeight: 600, textTransform: 'capitalize' }}>
                    {event.status}
                  </span>
                  <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                    {event.duration_ms} ms
                  </span>
                </div>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  {event.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
