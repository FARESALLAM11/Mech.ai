import React, { useCallback, useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { KeyRound, LoaderCircle, Save, ShieldCheck, Trash2, Wifi, DollarSign } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

type ProviderId = 'openai' | 'anthropic' | 'gemini' | 'groq' | 'deepseek' | 'mistral';
type KeyStatus = { id: ProviderId; configured: boolean; masked_key?: string };
const providers: { id: ProviderId; name: string; description: string }[] = [
  { id: 'openai', name: 'OpenAI', description: 'OpenAI API · GPT models' },
  { id: 'anthropic', name: 'Anthropic', description: 'Anthropic API · Claude models' },
  { id: 'gemini', name: 'Google Gemini', description: 'Google AI Studio API' },
  { id: 'groq', name: 'Groq', description: 'Groq Cloud API' },
  { id: 'deepseek', name: 'DeepSeek', description: 'DeepSeek API' },
  { id: 'mistral', name: 'Mistral', description: 'Mistral API · Codestral and Mistral models' },
];

export const ProvidersScreen: React.FC = () => {
  const { t, language } = useTaskStore();
  const strings = t();
  const isAr = language === 'ar';
  const [statuses, setStatuses] = useState<KeyStatus[]>([]);
  const [keys, setKeys] = useState<Record<string, string>>({});
  const [budgets, setBudgets] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<{ text: string; error: boolean } | null>(null);

  const refresh = useCallback(async () => {
    try { setStatuses(await invoke<KeyStatus[]>('get_provider_key_status')); }
    catch { setMessage({ text: isAr ? 'تعذر الوصول إلى نواة Mech. افتح تطبيق سطح المكتب لحفظ المفاتيح بأمان.' : 'Mech core is unavailable. Open the desktop app to save keys securely.', error: true }); }
  }, [isAr]);
  useEffect(() => { void refresh(); }, [refresh]);

  const run = async (providerId: ProviderId, action: 'save' | 'test' | 'delete' | 'budget') => {
    setBusy(`${providerId}:${action}`); setMessage(null);
    try {
      if (action === 'save') {
        const key = keys[providerId]?.trim();
        if (!key) throw new Error(isAr ? 'أدخل مفتاح API أولاً.' : 'Enter an API key first.');
        const masked = await invoke<string>('store_api_key', { providerId, keyValue: key });
        setKeys(current => ({ ...current, [providerId]: '' }));
        setMessage({ text: `${isAr ? 'تم حفظ المفتاح في مخزن النظام:' : 'Key saved in the OS credential store:'} ${masked}`, error: false });
        await refresh();
      } else if (action === 'test') {
        await invoke<string>('test_provider_connection', { providerId, keyValue: keys[providerId]?.trim() || null });
        setMessage({ text: isAr ? `اتصال ${providers.find(p => p.id === providerId)?.name} ناجح.` : `${providers.find(p => p.id === providerId)?.name} connection succeeded.`, error: false });
      } else if (action === 'delete') {
        await invoke('delete_provider_key', { providerId });
        setMessage({ text: isAr ? 'تم حذف المفتاح من مخزن النظام.' : 'Key removed from the OS credential store.', error: false });
        await refresh();
      } else {
        const limit = Number(budgets[providerId]);
        if (!Number.isFinite(limit) || limit < 0) throw new Error(isAr ? 'أدخل ميزانية صحيحة.' : 'Enter a valid budget.');
        await invoke('set_provider_budget', { providerId, limitUsd: limit });
        setMessage({ text: isAr ? 'تم حفظ الميزانية.' : 'Budget saved.', error: false });
      }
    } catch (error) {
      setMessage({ text: error instanceof Error ? error.message : String(error), error: true });
    } finally { setBusy(null); }
  };

  const statusFor = (id: ProviderId) => statuses.find(item => item.id === id);
  const inputStyle: React.CSSProperties = { minWidth: 0, width: '100%', padding: '10px 12px', borderRadius: 8, border: '1px solid var(--border-color)', background: 'var(--bg-primary)', color: 'var(--text-primary)', font: 'inherit' };
  const buttonStyle: React.CSSProperties = { display: 'inline-flex', justifyContent: 'center', alignItems: 'center', gap: 7, padding: '9px 12px', borderRadius: 8, border: '1px solid var(--border-color)', background: 'var(--bg-primary)', color: 'var(--text-primary)', fontSize: 13, fontWeight: 600 };

  return <div style={{ maxWidth: 1020, display: 'grid', gap: 18 }}>
    <header><h2 style={{ fontSize: 22, fontWeight: 700 }}>{strings.providers.title}</h2><p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{isAr ? 'المفاتيح تُحفظ في مخزن بيانات اعتماد النظام ولا تغادر جهازك إلا ضمن طلبات المزود.' : 'Keys are stored in your operating system credential store and sent only to the selected provider.'}</p></header>
    {message && <div role="status" style={{ padding: 12, borderRadius: 9, color: message.error ? 'var(--color-error)' : 'var(--color-success)', background: message.error ? 'var(--color-error-light)' : 'var(--color-success-light)', overflowWrap: 'anywhere' }}>{message.text}</div>}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 14 }}>
      {providers.map(provider => {
        const configured = statusFor(provider.id);
        const saving = busy === `${provider.id}:save`;
        return <section key={provider.id} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, padding: 17, display: 'grid', gap: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><div><h3 style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 16 }}><ShieldCheck size={17} color="var(--color-primary)" />{provider.name}</h3><p style={{ color: 'var(--text-secondary)', fontSize: 12, marginTop: 4 }}>{provider.description}</p></div><span style={{ fontSize: 12, color: configured?.configured ? 'var(--color-success)' : 'var(--text-secondary)' }}>{configured?.configured ? (isAr ? 'متصل بإعداد' : 'Key saved') : (isAr ? 'غير مضبوط' : 'Not configured')}</span></div>
          {configured?.masked_key && <p style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-secondary)' }}>{isAr ? 'المفتاح:' : 'Key:'} {configured.masked_key}</p>}
          <label style={{ display: 'grid', gap: 5, fontSize: 12, color: 'var(--text-secondary)' }}>{isAr ? 'مفتاح API' : 'API key'}<input aria-label={`${provider.name} API key`} type="password" autoComplete="new-password" value={keys[provider.id] || ''} onChange={e => setKeys(current => ({ ...current, [provider.id]: e.target.value }))} placeholder={configured?.configured ? (isAr ? 'أدخل مفتاحاً جديداً للاستبدال' : 'Enter a new key to replace saved key') : 'API key'} style={inputStyle} /></label>
          <div style={{ display: 'flex', gap: 8 }}><label style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, fontSize: 12, color: 'var(--text-secondary)' }}><DollarSign size={14} /><input type="number" min="0" step="1" aria-label={`${provider.name} monthly budget`} value={budgets[provider.id] || ''} onChange={e => setBudgets(current => ({ ...current, [provider.id]: e.target.value }))} placeholder={isAr ? 'الميزانية الشهرية بالدولار' : 'Monthly budget (USD)'} style={inputStyle} /></label><button style={buttonStyle} disabled={busy !== null || !budgets[provider.id]} onClick={() => void run(provider.id, 'budget')}>{busy === `${provider.id}:budget` ? <LoaderCircle size={14} /> : (isAr ? 'حفظ الميزانية' : 'Save budget')}</button></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <button style={{ ...buttonStyle, color: 'var(--color-primary)' }} disabled={busy !== null} onClick={() => void run(provider.id, 'test')}><Wifi size={14} />{busy === `${provider.id}:test` ? <LoaderCircle size={14} /> : (isAr ? 'اختبار فعلي' : 'Test connection')}</button>
            <button style={{ ...buttonStyle, background: 'var(--color-primary)', color: 'var(--color-on-primary)' }} disabled={busy !== null || saving} onClick={() => void run(provider.id, 'save')}><Save size={14} />{saving ? <LoaderCircle size={14} /> : (isAr ? 'حفظ المفتاح' : 'Save key')}</button>
            {configured?.configured && <button style={{ ...buttonStyle, color: 'var(--color-error)', gridColumn: '1 / -1' }} disabled={busy !== null} onClick={() => void run(provider.id, 'delete')}><Trash2 size={14} />{isAr ? 'حذف المفتاح' : 'Remove saved key'}</button>}
          </div>
        </section>;
      })}
    </div>
    <div style={{ ...{ background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 10, padding: 14, color: 'var(--text-secondary)', fontSize: 12 } }}><KeyRound size={14} style={{ verticalAlign: 'middle', marginInlineEnd: 6 }} />{isAr ? 'لا تُعرض المفاتيح المحفوظة مرة أخرى. أدخل مفتاحاً جديداً لاستبداله. يلزم الاتصال بالإنترنت لاختبار بيانات الاعتماد.' : 'Saved keys are never read back into the UI. Enter a new key to replace one. Testing credentials requires an internet connection.'}</div>
  </div>;
};
