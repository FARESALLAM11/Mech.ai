use async_trait::async_trait;
use tokio::sync::mpsc;
use serde_json::json;
use futures_util::StreamExt;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct OllamaProvider {
    pub base_url: String,
}

impl OllamaProvider {
    pub fn new() -> Self {
        Self {
            base_url: "http://127.0.0.1:11434".to_string(),
        }
    }

    pub fn with_base_url(base_url: String) -> Self {
        Self { base_url }
    }

    /// Check if local Ollama daemon is active and responsive on default port
    pub async fn is_running(&self) -> bool {
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_millis(800))
            .build()
            .unwrap_or_default();
        
        let url = format!("{}/api/tags", self.base_url.trim_end_matches('/'));
        client.get(&url).send().await.map(|r| r.status().is_success()).unwrap_or(false)
    }
}

#[async_trait]
impl ProviderAdapter for OllamaProvider {
    fn id(&self) -> &str {
        "ollama"
    }

    fn name(&self) -> &str {
        "Ollama (Local Models - $0 Cost)"
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let client = reqwest::Client::new();
        let url = format!("{}/api/chat", self.base_url.trim_end_matches('/'));

        let target_model = if model.is_empty() || model == "default" {
            "llama3.2"
        } else {
            model
        };

        let formatted_messages: Vec<serde_json::Value> = messages
            .iter()
            .map(|m| {
                json!({
                    "role": m.role,
                    "content": m.content
                })
            })
            .collect();

        let payload = json!({
            "model": target_model,
            "messages": formatted_messages,
            "stream": true
        });

        let res = client
            .post(&url)
            .header("content-type", "application/json")
            .json(&payload)
            .send()
            .await?;

        if !res.status().is_success() {
            let error_text = res.text().await.unwrap_or_else(|_| "Ollama error".into());
            anyhow::bail!("Ollama request failed: {}", error_text);
        }

        let mut stream = res.bytes_stream();
        let mut buffer = String::new();
        let mut prompt_tokens = 0i64;
        let mut completion_tokens = 0i64;

        while let Some(item) = stream.next().await {
            let chunk = item?;
            let text = String::from_utf8_lossy(&chunk);
            buffer.push_str(&text);

            while let Some(newline_pos) = buffer.find('\n') {
                let line = buffer[..newline_pos].trim().to_string();
                buffer.drain(..=newline_pos);

                if line.is_empty() {
                    continue;
                }

                if let Ok(val) = serde_json::from_str::<serde_json::Value>(&line) {
                    if let Some(content) = val["message"]["content"].as_str() {
                        let _ = sender.send(StreamChunk {
                            delta: content.to_string(),
                            is_done: false,
                            prompt_tokens: None,
                            completion_tokens: None,
                            cost_usd: None,
                        }).await;
                    }

                    if val["done"].as_bool().unwrap_or(false) {
                        prompt_tokens = val["prompt_eval_count"].as_i64().unwrap_or(0);
                        completion_tokens = val["eval_count"].as_i64().unwrap_or(0);

                        let _ = sender.send(StreamChunk {
                            delta: String::new(),
                            is_done: true,
                            prompt_tokens: Some(prompt_tokens),
                            completion_tokens: Some(completion_tokens),
                            cost_usd: Some(0.0), // Local models are 100% free
                        }).await;
                        break;
                    }
                }
            }
        }

        Ok(())
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(3))
            .build()?;
        let url = format!("{}/api/tags", self.base_url.trim_end_matches('/'));
        let response = client.get(&url).send().await
            .map_err(|error| anyhow::anyhow!("Local Ollama is not reachable at {}: {error}", self.base_url))?;
        if !response.status().is_success() {
            anyhow::bail!("Local Ollama returned HTTP {} while listing models", response.status());
        }
        let data = response.json::<serde_json::Value>().await?;
        let models = data["models"].as_array().cloned().unwrap_or_default();
        Ok(models.iter().filter_map(|model| {
            let name = model["name"].as_str()?.to_string();
            Some(ModelInfo {
                id: name.clone(),
                name: format!("{} (Local)", name),
                provider: "ollama".into(),
                context_window: 128000,
                input_price_per_m: 0.0,
                output_price_per_m: 0.0,
                supports_streaming: true,
            })
        }).collect())
    }

    fn count_tokens(&self, text: &str) -> usize {
        text.len().div_ceil(4)
    }

    fn price(&self, _model: &str, _input_tokens: usize, _output_tokens: usize) -> f64 {
        0.0 // Free local computation
    }

    fn capabilities(&self, _model: &str) -> ProviderCapabilities {
        ProviderCapabilities {
            streaming: true,
            tool_calling: true,
            prompt_caching: false,
            context_window: 128000,
        }
    }
}
