import React, { useEffect, useRef } from 'react';
import { AlertCircle, CheckCircle2, LoaderCircle, PauseCircle } from 'lucide-react';
import mechMark from '../mech-mark.svg';
import {
  isRunActive,
  useTaskStore,
  type ChatTurn,
  type Conversation,
  type TaskStatus,
} from '../store/taskStore';
import { DiffCard } from './DiffCard';
import { formatCost, formatDuration, relativeTime } from '../lib/format';

interface ChatThreadProps {
  conversation: Conversation;
  busy: boolean;
}

export const ChatThread: React.FC<ChatThreadProps> = ({ conversation, busy }) => {
  const { language, t } = useTaskStore();
  const strings = t();
  const isAr = language === 'ar';
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);

  const signature = conversation.turns.reduce(
    (total, turn) => total + 1 + (turn.steps?.length ?? 0),
    0,
  );

  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !stickToBottom.current) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [signature]);

  const statusLabel = (status?: TaskStatus) => {
    switch (status) {
      case 'planned':
        return strings.chat.statusPlanned;
      case 'running':
        return strings.chat.statusRunning;
      case 'testing':
        return strings.chat.statusTesting;
      case 'reviewing':
        return strings.chat.statusReviewing;
      case 'done':
        return strings.chat.statusDone;
      case 'failed':
        return strings.chat.statusFailed;
      case 'paused':
        return strings.chat.statusPaused;
      default:
        return strings.chat.statusIdle;
    }
  };

  const statusLine = (status?: TaskStatus) => {
    switch (status) {
      case 'planned':
        return strings.chat.statusLinePlanned;
      case 'running':
        return strings.chat.statusLineRunning;
      case 'testing':
        return strings.chat.statusLineTesting;
      case 'reviewing':
        return strings.chat.statusLineReviewing;
      case 'done':
        return strings.chat.statusLineDone;
      case 'failed':
        return strings.chat.statusLineFailed;
      case 'paused':
        return strings.chat.statusPaused;
      default:
        return '';
    }
  };

  const renderStepIcon = (stepStatus: TaskStatus, current: boolean, active: boolean) => {
    if (stepStatus === 'failed') {
      return <AlertCircle size={15} color="var(--color-error)" />;
    }
    if (stepStatus === 'paused') {
      return <PauseCircle size={15} color="var(--text-secondary)" />;
    }
    if (current && active) {
      return <LoaderCircle size={15} className="spin" color="var(--color-primary)" />;
    }
    return (
      <CheckCircle2
        size={15}
        color={stepStatus === 'done' ? 'var(--color-success)' : 'var(--color-primary)'}
      />
    );
  };

  const renderAssistant = (turn: ChatTurn) => {
    const steps = turn.steps ?? [];
    const active = busy && isRunActive(turn.status);
    const totalDuration = steps.reduce((total, step) => total + (step.duration_ms || 0), 0);
    const line = turn.text || statusLine(turn.status);

    return (
      <article className="turn turn-assistant" key={turn.id}>
        <span className="avatar" aria-hidden="true">
          <img src={mechMark} alt="" width={16} height={16} />
        </span>
        <div className="turn-main">
          <div className="turn-name">
            <span>Mech</span>
            {turn.status && <span className={`status-pill status-${turn.status}`}>{statusLabel(turn.status)}</span>}
            <time dateTime={new Date(turn.at).toISOString()}>{relativeTime(turn.at, isAr)}</time>
          </div>

          {turn.error ? (
            <div className="inline-error" role="alert">
              {turn.error}
            </div>
          ) : line ? (
            <p className="turn-text">{line}</p>
          ) : null}

          {steps.length > 0 && (
            <section className="run-card" aria-label={strings.chat.progress}>
              <header className="run-head">
                <strong>{strings.chat.progress}</strong>
                <span className="run-meta">
                  {[formatCost(turn.costUsd), formatDuration(totalDuration)]
                    .filter(Boolean)
                    .join(' · ')}
                </span>
              </header>
              <ol className="steps">
                {steps.map((step, index) => {
                  const current = index === steps.length - 1;
                  return (
                    <li
                      key={`${step.step_index}-${index}`}
                      className={`step${current && active ? ' step-current' : ''}`}
                    >
                      <span className="step-icon">
                        {renderStepIcon(step.status, current, active)}
                      </span>
                      <span className="step-desc">{step.description}</span>
                      {step.duration_ms > 0 && (
                        <span className="step-time">{formatDuration(step.duration_ms)}</span>
                      )}
                    </li>
                  );
                })}
              </ol>
            </section>
          )}

          {turn.diff && (
            <DiffCard
              diff={turn.diff}
              projectPath={conversation.projectPath}
              taskId={turn.taskId ?? conversation.taskId}
              conversationId={conversation.id}
              turnId={turn.id}
              applied={turn.applied}
            />
          )}
        </div>
      </article>
    );
  };

  return (
    <div
      className="chat-scroll"
      ref={scrollRef}
      role="log"
      aria-live="polite"
      aria-label={strings.chat.progress}
      onScroll={event => {
        const el = event.currentTarget;
        stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
      }}
    >
      <div className="chat-inner">
        {conversation.turns.map(turn =>
          turn.role === 'user' ? (
            <article className="turn turn-user" key={turn.id}>
              <div className="bubble-user">{turn.text}</div>
            </article>
          ) : (
            renderAssistant(turn)
          ),
        )}
      </div>
    </div>
  );
};
