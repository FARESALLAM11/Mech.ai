import React from 'react';
import { Languages, LockKeyhole, Moon, Network, ShieldCheck, Sun } from 'lucide-react';
import { useTaskStore } from '../store/taskStore';

export const SettingsScreen: React.FC = () => {
  const { language, theme, setTheme, setLanguage } = useTaskStore();
  const isAr = language === 'ar';

  const notes = isAr
    ? [
        [
          'المصدر يبقى محلياً',
          'تُرسل ملفات المشروع إلى Ollama على هذا الجهاز فقط عند اختيار مهمة. لا يرسل التطبيق محتوى الملفات إلى مزودي السحابة.',
        ],
        [
          'مراجعة قبل التطبيق',
          'لا تُنسخ التغييرات من مساحة العمل المعزولة إلى المشروع إلا بعد ضغط «قبول وتطبيق» والتأكيد.',
        ],
        [
          'الأوامر والاختبارات',
          'لا ينفذ التطبيق أوامر اختبارات تلقائياً حالياً، ولا يدعي نجاح اختبارات لم يتم تشغيلها.',
        ],
        [
          'إضافات المستودعات',
          'تثبيت الإضافات غير متصل بعد؛ لا تستخدم صفحة AI Repos لإضافة ملفات أو تشغيل برامج.',
        ],
      ]
    : [
        [
          'Source stays local',
          'Project files are sent only to Ollama on this PC when you run a task. File contents are not sent to cloud providers.',
        ],
        [
          'Review before apply',
          'Changes are copied from the isolated workspace into the project only after you choose Accept & apply and confirm.',
        ],
        [
          'Commands and tests',
          'The app does not run project tests automatically and will not report test success when no tests ran.',
        ],
        [
          'Repository extensions',
          'Extension installation is not connected yet; AI Repos cannot add files or run software.',
        ],
      ];

  const icons = [
    <LockKeyhole size={16} key="lock" />,
    <ShieldCheck size={16} key="shield" />,
    <Network size={16} key="net" />,
    <Network size={16} key="ext" />,
  ];

  return (
    <div style={{ display: 'grid', gap: 18 }}>
      <header className="page-head">
        <div>
          <h2>{isAr ? 'الإعدادات' : 'Settings'}</h2>
          <p>
            {isAr
              ? 'المظهر واللغة وسلوك التطبيق. كل شيء يُحفظ على هذا الجهاز.'
              : 'Appearance, language, and how the app behaves. Everything is saved on this PC.'}
          </p>
        </div>
      </header>

      <div className="settings-grid">
        <section className="panel">
          <h3>
            {theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />}
            {isAr ? 'المظهر' : 'Appearance'}
          </h3>
          <p>
            {isAr
              ? 'اختر الوضع الفاتح أو الداكن. يتذكر Mech اختيارك.'
              : 'Pick the light or dark theme. Mech remembers your choice.'}
          </p>
          <div className="segmented" role="group" aria-label={isAr ? 'المظهر' : 'Theme'}>
            <button
              type="button"
              className={theme === 'light' ? 'is-active' : ''}
              aria-pressed={theme === 'light'}
              onClick={() => setTheme('light')}
            >
              <Sun size={14} />
              {isAr ? 'فاتح' : 'Light'}
            </button>
            <button
              type="button"
              className={theme === 'dark' ? 'is-active' : ''}
              aria-pressed={theme === 'dark'}
              onClick={() => setTheme('dark')}
            >
              <Moon size={14} />
              {isAr ? 'داكن' : 'Dark'}
            </button>
          </div>
        </section>

        <section className="panel">
          <h3>
            <Languages size={16} />
            {isAr ? 'اللغة' : 'Language'}
          </h3>
          <p>
            {isAr
              ? 'الواجهة تدعم العربية والإنجليزية بالكامل، بما فيها اتجاه RTL.'
              : 'The interface supports English and Arabic, including full RTL layout.'}
          </p>
          <div className="segmented" role="group" aria-label={isAr ? 'اللغة' : 'Language'}>
            <button
              type="button"
              className={language === 'en' ? 'is-active' : ''}
              aria-pressed={language === 'en'}
              onClick={() => setLanguage('en')}
            >
              English
            </button>
            <button
              type="button"
              className={language === 'ar' ? 'is-active' : ''}
              aria-pressed={language === 'ar'}
              onClick={() => setLanguage('ar')}
            >
              العربية
            </button>
          </div>
        </section>
      </div>

      <div style={{ display: 'grid', gap: 12 }}>
        {notes.map(([title, body], index) => (
          <section key={title} className="panel" style={{ gridTemplateColumns: '20px 1fr' }}>
            <span style={{ color: 'var(--text-secondary)' }}>{icons[index]}</span>
            <div>
              <h3 style={{ marginBottom: 5 }}>{title}</h3>
              <p>{body}</p>
            </div>
          </section>
        ))}
      </div>
    </div>
  );
};
