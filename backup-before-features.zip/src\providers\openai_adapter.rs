use async_trait::async_trait;
use tokio::sync::mpsc;
use serde_json::json;
use futures_util::StreamExt;
use crate::providers::trait_def::ProviderAdapter;
use crate::providers::types::{ChatMessage, ModelInfo, ProviderCapabilities, StreamChunk};

pub struct OpenAiCompatibleProvider {
    pub id: String,
    pub name: String,
    pub base_url: String,
    pub api_key: Option<String>,
}

impl OpenAiCompatibleProvider {
    pub fn new(id: String, name: String, base_url: String, api_key: Option<String>) -> Self {
        Self {
            id,
            name,
            base_url,
            api_key,
        }
    }
}

#[async_trait]
impl ProviderAdapter for OpenAiCompatibleProvider {
    fn id(&self) -> &str {
        &self.id
    }

    fn name(&self) -> &str {
        &self.name
    }

    async fn chat_stream(
        &self,
        model: &str,
        messages: &[ChatMessage],
        sender: mpsc::Sender<StreamChunk>,
    ) -> anyhow::Result<()> {
        let client = reqwest::Client::new();
        let url = format!("{}/chat/completions", self.base_url.trim_end_matches('/'));

        let mut req = client.post(&url).json(&json!({
            "model": model,
            "messages": messages,
            "stream": true,
            "stream_options": { "include_usage": true }
        }));

        if let Some(ref key) = self.api_key {
            req = req.header("Authorization", format!("Bearer {}", key));
        }

        let res = req.send().await?;
        if !res.status().is_success() {
            let error_text = res.text().await.unwrap_or_else(|_| "Unknown error".into());
            anyhow::bail!("API call failed with status: {}", error_text);
        }

        let mut stream = res.bytes_stream();
        let mut buffer = String::new();

        while let Some(item) = stream.next().await {
            let chunk = item?;
            let text = String::from_utf8_lossy(&chunk);
            buffer.push_str(&text);

            while let Some(newline_pos) = buffer.find('\n') {
                let line = buffer[..newline_pos].trim().to_string();
                buffer.drain(..=newline_pos);

                if line.is_empty() {
                    continue;
                }

                if let Some(payload) = line.strip_prefix("data: ") {
                    if payload == "[DONE]" {
                        let _ = sender.send(StreamChunk {
                            delta: String::new(),
                            is_done: true,
                            prompt_tokens: None,
                            completion_tokens: None,
                            cost_usd: None,
                        }).await;
                        break;
                    }

                    if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(payload) {
                        if let Some(content) = parsed["choices"][0]["delta"]["content"].as_str() {
                            let _ = sender.send(StreamChunk {
                                delta: content.to_string(),
                                is_done: false,
                                prompt_tokens: None,
                                completion_tokens: None,
                                cost_usd: None,
                            }).await;
                        }

                        if let Some(usage) = parsed.get("usage") {
                            let prompt_tokens = usage["prompt_tokens"].as_i64().unwrap_or(0);
                            let completion_tokens = usage["completion_tokens"].as_i64().unwrap_or(0);
                            let cost = self.price(model, prompt_tokens as usize, completion_tokens as usize);

                            let _ = sender.send(StreamChunk {
                                delta: String::new(),
                                is_done: true,
                                prompt_tokens: Some(prompt_tokens),
                                completion_tokens: Some(completion_tokens),
                                cost_usd: Some(cost),
                            }).await;
                        }
                    }
                }
            }
        }

        Ok(())
    }

    async fn list_models(&self) -> anyhow::Result<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "gpt-4o".into(),
                name: "GPT-4o".into(),
                provider: self.id.clone(),
                context_window: 128000,
                input_price_per_m: 2.50,
                output_price_per_m: 10.00,
                supports_streaming: true,
            },
            ModelInfo {
                id: "gpt-4o-mini".into(),
                name: "GPT-4o Mini".into(),
                provider: self.id.clone(),
                context_window: 128000,
                input_price_per_m: 0.15,
                output_price_per_m: 0.60,
                supports_streaming: true,
            },
        ])
    }

    fn count_tokens(&self, text: &str) -> usize {
        text.len().div_ceil(4)
    }

    fn price(&self, model: &str, input_tokens: usize, output_tokens: usize) -> f64 {
        let (rate_in, rate_out) = match model {
            "gpt-4o-mini" => (0.15, 0.60),
            _ => (2.50, 10.00),
        };
        let in_cost = (input_tokens as f64 / 1_000_000.0) * rate_in;
        let out_cost = (output_tokens as f64 / 1_000_000.0) * rate_out;
        in_cost + out_cost
    }

    fn capabilities(&self, _model: &str) -> ProviderCapabilities {
        ProviderCapabilities {
            streaming: true,
            tool_calling: true,
            prompt_caching: true,
            context_window: 128000,
        }
    }
}
